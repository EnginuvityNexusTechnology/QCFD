"""The discrete linear system handed to solvers. Classical and quantum solvers
consume the *same* object, which is what makes their results comparable."""

from __future__ import annotations

import hashlib
from dataclasses import dataclass, field

import numpy as np
import scipy.sparse as sp


@dataclass
class LinearSystem:
    A: sp.csr_matrix
    b: np.ndarray
    full_template: np.ndarray        # full nodal field with Dirichlet values filled in, NaN at unknowns
    unknown_index: np.ndarray        # flat indices (into full_template) of the unknowns, in system order
    meta: dict = field(default_factory=dict)

    @property
    def n(self) -> int:
        return int(self.A.shape[0])

    def expand(self, u: np.ndarray) -> np.ndarray:
        """Scatter the unknown vector back onto the full nodal field."""
        full = self.full_template.copy()
        full.flat[self.unknown_index] = u
        return full

    def is_symmetric(self, tol: float = 1e-12) -> bool:
        d = self.A - self.A.T
        return bool(abs(d).max() <= tol * max(abs(self.A).max(), 1e-300)) if d.nnz else True

    def fingerprint(self) -> str:
        """SHA-256 of (A, b). Two runs are numerically comparable only if these match."""
        A = self.A.tocsr()
        A.sort_indices()
        h = hashlib.sha256()
        for arr in (A.indptr, A.indices, np.round(A.data, 12), np.round(self.b, 12)):
            h.update(np.ascontiguousarray(arr).tobytes())
        return h.hexdigest()

    def describe(self) -> dict:
        return {"unknowns": self.n, "nnz": int(self.A.nnz), "symmetric": self.is_symmetric(),
                "fingerprint": self.fingerprint()[:16], **self.meta}
