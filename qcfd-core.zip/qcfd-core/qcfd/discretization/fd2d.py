"""5-point finite differences for -k lap u = f on a uniform rectangular mesh.

Unknowns are interior nodes, ordered x-fastest: idx = j*(nx-1) + i.
Dirichlet data on all four sides (Neumann in 2D is planned work).
"""

from __future__ import annotations

import numpy as np
import scipy.sparse as sp

from ..model.geometry import Rectangle
from ..model.manufactured import field_2d
from ..model.mesh import Mesh2D
from ..model.physics import ConstantSource, ManufacturedSource, Poisson2D
from .system import LinearSystem


def _t(n: int) -> sp.csr_matrix:
    return sp.diags([-np.ones(n - 1), 2 * np.ones(n), -np.ones(n - 1)], [-1, 0, 1], format="csr")


def manufactured_field(model: Poisson2D, geom: Rectangle):
    if isinstance(model.source, ManufacturedSource):
        return field_2d(model.source.name, model.source.params, geom.origin, geom.lx, geom.ly)
    return None


def assemble_poisson_2d(model: Poisson2D, geom: Rectangle, mesh: Mesh2D) -> LinearSystem:
    nx, ny, hx, hy, k = mesh.nx, mesh.ny, mesh.hx, mesh.hy, model.diffusivity
    X, Y = mesh.grid()
    ref = manufactured_field(model, geom)

    full = np.full((ny + 1, nx + 1), np.nan)
    side_slices = {"bottom": (0, slice(None)), "top": (ny, slice(None)),
                   "left": (slice(None), 0), "right": (slice(None), nx)}
    for name in ("bottom", "top", "left", "right"):   # left/right overwrite the corners
        bc = next(b for b in model.bcs if b.boundary == name)
        sl = side_slices[name]
        full[sl] = ref.u(X[sl], Y[sl]) if bc.value == "exact" else float(bc.value)

    Xi, Yi = X[1:-1, 1:-1], Y[1:-1, 1:-1]
    s = model.source
    if isinstance(s, ConstantSource):
        f = np.full_like(Xi, s.value)
    elif isinstance(s, ManufacturedSource):
        f = -k * ref.lap(Xi, Yi)
    else:
        f = np.zeros_like(Xi)

    # boundary contributions (neighbours of the interior that sit on the boundary)
    rhs = f.copy()
    rhs[:, 0] += k * full[1:-1, 0] / hx**2
    rhs[:, -1] += k * full[1:-1, nx] / hx**2
    rhs[0, :] += k * full[0, 1:-1] / hy**2
    rhs[-1, :] += k * full[ny, 1:-1] / hy**2

    mx, my = nx - 1, ny - 1
    A = k * (sp.kron(sp.identity(my), _t(mx)) / hx**2 + sp.kron(_t(my), sp.identity(mx)) / hy**2)
    unknown = np.zeros((ny + 1, nx + 1), dtype=bool)
    unknown[1:-1, 1:-1] = True
    return LinearSystem(A=A.tocsr(), b=rhs.ravel(), full_template=full,
                        unknown_index=np.flatnonzero(unknown.ravel()),
                        meta={"operator": "-k lap u (5-point)", "hx": hx, "hy": hy})
