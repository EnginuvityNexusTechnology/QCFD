"""Second-order finite differences on a uniform 1D node-centred mesh.

Operator:  -k u'' + c u' + r u = f
  diffusion  : 3-point central                      O(h^2)
  advection  : central O(h^2)  |  first-order upwind O(h)  (stable for any cell Peclet)
  Dirichlet  : eliminated into the right-hand side
  Neumann    : ghost node u_ghost from the central-difference BC (2nd order); the
               boundary row is halved so pure diffusion stays symmetric (CG-compatible).
"""

from __future__ import annotations

from typing import Literal

import numpy as np
import scipy.sparse as sp

from ..model.geometry import Interval
from ..model.manufactured import field_1d
from ..model.mesh import Mesh1D
from ..model.physics import BC, ConstantSource, ManufacturedSource, SteadyTransport1D
from .system import LinearSystem

AdvectionScheme = Literal["central", "upwind"]


def _bc(bcs: list[BC], name: str) -> BC:
    return next(b for b in bcs if b.boundary == name)


def manufactured_field(model: SteadyTransport1D, geom: Interval):
    if isinstance(model.source, ManufacturedSource):
        return field_1d(model.source.name, model.source.params, geom.origin, geom.length)
    return None


def source_values(model: SteadyTransport1D, geom: Interval, x: np.ndarray) -> np.ndarray:
    s = model.source
    if isinstance(s, ConstantSource):
        return np.full_like(x, s.value)
    if isinstance(s, ManufacturedSource):
        f = manufactured_field(model, geom)
        return -model.diffusivity * f.d2u(x) + model.velocity * f.du(x) + model.reaction * f.u(x)
    return np.zeros_like(x)


def assemble_steady_1d(model: SteadyTransport1D, geom: Interval, mesh: Mesh1D,
                       advection: AdvectionScheme = "central") -> LinearSystem:
    x, h, N = mesh.x, mesh.h, mesh.cells
    k, c, r = model.diffusivity, model.velocity, model.reaction
    ref = manufactured_field(model, geom)
    left, right = _bc(model.bcs, "left"), _bc(model.bcs, "right")

    def bc_value(bc: BC, side: str) -> float:
        if bc.value != "exact":
            return float(bc.value)
        xb = x[0] if side == "left" else x[-1]
        if bc.type == "dirichlet":
            return float(ref.u(np.array([xb]))[0])
        du = float(ref.du(np.array([xb]))[0])
        return -du if side == "left" else du       # outward normal derivative

    gL, gR = bc_value(left, "left"), bc_value(right, "right")

    # 3-point stencil coefficients (west, centre, east)
    w, ce, e = -k / h**2, 2 * k / h**2 + r, -k / h**2
    if advection == "central":
        w, e = w - c / (2 * h), e + c / (2 * h)
    elif c >= 0:
        w, ce = w - c / h, ce + c / h
    else:
        ce, e = ce - c / h, e + c / h

    f = source_values(model, geom, x)
    full = np.full(N + 1, np.nan)
    unknown = np.ones(N + 1, dtype=bool)
    if left.type == "dirichlet":
        full[0], unknown[0] = gL, False
    if right.type == "dirichlet":
        full[N], unknown[N] = gR, False

    nodes = np.flatnonzero(unknown)
    pos = -np.ones(N + 1, dtype=int)
    pos[nodes] = np.arange(nodes.size)
    rows, cols, vals = [], [], []
    rhs = np.zeros(nodes.size)

    for row, i in enumerate(nodes):
        coeffs = {i - 1: w, i: ce, i + 1: e}
        b_i = f[i]
        scale = 1.0
        if i == 0:      # left Neumann: u_{-1} = u_1 + 2h gL
            coeffs[1] += coeffs.pop(-1)
            b_i -= w * 2 * h * gL
            scale = 0.5
        if i == N:      # right Neumann: u_{N+1} = u_{N-1} + 2h gR
            coeffs[N - 1] += coeffs.pop(N + 1)
            b_i -= e * 2 * h * gR
            scale = 0.5
        for j, a in coeffs.items():
            if unknown[j]:
                rows.append(row); cols.append(pos[j]); vals.append(scale * a)
            else:
                b_i -= a * full[j]
        rhs[row] = scale * b_i

    A = sp.csr_matrix((vals, (rows, cols)), shape=(nodes.size, nodes.size))
    peclet = abs(c) * h / (2 * k)
    return LinearSystem(A=A, b=rhs, full_template=full, unknown_index=nodes,
                        meta={"operator": "-k u'' + c u' + r u", "advection": advection,
                              "cell_peclet": peclet, "h": h})


# ---- operators reused by the transient solvers --------------------------------

def d2_dirichlet(n_interior: int, h: float) -> sp.csr_matrix:
    """Interior second-derivative matrix (boundary values added separately)."""
    return sp.diags([np.ones(n_interior - 1), -2 * np.ones(n_interior), np.ones(n_interior - 1)],
                    [-1, 0, 1], format="csr") / h**2
