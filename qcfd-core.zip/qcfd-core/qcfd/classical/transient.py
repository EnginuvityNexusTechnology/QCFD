"""Time integrators for the transient models.

heat_1d               theta-scheme (theta=1 implicit Euler O(dt), theta=1/2 Crank-Nicolson O(dt^2)), LU factorised once
burgers_1d            imex_euler : implicit diffusion + explicit conservative central convection, O(dt + h^2)
                      mol_bdf    : method of lines, SciPy BDF with sparse Jacobian, adaptive dt, O(h^2)
incompressible_ns_2d  projection : SSP-RK3 on central differences, exact discrete projection via FFT (periodic)
"""

from __future__ import annotations

import time
from dataclasses import dataclass, field
from typing import Any, Callable

import numpy as np
import scipy.sparse as sp
import scipy.sparse.linalg as spla
from scipy.integrate import solve_ivp

from ..discretization.fd1d import d2_dirichlet


@dataclass
class TransientResult:
    times: np.ndarray                  # snapshot times
    fields: dict[str, np.ndarray]      # name -> array (n_snap, ...) on full nodes
    info: dict[str, Any] = field(default_factory=dict)
    resources: dict[str, Any] = field(default_factory=dict)


def _snap_steps(n_steps: int, n_snap: int) -> set[int]:
    return set(np.unique(np.linspace(0, n_steps, max(n_snap, 2)).round().astype(int)).tolist())


# ------------------------------------------------------------------ heat
def heat_theta(x: np.ndarray, u0: np.ndarray, alpha: float, t_end: float, dt: float,
               bc_left: Callable[[float], float], bc_right: Callable[[float], float],
               theta: float = 0.5, n_snap: int = 11) -> TransientResult:
    h = x[1] - x[0]
    n_steps = int(np.ceil(t_end / dt - 1e-12))
    dt = t_end / n_steps
    m = x.size - 2
    D2 = d2_dirichlet(m, h)
    I = sp.identity(m, format="csc")
    lhs = spla.splu((I - theta * dt * alpha * D2).tocsc())
    rhs_op = (I + (1 - theta) * dt * alpha * D2).tocsr()

    def bvec(t: float) -> np.ndarray:
        v = np.zeros(m)
        v[0] += alpha * bc_left(t) / h**2
        v[-1] += alpha * bc_right(t) / h**2
        return v

    t0 = time.perf_counter()
    u = u0[1:-1].copy()
    snaps, times, keep = [u0.copy()], [0.0], _snap_steps(n_steps, n_snap)
    for n in range(1, n_steps + 1):
        t_old, t_new = (n - 1) * dt, n * dt
        u = lhs.solve(rhs_op @ u + dt * (theta * bvec(t_new) + (1 - theta) * bvec(t_old)))
        if n in keep:
            snaps.append(np.concatenate(([bc_left(t_new)], u, [bc_right(t_new)])))
            times.append(t_new)
    return TransientResult(
        times=np.array(times), fields={"u": np.array(snaps)},
        info={"scheme": "crank_nicolson" if theta == 0.5 else f"theta={theta}", "steps": n_steps, "dt": dt,
              "diffusion_number": alpha * dt / h**2},
        resources={"runtime_s": time.perf_counter() - t0, "unknowns": m},
    )


# ------------------------------------------------------------------ Burgers
def burgers(x: np.ndarray, u0: np.ndarray, nu: float, t_end: float, dt: float | None,
            bc_left: Callable[[float], float], bc_right: Callable[[float], float],
            method: str = "mol_bdf", cfl: float = 0.4, n_snap: int = 11, rtol: float = 1e-8) -> TransientResult:
    h = x[1] - x[0]
    m = x.size - 2
    D2 = d2_dirichlet(m, h)

    def rhs(t: float, u: np.ndarray) -> np.ndarray:
        ul, ur = bc_left(t), bc_right(t)
        ue = np.concatenate(([ul], u, [ur]))
        conv = (ue[2:] ** 2 - ue[:-2] ** 2) / (4 * h)          # d/dx (u^2/2), central
        diff = D2 @ u
        diff[0] += ul / h**2
        diff[-1] += ur / h**2
        return -conv + nu * diff

    t0 = time.perf_counter()
    umax = float(np.max(np.abs(u0)))
    if method == "mol_bdf":
        t_eval = np.linspace(0, t_end, n_snap)
        sparsity = sp.diags([np.ones(m - 1), np.ones(m), np.ones(m - 1)], [-1, 0, 1])
        sol = solve_ivp(rhs, (0, t_end), u0[1:-1], method="BDF", t_eval=t_eval, rtol=rtol, atol=rtol * 1e-2,
                        jac_sparsity=sparsity)
        if not sol.success:
            raise RuntimeError(f"BDF integration failed: {sol.message}")
        interior, times = sol.y.T, sol.t
        info = {"scheme": "mol_bdf", "rhs_evaluations": int(sol.nfev), "jacobian_evaluations": int(sol.njev),
                "rtol": rtol}
    elif method == "imex_euler":
        dt = dt or cfl * h / max(umax, 1e-12)
        n_steps = int(np.ceil(t_end / dt - 1e-12))
        dt = t_end / n_steps
        lhs = spla.splu((sp.identity(m) - dt * nu * D2).tocsc())
        u = u0[1:-1].copy()
        keep = _snap_steps(n_steps, n_snap)
        interior, times = [u.copy()], [0.0]
        for n in range(1, n_steps + 1):
            t_old, t_new = (n - 1) * dt, n * dt
            ue = np.concatenate(([bc_left(t_old)], u, [bc_right(t_old)]))
            conv = (ue[2:] ** 2 - ue[:-2] ** 2) / (4 * h)
            r = u - dt * conv
            r[0] += dt * nu * bc_left(t_new) / h**2
            r[-1] += dt * nu * bc_right(t_new) / h**2
            u = lhs.solve(r)
            if n in keep:
                interior.append(u.copy()); times.append(t_new)
        interior, times = np.array(interior), np.array(times)
        info = {"scheme": "imex_euler", "steps": n_steps, "dt": dt, "cfl": umax * dt / h}
    else:
        raise ValueError(f"unknown Burgers method '{method}'")

    full = np.array([np.concatenate(([bc_left(t)], u, [bc_right(t)])) for t, u in zip(times, interior)])
    info["cell_reynolds"] = umax * h / nu
    return TransientResult(times=np.asarray(times), fields={"u": full}, info=info,
                           resources={"runtime_s": time.perf_counter() - t0, "unknowns": m})


# ------------------------------------------------------------------ incompressible NS (periodic)
def ns2d_projection(L: float, n: int, u0: np.ndarray, v0: np.ndarray, nu: float, t_end: float,
                    cfl: float = 0.5, n_snap: int = 6) -> TransientResult:
    """Periodic box, n x n unique nodes, collocated central differences.

    The projection uses the *discrete* symbol of central-difference div(grad),
    -(sin(k h)/h)^2, so the projected field is divergence-free to round-off in
    the same discrete divergence used to measure it.
    """
    h = L / n
    k = 2 * np.pi * np.fft.fftfreq(n, d=h)
    sk = np.sin(k * h) / h
    SX, SY = np.meshgrid(sk, sk, indexing="xy")      # arrays indexed [y, x]
    denom = SX**2 + SY**2
    denom[denom == 0] = 1.0                           # mean / Nyquist modes: nothing to project

    dx = lambda f: (np.roll(f, -1, axis=1) - np.roll(f, 1, axis=1)) / (2 * h)
    dy = lambda f: (np.roll(f, -1, axis=0) - np.roll(f, 1, axis=0)) / (2 * h)
    lap = lambda f: (np.roll(f, -1, 0) + np.roll(f, 1, 0) + np.roll(f, -1, 1) + np.roll(f, 1, 1) - 4 * f) / h**2

    def project(u, v):
        uh, vh = np.fft.fft2(u), np.fft.fft2(v)
        div = 1j * (SX * uh + SY * vh)
        phi = -div / denom                            # lap_h phi = div  ->  -(SX^2+SY^2) phi = div
        uh = uh - 1j * SX * phi
        vh = vh - 1j * SY * phi
        return np.real(np.fft.ifft2(uh)), np.real(np.fft.ifft2(vh))

    def rhs(u, v):
        return (-(u * dx(u) + v * dy(u)) + nu * lap(u),
                -(u * dx(v) + v * dy(v)) + nu * lap(v))

    umax = max(float(np.abs(u0).max()), float(np.abs(v0).max()), 1e-12)
    dt = min(cfl * h / umax, 0.2 * h**2 / nu)
    n_steps = int(np.ceil(t_end / dt - 1e-12))
    dt = t_end / n_steps
    keep = _snap_steps(n_steps, n_snap)

    t0 = time.perf_counter()
    u, v = project(u0, v0)
    U, V, times = [u.copy()], [v.copy()], [0.0]
    for s in range(1, n_steps + 1):                   # SSP-RK3, projection after each stage
        r1 = rhs(u, v)
        u1, v1 = project(u + dt * r1[0], v + dt * r1[1])
        r2 = rhs(u1, v1)
        u2, v2 = project(0.75 * u + 0.25 * (u1 + dt * r2[0]), 0.75 * v + 0.25 * (v1 + dt * r2[1]))
        r3 = rhs(u2, v2)
        u, v = project(u / 3 + 2 / 3 * (u2 + dt * r3[0]), v / 3 + 2 / 3 * (v2 + dt * r3[1]))
        if s in keep:
            U.append(u.copy()); V.append(v.copy()); times.append(s * dt)
    div = dx(u) + dy(v)
    return TransientResult(
        times=np.array(times), fields={"u": np.array(U), "v": np.array(V)},
        info={"scheme": "ssp_rk3_projection", "steps": n_steps, "dt": dt, "cfl": umax * dt / h,
              "viscous_number": nu * dt / h**2, "max_divergence_final": float(np.abs(div).max())},
        resources={"runtime_s": time.perf_counter() - t0, "unknowns": 2 * n * n},
    )
