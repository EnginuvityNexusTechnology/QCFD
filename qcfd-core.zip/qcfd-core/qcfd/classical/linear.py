"""Classical linear solvers for steady problems (SciPy)."""

from __future__ import annotations

import time
from dataclasses import dataclass, field
from typing import Any, Literal

import numpy as np
import scipy.sparse as sp
import scipy.sparse.linalg as spla

from ..discretization.system import LinearSystem

Method = Literal["direct", "cg", "gmres"]

INFO = {
    "direct": ("implemented", "Sparse LU (SuperLU). Exact to round-off; memory grows with fill-in."),
    "cg": ("implemented", "Conjugate gradients; requires a symmetric positive-definite operator. Jacobi-preconditioned."),
    "gmres": ("implemented", "Restarted GMRES(50), ILU-preconditioned; for non-symmetric operators (advection)."),
}


@dataclass
class LinearResult:
    u: np.ndarray
    converged: bool
    method: str
    info: dict[str, Any] = field(default_factory=dict)
    resources: dict[str, Any] = field(default_factory=dict)


def solve_linear(system: LinearSystem, method: Method = "direct", *, rtol: float = 1e-10,
                 maxiter: int = 10_000) -> LinearResult:
    A, b = system.A, system.b
    bnorm = max(float(np.linalg.norm(b)), 1e-300)
    history: list[float] = []
    t0 = time.perf_counter()

    if method == "direct":
        u = spla.spsolve(sp.csc_matrix(A), b)
        ok, extra = True, {}
    elif method == "cg":
        if not system.is_symmetric():
            raise ValueError("CG requires a symmetric operator; use 'gmres' or 'direct'")
        M = sp.diags(1.0 / A.diagonal())
        u, flag = spla.cg(A, b, rtol=rtol, maxiter=maxiter, M=M,
                          callback=lambda xk: history.append(float(np.linalg.norm(A @ xk - b) / bnorm)))
        ok, extra = flag == 0, {"flag": int(flag)}
    elif method == "gmres":
        ilu = spla.spilu(sp.csc_matrix(A), drop_tol=1e-5)
        M = spla.LinearOperator(A.shape, ilu.solve)
        u, flag = spla.gmres(A, b, rtol=rtol, restart=50, maxiter=maxiter, M=M,
                             callback=lambda rk: history.append(float(rk)), callback_type="pr_norm")
        ok, extra = flag == 0, {"flag": int(flag)}
    else:
        raise ValueError(f"unknown classical method '{method}'")

    dt = time.perf_counter() - t0
    u = np.asarray(u, dtype=float)
    res = float(np.linalg.norm(A @ u - b) / bnorm)
    return LinearResult(
        u=u, converged=bool(ok and res < max(1e3 * rtol, 1e-8)), method=method,
        info={"relative_residual": res, "iterations": len(history), "residual_history": history, **extra},
        resources={"runtime_s": dt, "unknowns": system.n, "nnz": int(A.nnz)},
    )
