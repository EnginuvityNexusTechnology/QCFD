"""Variational Quantum Linear Solver (VQLS) with local circuit simulation.

Formulation (Bravo-Prieto et al., Quantum 7, 1188 (2023)):
    |x(theta)> = V(theta)|0>,   |b> = U_b|0>,   A = sum_l c_l P_l  (Pauli LCU)
    global cost  C(theta) = 1 - |<b|A|x>|^2 / <x|A^dag A|x>
    physical solution  u = mu |x>,  mu = ||b|| <b|A|x> / (s <x|A^dag A|x>)   (s = operator scale)

Two cost evaluators share the same circuits:
  exact    statevector expectation values (idealised, noiseless, infinite shots)
  sampled  the estimator a device would run:
             <b|A|x>      = sum_l c_l <0|U_b^dag P_l V|0>   -> one Hadamard test per Pauli term,
                            ancilla outcome drawn from its exact circuit probability with `shots` samples
             <x|A^dag A|x> = sum_k d_k <x|Q_k|x>            -> one Pauli-basis measurement setting per term
           so the cost carries realistic shot noise; noise models are planned work.

Readout: computational-basis sampling gives |x_k|^2; signs come from the
statevector (sign-resolving readout is planned) and this is reported.

No quantum advantage is claimed: this is a correctness and resource study.
"""

from __future__ import annotations

import time
from dataclasses import dataclass, field
from typing import Any, Literal

import numpy as np
from scipy.optimize import minimize

from ..discretization.system import LinearSystem
from . import pauli
from .circuit import hardware_efficient_ansatz, n_parameters, simulate

CostMode = Literal["exact", "sampled"]
Optimizer = Literal["lbfgs", "spsa"]
MAX_QUBITS = 10


@dataclass
class QuantumResult:
    u: np.ndarray
    converged: bool
    info: dict[str, Any] = field(default_factory=dict)
    resources: dict[str, Any] = field(default_factory=dict)
    circuit_qasm: str = ""


# ------------------------------------------------------------------ encoding
@dataclass
class EncodedProblem:
    A: np.ndarray          # 2^n x 2^n, scaled so max |a_ij| = 1
    b_hat: np.ndarray      # normalised, padded
    b_norm: float
    scale: float
    n_qubits: int
    n_original: int
    a_terms: list[pauli.PauliTerm]
    ata_terms: list[pauli.PauliTerm]


def encode(system: LinearSystem) -> EncodedProblem:
    """Pad to 2^n with an identity block (padded unknowns solve to 0), rescale, decompose."""
    N = system.n
    n = max(1, int(np.ceil(np.log2(N))))
    if n > MAX_QUBITS:
        raise ValueError(f"{N} unknowns need {n} qubits; local simulation is capped at {MAX_QUBITS}")
    A = system.A.toarray().astype(float)
    b = system.b.astype(float)
    if 2**n != N:
        pad = 2**n - N
        diag = float(np.mean(np.abs(np.diag(A))))
        A = np.block([[A, np.zeros((N, pad))], [np.zeros((pad, N)), diag * np.eye(pad)]])
        b = np.concatenate([b, np.zeros(pad)])
    scale = float(np.abs(A).max())
    As = A / scale
    bn = float(np.linalg.norm(b))
    if bn == 0:
        raise ValueError("right-hand side is zero; the solution is trivially zero")
    return EncodedProblem(A=As, b_hat=b / bn, b_norm=bn, scale=scale, n_qubits=n, n_original=N,
                          a_terms=pauli.decompose(As), ata_terms=pauli.decompose(As.T @ As))


# ------------------------------------------------------------------ cost evaluators
class CostEvaluator:
    def __init__(self, enc: EncodedProblem, layers: int, mode: CostMode, shots: int, rng: np.random.Generator):
        self.enc, self.layers, self.mode, self.shots, self.rng = enc, layers, mode, shots, rng
        self.evaluations = 0
        self.circuits_executed = 0
        self.shots_used = 0

    def state(self, theta: np.ndarray) -> np.ndarray:
        return simulate(hardware_efficient_ansatz(self.enc.n_qubits, self.layers, theta))

    def exact_terms(self, x: np.ndarray) -> tuple[complex, float]:
        Ax = self.enc.A @ x
        return complex(np.vdot(self.enc.b_hat, Ax)), float(np.real(np.vdot(Ax, Ax)))

    def _sample_expectation(self, value: float) -> float:
        """Estimate a +/-1 observable with mean `value` from `shots` single-shot outcomes."""
        p = float(np.clip(0.5 * (1 + value), 0, 1))
        return 2 * self.rng.binomial(self.shots, p) / self.shots - 1

    def sampled_terms(self, x: np.ndarray) -> tuple[complex, float]:
        enc = self.enc
        beta = 0j
        for t in enc.a_terms:                      # Hadamard tests
            ov = np.vdot(enc.b_hat, pauli.apply(t, x))
            # real states: even #Y -> real overlap (Re test), odd #Y -> imaginary overlap (Im test)
            if t.n_y % 2 == 0:
                beta += t.coeff * self._sample_expectation(float(ov.real))
            else:
                beta += t.coeff * 1j * self._sample_expectation(float(ov.imag))
            self.circuits_executed += 1
        den = 0.0
        for t in enc.ata_terms:                    # Pauli-basis measurements
            if t.xmask == 0 and t.zmask == 0:
                den += float(t.coeff.real)         # identity: no circuit needed
                continue
            if t.n_y % 2 == 1:
                continue                           # <x|Q|x> = 0 for real x, Hermitian real A^T A
            ev = float(np.real(np.vdot(x, pauli.apply(t, x))))
            den += float(t.coeff.real) * self._sample_expectation(ev)
            self.circuits_executed += 1
        self.shots_used += self.shots * self.circuits_per_evaluation()
        return beta, max(den, 1e-12)

    def circuits_per_evaluation(self) -> int:
        return len(self.enc.a_terms) + sum(
            1 for t in self.enc.ata_terms if (t.xmask or t.zmask) and t.n_y % 2 == 0)

    def cost(self, theta: np.ndarray) -> float:
        """Training objective.

        exact   : normalised global cost 1 - |<b|A|x>|^2 / <x|A^T A|x>
        sampled : unnormalised global cost <x|A^T A|x> - |<b|A|x>|^2  (same minimiser, value 0 at the
                  solution). It is linear in the measured expectation values, so it avoids the
                  ratio, whose small denominator near the solution amplifies shot noise by orders
                  of magnitude for ill-conditioned A.
        """
        self.evaluations += 1
        x = self.state(theta)
        if self.mode == "sampled":
            beta, den = self.sampled_terms(x)
            return float(den - abs(beta) ** 2)
        beta, den = self.exact_terms(x)
        return float(1.0 - abs(beta) ** 2 / den)


# ------------------------------------------------------------------ optimisers
def _spsa(f, theta0: np.ndarray, iters: int, rng: np.random.Generator, c: float = 0.2,
          first_step: float = 0.3, resamples: int = 2):
    """SPSA (Spall 1998) with the standard practical safeguards for shot noise:
    gain calibrated so the first update moves ~`first_step` rad, gradient averaged over
    `resamples` perturbations, and blocking (a step is rejected if the cost rises by
    more than twice the measured noise)."""
    theta = theta0.copy()
    A_stab = 0.1 * iters
    alpha, gamma = 0.602, 0.101

    def grad(th: np.ndarray, ck: float) -> np.ndarray:
        g = np.zeros_like(th)
        for _ in range(resamples):
            d = rng.choice([-1.0, 1.0], size=th.size)
            g += (f(th + ck * d) - f(th - ck * d)) / (2 * ck) * d
        return g / resamples

    # calibration
    g0 = np.mean([np.abs(grad(theta, c)).mean() for _ in range(3)])
    a = first_step * (A_stab + 1) ** alpha / max(g0, 1e-9)
    noise = float(np.std([f(theta) for _ in range(5)], ddof=1))
    current = float(f(theta))
    history = [current]
    for k in range(iters):
        ak, ck = a / (k + 1 + A_stab) ** alpha, c / (k + 1) ** gamma
        trial = theta - ak * grad(theta, ck)
        fv = float(f(trial))
        if fv <= current + 2 * noise:          # blocking
            theta, current = trial, fv
        if k % 10 == 0 or k == iters - 1:
            history.append(current)
    return theta, history


# ------------------------------------------------------------------ resources
def estimate_resources(system: LinearSystem, layers: int | None = None, shots: int = 0) -> dict[str, Any]:
    N = system.n
    n = max(1, int(np.ceil(np.log2(N))))
    layers = layers or n + 1
    out: dict[str, Any] = {
        "unknowns": N, "qubits": n, "padded_unknowns": 2**n - N, "ansatz_layers": layers,
        "ansatz_parameters": n_parameters(n, layers), "ansatz_cx": layers * (n - 1),
        "ansatz_depth": hardware_efficient_ansatz(n, layers, np.zeros(n_parameters(n, layers))).depth(),
        "statevector_bytes": 16 * 2**n, "feasible_locally": n <= MAX_QUBITS,
        # generic amplitude encoding of |b> (uniformly controlled rotations)
        "state_prep_cx_estimate": max(2 ** (n + 1) - 2 * n - 2, 0),
        "hadamard_test_ancillas": 1,
    }
    if n <= MAX_QUBITS:
        enc = encode(system)
        n_den = sum(1 for t in enc.ata_terms if (t.xmask or t.zmask) and t.n_y % 2 == 0)
        out.update({
            "pauli_terms_A": len(enc.a_terms), "pauli_terms_AtA": len(enc.ata_terms),
            "max_pauli_weight": max(t.weight for t in enc.a_terms),
            "circuits_per_cost_evaluation": len(enc.a_terms) + n_den,
            # controlled ansatz in a Hadamard test: CRY ~ 2 CX, CX -> Toffoli ~ 6 CX
            "controlled_ansatz_cx_estimate": 2 * n_parameters(n, layers) + 6 * layers * (n - 1),
        })
        if shots:
            out["shots_per_cost_evaluation"] = shots * out["circuits_per_cost_evaluation"]
    return out


# ------------------------------------------------------------------ solver
def solve_vqls(system: LinearSystem, *, layers: int | None = None, cost_mode: CostMode = "exact",
               optimizer: Optimizer = "lbfgs", shots: int = 10_000, readout_shots: int | None = None,
               restarts: int = 3, maxiter: int = 1000, seed: int = 1234,
               convergence_threshold: float = 1e-6) -> QuantumResult:
    enc = encode(system)
    n = enc.n_qubits
    layers = layers or n + 1
    rng = np.random.default_rng(seed)
    if cost_mode == "sampled" and optimizer == "lbfgs":
        raise ValueError("L-BFGS needs a deterministic cost; use optimizer='spsa' with cost_mode='sampled'")

    ev = CostEvaluator(enc, layers, cost_mode, shots, rng)
    t0 = time.perf_counter()
    best_theta, best_cost, restart_costs, history = None, np.inf, [], []
    for _ in range(restarts):
        th0 = rng.uniform(0, 2 * np.pi, n_parameters(n, layers))
        if optimizer == "lbfgs":
            res = minimize(ev.cost, th0, method="L-BFGS-B",
                           options={"maxiter": maxiter, "ftol": 1e-15, "gtol": 1e-11})
            theta, c = res.x, float(res.fun)
        else:
            theta, hist = _spsa(ev.cost, th0, maxiter, rng)
            history.extend(hist)
            c = float(np.mean([ev.cost(theta) for _ in range(3)]))
        restart_costs.append(c)
        if c < best_cost:
            best_theta, best_cost = theta, c
    train_time = time.perf_counter() - t0

    circ = hardware_efficient_ansatz(n, layers, best_theta)
    x = simulate(circ)
    beta_x, den_x = ev.exact_terms(x)
    exact_cost = float(1 - abs(beta_x) ** 2 / den_x)

    # final estimate as the device would report it
    final = {}
    if cost_mode == "sampled":
        reps = [ev.sampled_terms(x) for _ in range(5)]
        costs = [1 - abs(bt) ** 2 / dn for bt, dn in reps]
        ucosts = [dn - abs(bt) ** 2 for bt, dn in reps]
        beta, den = np.mean([r[0] for r in reps]), float(np.mean([r[1] for r in reps]))
        final = {"sampled_cost_mean": float(np.mean(costs)), "sampled_cost_std": float(np.std(costs, ddof=1)),
                 "sampled_unnormalised_cost_mean": float(np.mean(ucosts)),
                 "sampled_unnormalised_cost_std": float(np.std(ucosts, ddof=1)),
                 "sampled_estimate_repeats": len(reps)}
    else:
        beta, den = beta_x, den_x

    # readout of amplitudes
    amps = x.real.copy()
    if readout_shots:
        p = rng.multinomial(readout_shots, np.abs(x) ** 2) / readout_shots
        amps = np.sign(x.real) * np.sqrt(p)
        final.update({"readout_shots": readout_shots, "readout_sign_source": "statevector (idealised)",
                      "readout_max_prob_std": float(np.sqrt(np.max(p * (1 - p)) / readout_shots))})
    mu = enc.b_norm * float(np.real(beta)) / (enc.scale * den)
    u_full = mu * amps
    u = u_full[: enc.n_original]
    resid = float(np.linalg.norm(system.A @ u - system.b) / np.linalg.norm(system.b))

    resources = estimate_resources(system, layers, shots if cost_mode == "sampled" else 0)
    resources.update({"runtime_s": train_time, "cost_evaluations": ev.evaluations,
                      "circuits_executed": ev.circuits_executed, "shots_used": ev.shots_used,
                      "ansatz_gate_counts": circ.gate_counts(), "ansatz_two_qubit_depth": circ.two_qubit_depth(),
                      "simulator": "qcfd.statevector (NumPy, noiseless)"})
    return QuantumResult(
        u=u,
        converged=exact_cost < convergence_threshold,
        info={"method": "vqls", "cost_mode": cost_mode, "optimizer": optimizer, "seed": seed,
              "final_cost_exact": exact_cost, "restart_costs": restart_costs, "spsa_history": history,
              "relative_residual": resid, "padding_leakage": float(np.linalg.norm(u_full[enc.n_original:])),
              "condition_number": float(np.linalg.cond(enc.A)), "scale_factor_mu": mu,
              "pauli_terms": [(t.label, round(t.coeff.real, 12), round(t.coeff.imag, 12)) for t in enc.a_terms],
              **final},
        resources=resources,
        circuit_qasm=circ.to_qasm(),
    )


STATUS = "limited"
LIMITATIONS = (
    "VQLS on a local noiseless statevector simulator. Sampled mode models shot noise only (no gate/readout noise). "
    "Readout signs come from the statevector. Hardware-efficient ansatz without trainability guarantees. "
    f"Capped at {MAX_QUBITS} qubits (2^{MAX_QUBITS} unknowns). No quantum advantage is claimed."
)
