"""Gate-level circuits and a dependency-free statevector simulator (NumPy).

Convention: qubit 0 is the most significant bit, so amplitude index k maps
directly to unknown k of the linear system (big-endian).
Circuits export to OpenQASM 2.0 so they can be re-run in any framework.
"""

from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np

_H = np.array([[1, 1], [1, -1]]) / np.sqrt(2)
_X = np.array([[0, 1], [1, 0]])


def _ry(theta: float) -> np.ndarray:
    c, s = np.cos(theta / 2), np.sin(theta / 2)
    return np.array([[c, -s], [s, c]])


SINGLE = {"ry": lambda p: _ry(p[0]), "h": lambda p: _H, "x": lambda p: _X}


@dataclass
class Circuit:
    n_qubits: int
    ops: list[tuple[str, tuple[int, ...], tuple[float, ...]]] = field(default_factory=list)

    def ry(self, q: int, theta: float) -> "Circuit":
        self.ops.append(("ry", (q,), (float(theta),))); return self

    def h(self, q: int) -> "Circuit":
        self.ops.append(("h", (q,), ())); return self

    def x(self, q: int) -> "Circuit":
        self.ops.append(("x", (q,), ())); return self

    def cx(self, control: int, target: int) -> "Circuit":
        if control == target:
            raise ValueError("control == target")
        self.ops.append(("cx", (control, target), ())); return self

    # ---- resource accounting ------------------------------------------------
    def gate_counts(self) -> dict[str, int]:
        out: dict[str, int] = {}
        for g, _, _ in self.ops:
            out[g] = out.get(g, 0) + 1
        return out

    def depth(self) -> int:
        level = [0] * self.n_qubits
        for _, qs, _ in self.ops:
            d = max(level[q] for q in qs) + 1
            for q in qs:
                level[q] = d
        return max(level, default=0)

    def two_qubit_depth(self) -> int:
        level = [0] * self.n_qubits
        for g, qs, _ in self.ops:
            if len(qs) == 2:
                d = max(level[q] for q in qs) + 1
                for q in qs:
                    level[q] = d
        return max(level, default=0)

    def to_qasm(self, measure: bool = True) -> str:
        lines = ["OPENQASM 2.0;", 'include "qelib1.inc";', f"qreg q[{self.n_qubits}];"]
        if measure:
            lines.append(f"creg c[{self.n_qubits}];")
        for g, qs, ps in self.ops:
            args = ",".join(f"q[{q}]" for q in qs)
            lines.append(f"{g}({ps[0]:.12g}) {args};" if ps else f"{g} {args};")
        if measure:
            lines.append("measure q -> c;")
        return "\n".join(lines) + "\n"


def simulate(circ: Circuit) -> np.ndarray:
    n = circ.n_qubits
    psi = np.zeros((2,) * n, dtype=complex)
    psi[(0,) * n] = 1.0
    for g, qs, ps in circ.ops:
        if g in SINGLE:
            (q,) = qs
            psi = np.moveaxis(np.tensordot(SINGLE[g](ps), psi, axes=([1], [q])), 0, q)
        elif g == "cx":
            c, t = qs
            idx = [slice(None)] * n
            idx[c] = 1
            sub = psi[tuple(idx)]
            psi[tuple(idx)] = np.flip(sub, axis=t if t < c else t - 1)
        else:  # pragma: no cover
            raise ValueError(f"unsupported gate {g}")
    return psi.reshape(-1)


def hardware_efficient_ansatz(n_qubits: int, layers: int, theta: np.ndarray) -> Circuit:
    """Real-amplitude ansatz: RY layer, then `layers` x (linear CX ladder + RY layer)."""
    need = n_parameters(n_qubits, layers)
    if theta.size != need:
        raise ValueError(f"expected {need} parameters, got {theta.size}")
    c, k = Circuit(n_qubits), 0
    for q in range(n_qubits):
        c.ry(q, theta[k]); k += 1
    for _ in range(layers):
        for q in range(n_qubits - 1):
            c.cx(q, q + 1)
        for q in range(n_qubits):
            c.ry(q, theta[k]); k += 1
    return c


def n_parameters(n_qubits: int, layers: int) -> int:
    return n_qubits * (layers + 1)
