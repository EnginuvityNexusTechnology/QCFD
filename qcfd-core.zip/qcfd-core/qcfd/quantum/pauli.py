"""Pauli (LCU) decomposition of matrices and fast Pauli action on statevectors.

A = sum_l c_l P_l,  c_l = tr(P_l A) / 2^n.
Computed with one Walsh-Hadamard transform per X-mask: O(4^n n) instead of
the naive O(8^n), so 8-10 qubit operators decompose in well under a second.
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np


@dataclass(frozen=True)
class PauliTerm:
    coeff: complex
    xmask: int      # bits where the factor is X or Y
    zmask: int      # bits where the factor is Z or Y
    n: int

    @property
    def label(self) -> str:
        out = []
        for q in range(self.n):
            bit = 1 << (self.n - 1 - q)
            x, z = bool(self.xmask & bit), bool(self.zmask & bit)
            out.append("Y" if x and z else "X" if x else "Z" if z else "I")
        return "".join(out)

    @property
    def n_y(self) -> int:
        return bin(self.xmask & self.zmask).count("1")

    @property
    def weight(self) -> int:
        return bin(self.xmask | self.zmask).count("1")


def _fwht(a: np.ndarray) -> np.ndarray:
    a = a.astype(complex).copy()
    h = 1
    while h < a.size:
        a = a.reshape(-1, 2, h)
        a = np.stack((a[:, 0] + a[:, 1], a[:, 0] - a[:, 1]), axis=1)
        h *= 2
    return a.reshape(-1)


def decompose(A: np.ndarray, tol: float = 1e-12) -> list[PauliTerm]:
    N = A.shape[0]
    n = int(round(np.log2(N)))
    if 2**n != N or A.shape != (N, N):
        raise ValueError("matrix must be 2^n x 2^n")
    k = np.arange(N)
    scale = max(float(np.abs(A).max()), 1e-300)
    terms = []
    for xm in range(N):
        w = A[k, k ^ xm]
        if not np.any(np.abs(w) > tol * scale):
            continue
        S = _fwht(w)       # S[zm] = sum_k (-1)^{k.zm} A[k, k^xm]
        for zm in np.flatnonzero(np.abs(S) > tol * scale * N):
            ny = bin(xm & int(zm)).count("1")
            c = (1j ** ny) * S[zm] / N
            terms.append(PauliTerm(complex(c), xm, int(zm), n))
    return terms


def apply(term: PauliTerm, psi: np.ndarray) -> np.ndarray:
    """P|psi> (without the coefficient)."""
    j = np.arange(psi.size)
    parity = (np.bitwise_count(j & term.zmask) & 1) if term.zmask else 0
    phase = (1j ** term.n_y) * (-1.0) ** parity
    out = np.empty_like(psi, dtype=complex)
    out[j ^ term.xmask] = phase * psi
    return out


def to_dense(terms: list[PauliTerm], n: int) -> np.ndarray:
    N = 2**n
    M = np.zeros((N, N), dtype=complex)
    I = np.eye(N)
    for t in terms:
        for col in range(N):
            M[:, col] += t.coeff * apply(t, I[:, col])
    return M
