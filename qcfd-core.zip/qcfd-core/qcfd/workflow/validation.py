"""Error metrics, convergence orders and validation checks."""

from __future__ import annotations

from typing import Any, Literal

import numpy as np

CheckStatus = Literal["passed", "warning", "failed", "not_applicable"]


def check(name: str, status: CheckStatus, detail: str, value: Any = None) -> dict:
    if isinstance(value, np.generic):
        value = value.item()
    return {"name": name, "status": status, "detail": detail, "value": value}


def error_metrics(u: np.ndarray, ref: np.ndarray, cell_volume: float | None = None) -> dict[str, float]:
    u, ref = np.asarray(u, float).ravel(), np.asarray(ref, float).ravel()
    e = u - ref
    rn = float(np.linalg.norm(ref))
    rmax = float(np.max(np.abs(ref)))
    out = {
        "max_abs": float(np.max(np.abs(e))),
        "max_relative": float(np.max(np.abs(e)) / rmax) if rmax > 0 else float("nan"),
        "l2_relative": float(np.linalg.norm(e) / rn) if rn > 0 else float("nan"),
        "rmse": float(np.sqrt(np.mean(e**2))),
        "mse": float(np.mean(e**2)),
    }
    if cell_volume is not None:
        out["l2_discrete"] = float(np.sqrt(cell_volume * np.sum(e**2)))
    return out


def observed_order(hs: list[float], errors: list[float]) -> float:
    hs_a, e = np.asarray(hs, float), np.asarray(errors, float)
    if len(e) < 2 or np.any(e <= 0) or e.max() < 1e-11:
        return float("nan")
    return float(np.polyfit(np.log(hs_a), np.log(e), 1)[0])


def self_convergence_order(coarse: np.ndarray, medium: np.ndarray, fine: np.ndarray) -> float:
    """Richardson-type order from three nested grids (no reference needed); arrays sampled on the coarse nodes."""
    d1, d2 = np.linalg.norm(coarse - medium), np.linalg.norm(medium - fine)
    if d2 < 1e-14 or d1 < 1e-14:
        return float("nan")
    return float(np.log2(d1 / d2))


def order_check(name: str, observed: float, expected: float, tol: float, what: str) -> dict:
    if np.isnan(observed):
        return check(name, "not_applicable", f"{what}: error at round-off (solution exactly representable)")
    ok = abs(observed - expected) <= tol
    better = observed > expected + tol
    status: CheckStatus = "passed" if ok or better else "warning"
    return check(name, status, f"{what}: expected ~{expected:g} (+/-{tol:g})", round(observed, 3))


def tolerance_check(name: str, value: float, tol: float, what: str, fail_status: CheckStatus = "failed") -> dict:
    if value is None or np.isnan(value):
        return check(name, "not_applicable", what)
    return check(name, "passed" if value <= tol else fail_status, f"{what} <= {tol:g}", value)
