"""Feature status registry: every capability is labelled implemented, limited, third-party or planned."""

CAPABILITIES: list[dict[str, str]] = [
    # geometry / mesh
    {"area": "geometry", "feature": "1D interval", "status": "implemented"},
    {"area": "geometry", "feature": "2D rectangle", "status": "implemented"},
    {"area": "geometry", "feature": "CAD import / curved boundaries / 3D", "status": "planned"},
    {"area": "mesh", "feature": "uniform structured 1D/2D, quality checks, memory estimate", "status": "implemented"},
    {"area": "mesh", "feature": "graded / stretched / unstructured meshes", "status": "planned"},
    # physics
    {"area": "physics", "feature": "steady_transport_1d: -k u'' + c u' + r u = f (Dirichlet, Neumann)", "status": "implemented"},
    {"area": "physics", "feature": "poisson_2d: -k lap u = f (Dirichlet)", "status": "implemented"},
    {"area": "physics", "feature": "heat_1d: transient diffusion (Dirichlet)", "status": "implemented"},
    {"area": "physics", "feature": "burgers_1d: viscous Burgers (Dirichlet)", "status": "implemented"},
    {"area": "physics", "feature": "incompressible_ns_2d: periodic box (Taylor-Green)", "status": "limited"},
    {"area": "physics", "feature": "walls / inflow-outflow NS, flow over a cylinder, Schrodinger 1D", "status": "planned"},
    # classical
    {"area": "classical", "feature": "sparse direct, Jacobi-CG, ILU-GMRES", "status": "implemented"},
    {"area": "classical", "feature": "Crank-Nicolson, implicit Euler, IMEX Euler, BDF (method of lines), SSP-RK3 projection", "status": "implemented"},
    # quantum
    {"area": "quantum", "feature": "VQLS, exact statevector cost", "status": "limited"},
    {"area": "quantum", "feature": "VQLS, shot-sampled Hadamard-test cost + SPSA", "status": "limited"},
    {"area": "quantum", "feature": "Pauli/LCU decomposition, resource estimates, OpenQASM 2 export", "status": "implemented"},
    {"area": "quantum", "feature": "noise models, sign-resolving readout, HHL/QSVT, framework backends (Qiskit/Qrisp/PennyLane)", "status": "planned"},
    {"area": "quantum", "feature": "quantum formulation for transient or nonlinear models", "status": "planned"},
    {"area": "quantum", "feature": "cloud / physical QPU execution", "status": "planned"},
    # workflow
    {"area": "workflow", "feature": "TOML cases, setup validation, local projects, run folders with checksums", "status": "implemented"},
    {"area": "workflow", "feature": "grid-refinement study, comparison, validation checks", "status": "implemented"},
    {"area": "workflow", "feature": "HTML / Markdown / PDF reports, CSV export", "status": "implemented"},
]
