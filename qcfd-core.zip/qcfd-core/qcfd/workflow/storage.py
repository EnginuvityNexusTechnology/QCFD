"""Local projects and run folders (no network, no database server).

project/
  project.json            manifest (format, version, name, created)
  cases/                  case files kept with the project
  runs/index.jsonl        one line per run (append-only)
  runs/<run_id>/          everything needed to reproduce and audit a run:
      case.toml  case.resolved.json  environment.json  run.log
      setup.json  mesh.json  system/  fields/  quantum/
      results.json  validation.json  report.*  figures/  checksums.json
"""

from __future__ import annotations

import hashlib
import json
import platform
import re
import secrets
import shutil
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import numpy as np
import scipy
import scipy.sparse as sp

from .. import __version__

FORMAT = "qcfd-project"
FORMAT_VERSION = 1


def utcnow() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def environment() -> dict[str, str]:
    env = {"qcfd": __version__, "python": sys.version.split()[0], "numpy": np.__version__,
           "scipy": scipy.__version__, "platform": platform.platform(), "machine": platform.machine()}
    try:
        import matplotlib
        env["matplotlib"] = matplotlib.__version__
    except ImportError:  # pragma: no cover
        pass
    return env


def _json_default(o: Any) -> Any:
    if isinstance(o, np.generic):
        return o.item()
    if isinstance(o, np.ndarray):
        return o.tolist()
    if isinstance(o, complex):
        return [o.real, o.imag]
    if isinstance(o, Path):
        return str(o)
    raise TypeError(f"not JSON serialisable: {type(o)}")


def dump_json(path: Path, data: Any) -> Path:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, indent=2, default=_json_default, allow_nan=True))
    return path


class RunFolder:
    def __init__(self, path: Path):
        self.path = Path(path)

    @property
    def run_id(self) -> str:
        return self.path.name

    def file(self, rel: str) -> Path:
        p = self.path / rel
        p.parent.mkdir(parents=True, exist_ok=True)
        return p

    def write_json(self, rel: str, data: Any) -> Path:
        return dump_json(self.file(rel), data)

    def read_json(self, rel: str) -> Any:
        return json.loads((self.path / rel).read_text())

    def write_text(self, rel: str, text: str) -> Path:
        p = self.file(rel)
        p.write_text(text)
        return p

    def save_array(self, rel: str, arr: np.ndarray) -> Path:
        p = self.file(rel if rel.endswith(".npy") else rel + ".npy")
        np.save(p, np.asarray(arr))
        return p

    def load_array(self, rel: str) -> np.ndarray:
        return np.load(self.path / (rel if rel.endswith(".npy") else rel + ".npy"))

    def save_sparse(self, rel: str, A: sp.spmatrix) -> Path:
        p = self.file(rel if rel.endswith(".npz") else rel + ".npz")
        sp.save_npz(p, sp.csr_matrix(A))
        return p

    def log(self, msg: str) -> None:
        with self.file("run.log").open("a") as f:
            f.write(f"{utcnow()}  {msg.rstrip()}\n")

    def finalize(self) -> dict[str, str]:
        sums = {str(p.relative_to(self.path)).replace("\\", "/"): sha256_file(p)
                for p in sorted(self.path.rglob("*")) if p.is_file() and p.name != "checksums.json"}
        self.write_json("checksums.json", sums)
        return sums

    def verify(self) -> list[str]:
        """Return the files whose checksum no longer matches (empty list = intact)."""
        sums = self.read_json("checksums.json")
        bad = [rel for rel, h in sums.items()
               if not (self.path / rel).exists() or sha256_file(self.path / rel) != h]
        return bad


class Project:
    def __init__(self, root: Path):
        self.root = Path(root)
        manifest = self.root / "project.json"
        if not manifest.exists():
            raise FileNotFoundError(f"{self.root} is not a QuantumCFD project (no project.json)")
        self.manifest = json.loads(manifest.read_text())
        if self.manifest.get("format") != FORMAT:
            raise ValueError("project.json has an unknown format")

    @classmethod
    def create(cls, root: str | Path, name: str, description: str = "") -> "Project":
        root = Path(root)
        if (root / "project.json").exists():
            raise FileExistsError(f"a project already exists at {root}")
        for d in ("cases", "runs"):
            (root / d).mkdir(parents=True, exist_ok=True)
        dump_json(root / "project.json", {"format": FORMAT, "format_version": FORMAT_VERSION, "name": name,
                                          "description": description, "created_at": utcnow(),
                                          "created_with": environment()})
        return cls(root)

    @classmethod
    def open_or_create(cls, root: str | Path, name: str | None = None) -> "Project":
        root = Path(root)
        return cls(root) if (root / "project.json").exists() else cls.create(root, name or root.name)

    def new_run(self, case_name: str) -> RunFolder:
        slug = re.sub(r"[^a-z0-9]+", "-", case_name.lower()).strip("-")[:40] or "case"
        run_id = f"{datetime.now(timezone.utc):%Y%m%dT%H%M%SZ}-{slug}-{secrets.token_hex(2)}"
        path = self.root / "runs" / run_id
        path.mkdir(parents=True)
        return RunFolder(path)

    def store_case(self, case_file: Path) -> Path:
        dst = self.root / "cases" / case_file.name
        if not dst.exists() or dst.read_bytes() != case_file.read_bytes():
            shutil.copy2(case_file, dst)
        return dst

    def index_run(self, record: dict) -> None:
        with (self.root / "runs" / "index.jsonl").open("a") as f:
            f.write(json.dumps(record, default=_json_default) + "\n")

    def runs(self) -> list[dict]:
        idx = self.root / "runs" / "index.jsonl"
        if not idx.exists():
            return []
        return [json.loads(line) for line in idx.read_text().splitlines() if line.strip()]

    def run(self, run_id: str) -> RunFolder:
        p = self.root / "runs" / run_id
        if not p.is_dir():
            raise FileNotFoundError(run_id)
        return RunFolder(p)
