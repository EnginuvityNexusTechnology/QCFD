"""Simulation pipeline:

    case -> setup validation -> mesh -> discretization -> classical and/or quantum solve
         -> comparison -> refinement study -> validation checks -> stored run -> report

Classical and quantum solvers never import each other; they meet only here,
through the shared LinearSystem, which is what makes the comparison valid.
"""

from __future__ import annotations

import time
import traceback
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable

import numpy as np

from .. import __version__
from ..classical import linear as classical_linear
from ..classical import transient as classical_transient
from ..discretization.fd1d import assemble_steady_1d, manufactured_field as mf1d
from ..discretization.fd2d import assemble_poisson_2d, manufactured_field as mf2d
from ..discretization.system import LinearSystem
from ..model import manufactured as ms
from ..model.mesh import Mesh1D, Mesh2D, MeshSpec1D, MeshSpec2D, build_mesh, memory_estimate_bytes, quality
from ..model.physics import BC, ManufacturedSource
from ..quantum import vqls
from .case import Case, CaseError, check_case
from .storage import Project, RunFolder, environment, utcnow
from .validation import (check, error_metrics, observed_order, order_check, self_convergence_order,
                         tolerance_check)

Log = Callable[[str], None]
MAX_REFINEMENT_UNKNOWNS = 2_000_000


@dataclass
class RunOutcome:
    run_id: str
    run_dir: Path
    status: str
    summary: dict = field(default_factory=dict)
    checks: list[dict] = field(default_factory=list)

    @property
    def failed_checks(self) -> list[dict]:
        return [c for c in self.checks if c["status"] == "failed"]


# =========================================================================== helpers
def scaled_mesh_spec(case: Case, factor: int) -> MeshSpec1D | MeshSpec2D:
    m = case.mesh
    if isinstance(m, MeshSpec1D):
        return MeshSpec1D(cells=m.cells * factor)
    return MeshSpec2D(nx=m.nx * factor, ny=m.ny * factor)


def cell_volume(mesh: Mesh1D | Mesh2D) -> float:
    return mesh.h if isinstance(mesh, Mesh1D) else mesh.hx * mesh.hy


def assemble(case: Case, mesh: Mesh1D | Mesh2D) -> LinearSystem:
    p = case.physics
    if p.model == "steady_transport_1d":
        return assemble_steady_1d(p, case.geometry, mesh, case.discretization.advection)
    if p.model == "poisson_2d":
        return assemble_poisson_2d(p, case.geometry, mesh)
    raise ValueError(f"{p.model} is not a steady linear model")


def steady_reference(case: Case, mesh: Mesh1D | Mesh2D) -> np.ndarray | None:
    p = case.physics
    if not isinstance(p.source, ManufacturedSource):
        return None
    # numeric BCs that differ from the manufactured field make it no longer the solution
    if any(b.value != "exact" for b in p.bcs):
        return None
    if p.model == "steady_transport_1d":
        return mf1d(p, case.geometry).u(mesh.x)
    X, Y = mesh.grid()
    return mf2d(p, case.geometry).u(X, Y)


def estimate(case: Case) -> dict[str, Any]:
    """Pre-run resource estimate (the 'validate setup' step)."""
    mesh = build_mesh(case.geometry, case.mesh)
    out: dict[str, Any] = {"mesh": mesh.summary(), "memory_estimate_bytes": memory_estimate_bytes(mesh)}
    p = case.physics
    if p.steady:
        system = assemble(case, mesh)
        out["system"] = system.describe()
        if case.solver.mode in ("quantum", "both"):
            q = case.solver.quantum
            out["quantum"] = vqls.estimate_resources(system, q.layers, q.shots if q.cost_mode == "sampled" else 0)
    elif case.time is not None:
        out["time"] = {"t_end": case.time.t_end, "scheme": case.scheme, "dt": case.time.dt or "auto"}
    if case.validation.refinement_levels:
        f = 2 ** case.validation.refinement_levels
        out["refinement_finest_mesh"] = build_mesh(case.geometry, scaled_mesh_spec(case, f)).summary()
    return out


def _drop(d: dict, *keys: str) -> dict:
    return {k: v for k, v in d.items() if k not in keys}


# =========================================================================== steady
def _run_steady(case: Case, mesh, rf: RunFolder, log: Log) -> tuple[dict, list[dict]]:
    v, mode = case.validation, case.solver.mode
    checks: list[dict] = []
    system = assemble(case, mesh)
    desc = system.describe()
    rf.save_sparse("system/A", system.A)
    rf.save_array("system/b", system.b)
    rf.write_json("system/system.json", {**desc, "fingerprint": system.fingerprint()})
    log(f"assembled {desc['unknowns']} unknowns, nnz={desc['nnz']}, symmetric={desc['symmetric']}")

    vol = cell_volume(mesh)
    ref = steady_reference(case, mesh)
    fields: dict[str, np.ndarray] = {}
    if ref is not None:
        fields["reference"] = ref
    results: dict[str, Any] = {}

    if mode in ("classical", "both"):
        cfg = case.solver.classical
        log(f"classical solve: {cfg.method}")
        cr = classical_linear.solve_linear(system, cfg.method, rtol=cfg.rtol)
        uc = system.expand(cr.u)
        fields["classical"] = uc
        status, limits = classical_linear.INFO[cfg.method]
        results["classical"] = {"method": cfg.method, "status": status, "limitations": limits,
                                "info": _drop(cr.info, "residual_history"),
                                "residual_history": cr.info["residual_history"][:500], "resources": cr.resources}
        checks.append(check("classical.converged", "passed" if cr.converged else "failed", "solver convergence"))
        checks.append(tolerance_check("classical.residual", cr.info["relative_residual"],
                                      max(1e-8, 100 * cfg.rtol), "relative residual ||Au-b||/||b||"))
        if ref is not None:
            m = error_metrics(uc, ref, vol)
            results["classical"]["metrics_vs_reference"] = m
            checks.append(tolerance_check("classical.reference_error", m["l2_relative"], v.reference_tolerance,
                                          "relative L2 error vs analytical reference"))
        else:
            checks.append(check("classical.reference_error", "not_applicable",
                                "no analytical reference for this set-up; see the self-convergence study"))

    if mode in ("quantum", "both"):
        q = case.solver.quantum
        log(f"quantum solve: VQLS cost={q.cost_mode} optimizer={q.optimizer} seed={q.seed}")
        qr = vqls.solve_vqls(system, layers=q.layers, cost_mode=q.cost_mode, optimizer=q.optimizer,
                             shots=q.shots, readout_shots=q.readout_shots, restarts=q.restarts,
                             maxiter=q.maxiter, seed=q.seed, convergence_threshold=q.convergence_threshold)
        uq = system.expand(qr.u)
        fields["quantum"] = uq
        rf.write_text("quantum/ansatz.qasm", qr.circuit_qasm)
        rf.write_json("quantum/pauli_terms.json", qr.info.pop("pauli_terms"))
        results["quantum"] = {"method": "vqls", "status": vqls.STATUS, "limitations": vqls.LIMITATIONS,
                              "info": qr.info, "resources": qr.resources}
        log(f"VQLS exact final cost {qr.info['final_cost_exact']:.3e}, residual {qr.info['relative_residual']:.3e}")
        checks.append(check("quantum.cost_converged", "passed" if qr.converged else "warning",
                            f"VQLS global cost < {q.convergence_threshold:g} (exact, simulator diagnostic)",
                            qr.info["final_cost_exact"]))
        checks.append(tolerance_check("quantum.padding_leakage", qr.info["padding_leakage"], 1e-3,
                                      "norm of the padded (non-physical) amplitudes", "warning"))
        if q.cost_mode == "sampled" or q.readout_shots:
            checks.append(check("quantum.sampling", "warning",
                                "shot noise included; readout signs from statevector (idealised)",
                                qr.info.get("sampled_cost_std")))
        checks.append(check("quantum.hardware_noise", "not_applicable",
                            "noiseless simulator: gate and readout noise are not modelled"))
        if ref is not None:
            m = error_metrics(uq, ref, vol)
            results["quantum"]["metrics_vs_reference"] = m
            checks.append(tolerance_check("quantum.reference_error", m["l2_relative"], v.reference_tolerance,
                                          "relative L2 error vs analytical reference", "warning"))

    comparison = None
    if "classical" in fields and "quantum" in fields:
        m = error_metrics(fields["quantum"], fields["classical"], vol)
        comparison = {"compatible": True, "basis": "identical discrete system (same A, b fingerprint)",
                      "fingerprint": system.fingerprint(), "metrics_quantum_vs_classical": m}
        checks.append(tolerance_check("comparison.quantum_vs_classical", m["l2_relative"], v.comparison_tolerance,
                                      "relative L2 difference, quantum vs classical", "warning"))

    refinement = _steady_refinement(case, log) if v.refinement_levels else None
    if refinement:
        checks.append(order_check("classical.convergence_order", refinement["observed_order"],
                                  refinement["expected_order"], v.order_tolerance, refinement["kind"]))

    budget = _error_budget(results, comparison, refinement, case)
    summary = {"kind": "steady_1d" if isinstance(mesh, Mesh1D) else "steady_2d", "system": desc,
               "results": results, "comparison": comparison, "refinement": refinement, "error_budget": budget}
    _save_fields(rf, mesh, fields, summary["kind"])
    return summary, checks


def _steady_refinement(case: Case, log: Log) -> dict:
    p = case.physics
    expected = 1.0 if (p.model == "steady_transport_1d" and p.velocity != 0
                       and case.discretization.advection == "upwind") else 2.0
    levels = case.validation.refinement_levels
    hs, errs, sols, sizes = [], [], [], []
    has_ref = None
    for k in range(levels + 1):
        mesh = build_mesh(case.geometry, scaled_mesh_spec(case, 2**k))
        system = assemble(case, mesh)
        if system.n > MAX_REFINEMENT_UNKNOWNS:
            log(f"refinement stopped at level {k}: {system.n} unknowns")
            break
        u = system.expand(classical_linear.solve_linear(system, "direct").u)
        ref = steady_reference(case, mesh)
        has_ref = ref is not None
        hs.append(mesh.h if isinstance(mesh, Mesh1D) else max(mesh.hx, mesh.hy))
        sizes.append(system.n)
        if has_ref:
            errs.append(error_metrics(u, ref, cell_volume(mesh))["l2_discrete"])
        sols.append(u)
    if has_ref:
        order, kind = observed_order(hs, errs), "error vs analytical reference"
    elif len(sols) >= 3:
        c, m_, f = sols[-3], sols[-2], sols[-1]
        if c.ndim == 1:
            order = self_convergence_order(c, m_[::2], f[::4])
        else:
            order = self_convergence_order(c, m_[::2, ::2], f[::4, ::4])
        kind = "self-convergence (three nested grids, no reference)"
    else:
        order, kind = float("nan"), "too few levels"
    log(f"refinement: {kind}, observed order {order:.3f}")
    return {"kind": kind, "h": hs, "unknowns": sizes, "l2_error": errs or None,
            "observed_order": order, "expected_order": expected}


def _error_budget(results: dict, comparison: dict | None, refinement: dict | None, case: Case) -> list[dict]:
    """Attribute differences to their source (spec section 9)."""
    out = []
    c = results.get("classical")
    if c and "metrics_vs_reference" in c:
        out.append({"source": "discretization", "magnitude": c["metrics_vs_reference"]["l2_relative"],
                    "note": "classical vs analytical; the algebraic error is negligible so this is truncation error"})
    elif refinement and refinement.get("observed_order") == refinement.get("observed_order"):
        out.append({"source": "discretization", "magnitude": None,
                    "note": "no reference: estimated only through the self-convergence order"})
    if c:
        out.append({"source": "classical solver tolerance", "magnitude": c["info"]["relative_residual"],
                    "note": "relative residual of the classical solve"})
    if comparison:
        q = results["quantum"]
        mode = q["info"]["cost_mode"]
        out.append({"source": "quantum approximation" + (" + sampling noise" if mode == "sampled" else ""),
                    "magnitude": comparison["metrics_quantum_vs_classical"]["l2_relative"],
                    "note": "quantum vs classical on the identical discrete system: ansatz expressivity, "
                            "optimiser convergence" + (", finite shots" if mode == "sampled" else "")})
        if mode == "sampled" or q["info"].get("readout_shots"):
            out.append({"source": "sampling noise", "magnitude": q["info"].get("sampled_cost_std"),
                        "note": "standard deviation of the sampled cost over 5 repeated estimates"})
    if "quantum" in results:
        out.append({"source": "hardware noise", "magnitude": None, "note": "not modelled (noiseless simulator)"})
    return out


# =========================================================================== transient
def _simulate_transient(case: Case, factor: int):
    """Run the transient model on the mesh refined by `factor`.
    Returns (TransientResult, coords, reference(t) or None, expected_order)."""
    p, g, t = case.physics, case.geometry, case.time
    mesh = build_mesh(g, scaled_mesh_spec(case, factor))
    scheme = case.scheme
    dt = t.dt / factor if t.dt else None

    if p.model == "heat_1d":
        x = mesh.x
        kw = dict(alpha=p.diffusivity, k=p.initial.k, amplitude=p.initial.amplitude, x0=g.origin, length=g.length)
        exact = lambda tt: ms.heat_sine_exact(x, tt, **kw)
        bcf = {b.boundary: b for b in p.bcs}
        def bc(side: str):
            b, xb = bcf[side], np.array([x[0] if side == "left" else x[-1]])
            return (lambda tt: float(ms.heat_sine_exact(xb, tt, **kw)[0])) if b.value == "exact" \
                else (lambda tt, v=float(b.value): v)
        # default dt ~ h of the base mesh, halved with every refinement so dt/h stays fixed
        dt = dt or min(t.t_end / 20, g.length / case.mesh.cells) / factor
        theta = 0.5 if scheme == "crank_nicolson" else 1.0
        res = classical_transient.heat_theta(x, exact(0.0), p.diffusivity, t.t_end, dt, bc("left"), bc("right"),
                                             theta=theta, n_snap=t.snapshots)
        has_ref = all(b.value == "exact" or b.value == 0.0 for b in p.bcs)
        return res, mesh, (exact if has_ref else None), (2.0 if theta == 0.5 else 1.0)

    if p.model == "burgers_1d":
        x = mesh.x
        ic = p.initial
        kw = dict(nu=p.viscosity, u_left=ic.u_left, u_right=ic.u_right, x_front=ic.x_front)
        exact = lambda tt: ms.burgers_tanh_exact(x, tt, **kw)
        bcf = {b.boundary: b for b in p.bcs}
        def bc(side: str):
            b, xb = bcf[side], np.array([x[0] if side == "left" else x[-1]])
            return (lambda tt: float(ms.burgers_tanh_exact(xb, tt, **kw)[0])) if b.value == "exact" \
                else (lambda tt, v=float(b.value): v)
        res = classical_transient.burgers(x, exact(0.0), p.viscosity, t.t_end, dt, bc("left"), bc("right"),
                                          method=scheme, cfl=t.cfl, n_snap=t.snapshots, rtol=1e-9)
        has_ref = all(b.value == "exact" for b in p.bcs)
        return res, mesh, (exact if has_ref else None), (2.0 if scheme == "mol_bdf" else 1.0)

    if p.model == "incompressible_ns_2d":
        n, L = mesh.nx, g.lx
        xs = g.origin[0] + np.arange(n) * L / n
        ys = g.origin[1] + np.arange(n) * L / n
        X, Y = np.meshgrid(xs, ys, indexing="xy")
        kw = dict(nu=p.viscosity, amplitude=p.initial.amplitude, length=L)
        def exact(tt):
            u, v, _ = ms.taylor_green_exact(X - g.origin[0], Y - g.origin[1], tt, **kw)
            return np.stack([u, v])
        u0 = exact(0.0)
        res = classical_transient.ns2d_projection(L, n, u0[0], u0[1], p.viscosity, t.t_end, cfl=t.cfl,
                                                  n_snap=t.snapshots)
        res.fields["uv"] = np.stack([res.fields["u"], res.fields["v"]], axis=1)
        return res, (xs, ys, L / n), exact, 2.0
    raise ValueError(p.model)


def _run_transient(case: Case, mesh, rf: RunFolder, log: Log) -> tuple[dict, list[dict]]:
    p, v = case.physics, case.validation
    checks: list[dict] = []
    log(f"time integration: {p.model} scheme={case.scheme} t_end={case.time.t_end}")
    res, m, exact, expected = _simulate_transient(case, 1)
    is_ns = p.model == "incompressible_ns_2d"
    key = "uv" if is_ns else "u"
    snaps = res.fields[key]
    vol = (m[2] ** 2) if is_ns else m.h
    log(f"done in {res.resources['runtime_s']:.3f} s, {res.info}")

    ref_snaps = np.array([exact(t) for t in res.times]) if exact else None
    results: dict[str, Any] = {"classical": {"method": case.scheme, "status": "implemented",
                                             "info": res.info, "resources": res.resources}}
    if ref_snaps is not None:
        final = error_metrics(snaps[-1], ref_snaps[-1], vol)
        history = [error_metrics(s, r)["l2_relative"] for s, r in zip(snaps[1:], ref_snaps[1:])]
        results["classical"]["metrics_vs_reference"] = final
        results["classical"]["error_history"] = {"t": res.times[1:].tolist(), "l2_relative": history}
        checks.append(tolerance_check("classical.reference_error", final["l2_relative"], v.reference_tolerance,
                                      "relative L2 error vs analytical reference at t_end"))
    else:
        checks.append(check("classical.reference_error", "not_applicable",
                            "boundary data differ from the analytical solution: no reference"))

    # ---- physical and stability checks
    info = res.info
    if p.model == "heat_1d":
        mx = np.abs(snaps).max(axis=1)
        mono = bool(np.all(np.diff(mx) <= 1e-12 * max(mx[0], 1)))
        checks.append(check("physics.maximum_principle", "passed" if mono else "failed",
                            "max |u| does not grow (homogeneous diffusion)", float(mx[-1])))
    if p.model == "burgers_1d":
        ic = p.initial
        lo, hi = min(ic.u_left, ic.u_right), max(ic.u_left, ic.u_right)
        over = float(max(snaps.max() - hi, lo - snaps.min(), 0) / max(hi - lo, 1e-12))
        checks.append(tolerance_check("physics.no_overshoot", over, 1e-2,
                                      "relative overshoot beyond the initial range", "warning"))
        checks.append(tolerance_check("stability.cell_reynolds", info["cell_reynolds"], 2.0,
                                      "cell Reynolds number |u|h/nu (central convection)", "warning"))
        if "cfl" in info:
            checks.append(tolerance_check("stability.cfl", info["cfl"], 1.0, "CFL number", "failed"))
    if is_ns:
        checks.append(tolerance_check("physics.divergence_free", info["max_divergence_final"], 1e-10,
                                      "max |div u| (discrete) at t_end"))
        ke = 0.5 * (snaps**2).sum(axis=(1, 2, 3)) * vol
        mono = bool(np.all(np.diff(ke) <= 1e-12 * ke[0]))
        checks.append(check("physics.energy_decay", "passed" if mono else "failed",
                            "kinetic energy decreases monotonically", float(ke[-1] / ke[0])))
        kk = 2 * np.pi / case.geometry.lx
        ke_exact = np.exp(-4 * p.viscosity * kk**2 * res.times)
        ke_err = float(np.max(np.abs(ke / ke[0] - ke_exact)))
        checks.append(tolerance_check("physics.energy_decay_rate", ke_err, 1e-2,
                                      "max |KE(t)/KE(0) - exp(-4 nu k^2 t)|", "warning"))
        results["classical"]["kinetic_energy"] = {"t": res.times.tolist(), "ke_ratio": (ke / ke[0]).tolist(),
                                                  "ke_ratio_exact": ke_exact.tolist()}
        checks.append(tolerance_check("stability.cfl", info["cfl"], 1.0, "CFL number"))

    # ---- refinement (space with dt scaled consistently)
    refinement = None
    if v.refinement_levels and exact:
        hs, errs = [], []
        for k in range(v.refinement_levels + 1):
            r_k, m_k, ex_k, _ = _simulate_transient(case, 2**k)
            h_k = m_k[2] if is_ns else m_k.h
            e = error_metrics(r_k.fields[key][-1], ex_k(r_k.times[-1]), h_k**2 if is_ns else h_k)
            hs.append(h_k); errs.append(e["l2_discrete"])
        order = observed_order(hs, errs)
        refinement = {"kind": "space and time refined together (dt ~ h)", "h": hs, "l2_error": errs,
                      "observed_order": order, "expected_order": expected}
        log(f"refinement observed order {order:.3f} (expected {expected})")
        checks.append(order_check("classical.convergence_order", order, expected, v.order_tolerance,
                                  refinement["kind"]))

    if case.solver.mode in ("quantum", "both"):  # guarded by check_case; kept for direct API use
        checks.append(check("quantum.formulation", "not_applicable", "quantum formulation planned for this model"))

    kind = "ns_2d" if is_ns else "transient_1d"
    rf.save_array("fields/times", res.times)
    if is_ns:
        xs, ys, _ = m
        rf.save_array("fields/x", xs); rf.save_array("fields/y", ys)
    else:
        rf.save_array("fields/x", m.x)
    rf.save_array("fields/classical_snapshots", snaps)
    if ref_snaps is not None:
        rf.save_array("fields/reference_snapshots", ref_snaps)
    rf.write_json("fields/manifest.json", {"kind": kind, "snapshots": int(len(res.times))})
    summary = {"kind": kind, "results": results, "comparison": None, "refinement": refinement,
               "error_budget": _transient_budget(results)}
    return summary, checks


def _transient_budget(results: dict) -> list[dict]:
    c = results["classical"]
    if "metrics_vs_reference" not in c:
        return []
    return [{"source": "discretization (space + time)", "magnitude": c["metrics_vs_reference"]["l2_relative"],
             "note": f"scheme {c['method']}; see the refinement study for the split between h and dt"}]


def _save_fields(rf: RunFolder, mesh, fields: dict[str, np.ndarray], kind: str) -> None:
    if isinstance(mesh, Mesh1D):
        rf.save_array("fields/x", mesh.x)
    else:
        rf.save_array("fields/x", mesh.x); rf.save_array("fields/y", mesh.y)
    for name, arr in fields.items():
        rf.save_array(f"fields/{name}", arr)
    rf.write_json("fields/manifest.json", {"kind": kind, "fields": sorted(fields)})


# =========================================================================== entry point
def run_case(case: Case, project: Project, *, case_text: str | None = None, log: Log | None = None,
             make_report: bool = True) -> RunOutcome:
    issues = check_case(case)
    errors = [i for i in issues if i.level == "error"]
    if errors:
        raise CaseError(errors)

    rf = project.new_run(case.name)
    echo = log or (lambda s: None)

    def logf(msg: str) -> None:
        rf.log(msg); echo(msg)

    started = time.perf_counter()
    rf.write_json("case.resolved.json", case.model_dump(mode="json"))
    if case_text is not None:
        rf.write_text("case.toml", case_text)
    rf.write_json("environment.json", environment())
    logf(f"run {rf.run_id} started: case '{case.name}', model {case.physics.model}, qcfd {__version__}")

    status = "failed"
    summary: dict = {}
    checks: list[dict] = []
    try:
        est = estimate(case)
        rf.write_json("setup.json", {"issues": [i.__dict__ for i in issues], "estimate": est})
        checks += [check(f"setup.{i.path}", "warning", i.message + (f" ({i.fix})" if i.fix else ""))
                   for i in issues]
        mesh = build_mesh(case.geometry, case.mesh)
        rf.write_json("mesh.json", mesh.summary())
        checks += quality(mesh)
        logf(f"mesh {mesh.summary()}")
        if case.physics.steady:
            summary, more = _run_steady(case, mesh, rf, logf)
        else:
            summary, more = _run_transient(case, mesh, rf, logf)
        checks += more
        summary.update({"run_id": rf.run_id, "case": case.name, "model": case.physics.model,
                        "mesh": mesh.summary(), "estimate": est, "wall_time_s": time.perf_counter() - started,
                        "finished_at": utcnow()})
        status = "completed_with_failures" if any(c["status"] == "failed" for c in checks) else "completed"
    except Exception as exc:  # recorded, then re-raised after the run folder is sealed
        logf("ERROR " + "".join(traceback.format_exception(exc)))
        summary = {"run_id": rf.run_id, "case": case.name, "error": f"{type(exc).__name__}: {exc}"}
        rf.write_json("results.json", {**summary, "status": status})
        rf.write_json("validation.json", checks)
        rf.finalize()
        project.index_run({"run_id": rf.run_id, "case": case.name, "model": case.physics.model,
                           "status": status, "finished_at": utcnow()})
        raise

    summary["status"] = status
    rf.write_json("results.json", summary)
    rf.write_json("validation.json", checks)
    if make_report:
        from ..report.builder import build_report
        build_report(rf, formats=case.output.reports, csv=case.output.csv)
        logf(f"report written: {', '.join(case.output.reports)}")
    logf(f"run finished: {status}")
    rf.finalize()
    project.index_run({"run_id": rf.run_id, "case": case.name, "model": case.physics.model, "status": status,
                       "mode": case.solver.mode, "finished_at": utcnow(),
                       "checks": {s: sum(c["status"] == s for c in checks)
                                  for s in ("passed", "warning", "failed", "not_applicable")}})
    return RunOutcome(rf.run_id, rf.path, status, summary, checks)
