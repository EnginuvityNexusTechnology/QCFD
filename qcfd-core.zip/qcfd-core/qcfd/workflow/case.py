"""Case definition (one simulation set-up) and setup validation.

A case is a TOML file: geometry -> physics (+BCs) -> mesh -> discretization ->
solver(s) -> time -> validation -> output. Structural errors are reported by
pydantic with their path; `check_case` adds the physics/compatibility rules and
says how to fix each problem.
"""

from __future__ import annotations

import tomllib
from dataclasses import dataclass
from pathlib import Path
from typing import Literal

from pydantic import BaseModel, ConfigDict, Field, ValidationError

from ..model.geometry import Geometry, Interval, Rectangle
from ..model.manufactured import MANUFACTURED_1D, MANUFACTURED_2D
from ..model.mesh import MeshSpec, MeshSpec1D, MeshSpec2D
from ..model.physics import MODEL_DIM, ManufacturedSource, Physics
from ..quantum.vqls import MAX_QUBITS


class _Strict(BaseModel):
    model_config = ConfigDict(extra="forbid")


class ClassicalCfg(_Strict):
    method: Literal["direct", "cg", "gmres"] = "direct"
    rtol: float = Field(1e-10, gt=0)


class QuantumCfg(_Strict):
    method: Literal["vqls"] = "vqls"
    layers: int | None = Field(None, ge=1, le=20, description="default: qubits + 1")
    cost_mode: Literal["exact", "sampled"] = "exact"
    optimizer: Literal["lbfgs", "spsa"] = "lbfgs"
    shots: int = Field(10_000, ge=100, le=10**8)
    readout_shots: int | None = Field(None, ge=100, le=10**9)
    restarts: int = Field(3, ge=1, le=20)
    maxiter: int = Field(1000, ge=10, le=100_000)
    seed: int = 1234
    convergence_threshold: float = Field(1e-6, gt=0)


class SolverCfg(_Strict):
    mode: Literal["classical", "quantum", "both"] = "classical"
    classical: ClassicalCfg = ClassicalCfg()
    quantum: QuantumCfg = QuantumCfg()


class DiscretizationCfg(_Strict):
    advection: Literal["central", "upwind"] = "central"


TimeScheme = Literal["crank_nicolson", "implicit_euler", "mol_bdf", "imex_euler", "ssp_rk3_projection"]
DEFAULT_SCHEME = {"heat_1d": "crank_nicolson", "burgers_1d": "mol_bdf", "incompressible_ns_2d": "ssp_rk3_projection"}
ALLOWED_SCHEMES = {"heat_1d": {"crank_nicolson", "implicit_euler"}, "burgers_1d": {"mol_bdf", "imex_euler"},
                   "incompressible_ns_2d": {"ssp_rk3_projection"}}


class TimeCfg(_Strict):
    t_end: float = Field(gt=0)
    dt: float | None = Field(None, gt=0, description="fixed step; default chosen from stability/accuracy")
    scheme: TimeScheme | None = None
    snapshots: int = Field(11, ge=2, le=1000)
    cfl: float = Field(0.4, gt=0, le=1.0)


class ValidationCfg(_Strict):
    refinement_levels: int = Field(3, ge=0, le=6, description="0 disables the grid-refinement study")
    reference_tolerance: float = Field(5e-2, gt=0, description="max relative L2 error vs analytical reference")
    comparison_tolerance: float = Field(1e-3, gt=0, description="max relative L2 quantum vs classical")
    order_tolerance: float = Field(0.25, gt=0, description="allowed deviation of observed from expected order")


class OutputCfg(_Strict):
    reports: list[Literal["html", "md", "pdf"]] = ["html", "md"]
    csv: bool = True


class Case(_Strict):
    name: str = Field(min_length=1, max_length=120)
    description: str = ""
    geometry: Geometry
    physics: Physics
    mesh: MeshSpec
    discretization: DiscretizationCfg = DiscretizationCfg()
    solver: SolverCfg = SolverCfg()
    time: TimeCfg | None = None
    validation: ValidationCfg = ValidationCfg()
    output: OutputCfg = OutputCfg()

    @property
    def scheme(self) -> str | None:
        if self.time is None:
            return None
        return self.time.scheme or DEFAULT_SCHEME.get(self.physics.model)


@dataclass
class Issue:
    level: Literal["error", "warning"]
    path: str
    message: str
    fix: str = ""

    def __str__(self) -> str:
        s = f"[{self.level.upper()}] {self.path}: {self.message}"
        return s + (f"  -> {self.fix}" if self.fix else "")


class CaseError(Exception):
    def __init__(self, issues: list[Issue]):
        self.issues = issues
        super().__init__("\n".join(map(str, issues)))


def load_case(path: str | Path) -> Case:
    data = tomllib.loads(Path(path).read_text())
    return parse_case(data)


def parse_case(data: dict) -> Case:
    try:
        return Case.model_validate(data)
    except ValidationError as e:
        raise CaseError([Issue("error", ".".join(map(str, err["loc"])) or "<root>", err["msg"])
                         for err in e.errors()]) from None


def unknown_count(case: Case) -> int:
    m, p = case.mesh, case.physics
    if isinstance(m, MeshSpec1D):
        n = m.cells + 1
        n -= sum(1 for b in p.bcs if b.type == "dirichlet")
        return n
    return (m.nx - 1) * (m.ny - 1)


def check_case(case: Case) -> list[Issue]:
    """Physics and compatibility rules beyond the schema. Errors block a run."""
    out: list[Issue] = []
    p, g = case.physics, case.geometry
    E = lambda path, msg, fix="": out.append(Issue("error", path, msg, fix))
    W = lambda path, msg, fix="": out.append(Issue("warning", path, msg, fix))

    if MODEL_DIM[p.model] != g.dim:
        E("physics.model", f"{p.model} is {MODEL_DIM[p.model]}D but the geometry is {g.dim}D",
          "use an interval for 1D models and a rectangle for 2D models")
    if (g.dim == 1) != isinstance(case.mesh, MeshSpec1D):
        E("mesh.kind", "mesh kind does not match the geometry", "use uniform_1d for intervals, uniform_2d for rectangles")

    # ---- boundary conditions
    names = [b.boundary for b in p.bcs]
    for b in g.boundaries:
        if names.count(b) != 1:
            E("physics.bcs", f"boundary '{b}' needs exactly one condition (found {names.count(b)})")
    for i, b in enumerate(p.bcs):
        if b.boundary not in g.boundaries:
            E(f"physics.bcs.{i}.boundary", f"unknown boundary '{b.boundary}'", f"valid: {', '.join(g.boundaries)}")
    types = {b.type for b in p.bcs}
    if p.model == "incompressible_ns_2d":
        if types != {"periodic"}:
            E("physics.bcs", "incompressible_ns_2d (V1) requires periodic boundaries on all sides",
              "wall boundaries are planned work")
        if isinstance(g, Rectangle) and abs(g.lx - g.ly) > 1e-12 * g.lx:
            E("geometry", "Taylor-Green set-up requires a square box (lx == ly)")
        if isinstance(case.mesh, MeshSpec2D) and case.mesh.nx != case.mesh.ny:
            E("mesh", "periodic NS solver requires nx == ny")
    else:
        if "periodic" in types:
            E("physics.bcs", f"periodic boundaries are not implemented for {p.model}")
        if p.model in ("poisson_2d", "heat_1d", "burgers_1d") and "neumann" in types:
            E("physics.bcs", f"Neumann conditions are implemented for steady_transport_1d only ({p.model}: planned)")
        if p.model == "steady_transport_1d" and types == {"neumann"} and p.reaction == 0:
            E("physics.bcs", "pure Neumann problem without reaction is singular",
              "set one boundary to dirichlet, or reaction > 0")

    uses_exact = any(b.value == "exact" for b in p.bcs)
    if p.model in ("steady_transport_1d", "poisson_2d"):
        src = p.source
        if isinstance(src, ManufacturedSource):
            valid = MANUFACTURED_1D if g.dim == 1 else MANUFACTURED_2D
            if src.name not in valid:
                E("physics.source.name", f"unknown manufactured solution '{src.name}'", f"valid: {', '.join(valid)}")
        elif uses_exact:
            E("physics.bcs", "value = \"exact\" needs a manufactured source to take values from",
              "give numeric values or use a manufactured source")

    # ---- time
    if p.steady and case.time is not None:
        W("time", f"{p.model} is steady; the [time] section is ignored")
    if not p.steady:
        if case.time is None:
            E("time", f"{p.model} is transient and needs a [time] section with t_end")
        elif case.scheme not in ALLOWED_SCHEMES[p.model]:
            E("time.scheme", f"'{case.scheme}' is not available for {p.model}",
              f"valid: {', '.join(sorted(ALLOWED_SCHEMES[p.model]))}")

    # ---- discretization quality
    if p.model == "steady_transport_1d" and isinstance(case.mesh, MeshSpec1D) and isinstance(g, Interval):
        h = g.length / case.mesh.cells
        pe = abs(p.velocity) * h / (2 * p.diffusivity)
        if pe > 1 and case.discretization.advection == "central":
            W("discretization.advection", f"cell Peclet number {pe:.2f} > 1: central differences may oscillate",
              "refine the mesh or use advection = \"upwind\" (first order)")
    if p.model == "burgers_1d" and isinstance(case.mesh, MeshSpec1D) and isinstance(g, Interval):
        ic = p.initial
        re_h = max(abs(ic.u_left), abs(ic.u_right)) * g.length / case.mesh.cells / p.viscosity
        if re_h > 2:
            W("mesh.cells", f"cell Reynolds number {re_h:.2f} > 2: central convection may oscillate", "refine the mesh")

    # ---- solvers
    mode = case.solver.mode
    if mode in ("quantum", "both"):
        if not (p.steady and p.linear):
            E("solver.mode", f"the quantum formulation is implemented for steady linear models only ({p.model}: planned)",
              "set solver.mode = \"classical\"")
        else:
            n = unknown_count(case)
            q = max(1, (n - 1).bit_length())
            if q > MAX_QUBITS:
                E("mesh", f"{n} unknowns need {q} qubits; local simulation is capped at {MAX_QUBITS}",
                  "coarsen the mesh for the quantum run")
            elif q > 6:
                W("mesh", f"{q} qubits: VQLS training on a CPU may take many minutes")
        qc = case.solver.quantum
        if qc.cost_mode == "sampled" and qc.optimizer == "lbfgs":
            E("solver.quantum.optimizer", "L-BFGS needs a deterministic cost", "use optimizer = \"spsa\" with sampled cost")
    if mode in ("classical", "both") and case.solver.classical.method == "cg":
        if p.model == "steady_transport_1d" and p.velocity != 0:
            E("solver.classical.method", "CG requires a symmetric operator; advection makes it non-symmetric",
              "use gmres or direct")
    if not p.steady and case.solver.classical.method != "direct":
        W("solver.classical.method", "transient schemes use their own internal solvers; this setting is ignored")
    return out
