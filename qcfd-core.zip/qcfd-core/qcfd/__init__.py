"""QuantumCFD Simulator — simulation core (classical + quantum CFD, offline)."""

__version__ = "0.2.0"
