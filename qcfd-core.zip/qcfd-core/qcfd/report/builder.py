"""Reports built purely from a run folder, so they can be regenerated at any time
(`qcfd report <run>`) and always reflect exactly what was stored."""

from __future__ import annotations

import base64
import html
import json
from pathlib import Path
from typing import Any

import numpy as np

from ..workflow.capabilities import CAPABILITIES
from ..workflow.storage import RunFolder

COLORS = {"reference": "#1f2933", "classical": "#2563eb", "quantum": "#d97706", "diff": "#7c3aed"}


# ------------------------------------------------------------------ figures
def _plt():
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    plt.rcParams.update({"figure.dpi": 110, "font.size": 9, "axes.grid": True, "grid.alpha": 0.3,
                         "axes.spines.top": False, "axes.spines.right": False})
    return plt


def _refinement_fig(plt, ref: dict):
    if not ref or not ref.get("l2_error"):
        return None
    fig, ax = plt.subplots(figsize=(5, 3.6))
    h, e = np.array(ref["h"]), np.array(ref["l2_error"])
    ax.loglog(h, e, "o-", color=COLORS["classical"], label="observed")
    p = ref["expected_order"]
    ax.loglog(h, e[0] * (h / h[0]) ** p, "--", color="0.5", label=f"slope {p:g}")
    ax.set_xlabel("h"); ax.set_ylabel("discrete L2 error")
    ax.set_title(f"Grid refinement: observed order {ref['observed_order']:.2f}")
    ax.legend()
    return fig


def make_figures(rf: RunFolder) -> list[tuple[str, str]]:
    """Write figures/*.png; return [(file, caption)]."""
    plt = _plt()
    res = rf.read_json("results.json")
    man = rf.read_json("fields/manifest.json")
    kind = man["kind"]
    out: list[tuple[str, Any, str]] = []
    has = lambda n: (rf.path / f"fields/{n}.npy").exists()

    if kind == "steady_1d":
        x = rf.load_array("fields/x")
        fig, ax = plt.subplots(figsize=(6.4, 3.6))
        if has("reference"):
            xf = np.linspace(x[0], x[-1], 400)
            ax.plot(x, rf.load_array("fields/reference"), "-", color=COLORS["reference"], label="analytical", lw=1.5)
        if has("classical"):
            ax.plot(x, rf.load_array("fields/classical"), "o", color=COLORS["classical"], ms=4, label="classical FD")
        if has("quantum"):
            ax.plot(x, rf.load_array("fields/quantum"), "x", color=COLORS["quantum"], ms=6, label="quantum (VQLS)")
        ax.set_xlabel("x"); ax.set_ylabel("u"); ax.legend(); ax.set_title("Solution")
        out.append(("solution.png", fig, "Nodal solution: analytical reference, classical and quantum results."))
        if has("classical") and (has("reference") or has("quantum")):
            fig, ax = plt.subplots(figsize=(6.4, 3.2))
            c = rf.load_array("fields/classical")
            if has("reference"):
                ax.semilogy(x, np.abs(c - rf.load_array("fields/reference")) + 1e-18, "-o", ms=3,
                            color=COLORS["classical"], label="|classical - analytical|")
            if has("quantum"):
                ax.semilogy(x, np.abs(rf.load_array("fields/quantum") - c) + 1e-18, "-x", ms=4,
                            color=COLORS["quantum"], label="|quantum - classical|")
            ax.set_xlabel("x"); ax.set_ylabel("pointwise difference"); ax.legend(); ax.set_title("Error")
            out.append(("error.png", fig, "Pointwise discretization error and quantum-classical difference (log scale)."))

    elif kind == "steady_2d":
        x, y = rf.load_array("fields/x"), rf.load_array("fields/y")
        X, Y = np.meshgrid(x, y)
        panels = []
        main = "classical" if has("classical") else "quantum"
        panels.append((f"{main} solution", rf.load_array(f"fields/{main}"), "viridis"))
        if has("reference"):
            panels.append(("classical - analytical" if main == "classical" else "quantum - analytical",
                           rf.load_array(f"fields/{main}") - rf.load_array("fields/reference"), "coolwarm"))
        if has("quantum") and has("classical"):
            panels.append(("quantum - classical", rf.load_array("fields/quantum") - rf.load_array("fields/classical"),
                           "coolwarm"))
        fig, axes = plt.subplots(1, len(panels), figsize=(4.2 * len(panels), 3.6), squeeze=False)
        for ax, (title, Z, cmap) in zip(axes[0], panels):
            if cmap == "coolwarm":
                vmax = float(np.abs(Z).max()) or 1.0
                im = ax.pcolormesh(X, Y, Z, cmap=cmap, vmin=-vmax, vmax=vmax, shading="auto")
            else:
                im = ax.pcolormesh(X, Y, Z, cmap=cmap, shading="auto")
            ax.set_aspect("equal"); ax.set_title(title); ax.grid(False)
            fig.colorbar(im, ax=ax, shrink=0.85, format="%.2e" if cmap == "coolwarm" else None)
        fig.tight_layout()
        out.append(("fields.png", fig, "Solution field and difference fields on the structured mesh."))

    elif kind == "transient_1d":
        x, t = rf.load_array("fields/x"), rf.load_array("fields/times")
        S = rf.load_array("fields/classical_snapshots")
        R = rf.load_array("fields/reference_snapshots") if has("reference_snapshots") else None
        fig, ax = plt.subplots(figsize=(6.4, 3.6))
        cmap = plt.get_cmap("Blues")
        for i in range(len(t)):
            ax.plot(x, S[i], color=cmap(0.3 + 0.7 * i / max(len(t) - 1, 1)), lw=1.2)
            if R is not None:
                ax.plot(x, R[i], "--", color=COLORS["reference"], lw=0.7)
        ax.set_xlabel("x"); ax.set_ylabel("u"); ax.set_title(f"Snapshots t = 0 ... {t[-1]:g} (dashed: analytical)")
        out.append(("snapshots.png", fig, "Solution snapshots in time (light to dark), analytical solution dashed."))
        eh = res["results"]["classical"].get("error_history")
        if eh:
            fig, ax = plt.subplots(figsize=(6.4, 3.0))
            ax.semilogy(eh["t"], eh["l2_relative"], "o-", color=COLORS["classical"], ms=3)
            ax.set_xlabel("t"); ax.set_ylabel("relative L2 error"); ax.set_title("Error history")
            out.append(("error_history.png", fig, "Relative L2 error against the analytical solution over time."))

    elif kind == "ns_2d":
        x, y = rf.load_array("fields/x"), rf.load_array("fields/y")
        S = rf.load_array("fields/classical_snapshots")
        u, v = S[-1, 0], S[-1, 1]
        h = x[1] - x[0]
        w = (np.roll(v, -1, 1) - np.roll(v, 1, 1)) / (2 * h) - (np.roll(u, -1, 0) - np.roll(u, 1, 0)) / (2 * h)
        X, Y = np.meshgrid(x, y)
        fig, axes = plt.subplots(1, 2, figsize=(8.6, 3.8))
        im = axes[0].pcolormesh(X, Y, np.hypot(u, v), cmap="viridis", shading="auto")
        step = max(1, len(x) // 16)
        axes[0].quiver(X[::step, ::step], Y[::step, ::step], u[::step, ::step], v[::step, ::step], color="w")
        axes[0].set_title("|u| and velocity at t_end"); fig.colorbar(im, ax=axes[0], shrink=0.85)
        vm = float(np.abs(w).max()) or 1
        im = axes[1].pcolormesh(X, Y, w, cmap="RdBu_r", vmin=-vm, vmax=vm, shading="auto")
        axes[1].set_title("vorticity at t_end"); fig.colorbar(im, ax=axes[1], shrink=0.85)
        for a in axes:
            a.set_aspect("equal"); a.grid(False)
        fig.tight_layout()
        out.append(("flow.png", fig, "Velocity magnitude, vectors and vorticity at the final time."))
        ke = res["results"]["classical"].get("kinetic_energy")
        if ke:
            fig, ax = plt.subplots(figsize=(6.4, 3.0))
            ax.plot(ke["t"], ke["ke_ratio_exact"], "-", color=COLORS["reference"], label="exact exp(-4 nu k^2 t)")
            ax.plot(ke["t"], ke["ke_ratio"], "o", color=COLORS["classical"], ms=4, label="computed")
            ax.set_xlabel("t"); ax.set_ylabel("KE / KE(0)"); ax.legend(); ax.set_title("Kinetic-energy decay")
            out.append(("energy.png", fig, "Kinetic-energy decay against the exact Taylor-Green rate."))

    fig = _refinement_fig(plt, res.get("refinement"))
    if fig is not None:
        out.append(("refinement.png", fig, "Grid-refinement study on log-log axes with the expected slope."))

    files = []
    for name, fig, cap in out:
        fig.savefig(rf.file(f"figures/{name}"), bbox_inches="tight")
        plt.close(fig)
        files.append((name, cap))
    return files


# ------------------------------------------------------------------ CSV
def write_csv(rf: RunFolder) -> Path:
    man = rf.read_json("fields/manifest.json")
    has = lambda n: (rf.path / f"fields/{n}.npy").exists()
    kind = man["kind"]
    if kind == "steady_1d":
        cols = {"x": rf.load_array("fields/x")}
        for n in ("reference", "classical", "quantum"):
            if has(n):
                cols[n] = rf.load_array(f"fields/{n}")
    elif kind == "steady_2d":
        X, Y = np.meshgrid(rf.load_array("fields/x"), rf.load_array("fields/y"))
        cols = {"x": X.ravel(), "y": Y.ravel()}
        for n in ("reference", "classical", "quantum"):
            if has(n):
                cols[n] = rf.load_array(f"fields/{n}").ravel()
    elif kind == "transient_1d":
        x, t = rf.load_array("fields/x"), rf.load_array("fields/times")
        S = rf.load_array("fields/classical_snapshots")
        T, Xg = np.meshgrid(t, x, indexing="ij")
        cols = {"t": T.ravel(), "x": Xg.ravel(), "classical": S.ravel()}
        if has("reference_snapshots"):
            cols["reference"] = rf.load_array("fields/reference_snapshots").ravel()
    else:
        X, Y = np.meshgrid(rf.load_array("fields/x"), rf.load_array("fields/y"))
        S = rf.load_array("fields/classical_snapshots")[-1]
        cols = {"x": X.ravel(), "y": Y.ravel(), "u": S[0].ravel(), "v": S[1].ravel()}
        if has("reference_snapshots"):
            R = rf.load_array("fields/reference_snapshots")[-1]
            cols.update({"u_reference": R[0].ravel(), "v_reference": R[1].ravel()})
    p = rf.file("fields.csv")
    np.savetxt(p, np.column_stack(list(cols.values())), delimiter=",", header=",".join(cols), comments="",
               fmt="%.12g")
    return p


# ------------------------------------------------------------------ content model
def _fmt(v: Any) -> str:
    if v is None:
        return "—"
    if isinstance(v, bool):
        return "yes" if v else "no"
    if isinstance(v, int):
        return f"{v:,}"
    if isinstance(v, float):
        if v != v:
            return "n/a"
        return f"{v:.3e}" if (abs(v) < 1e-3 and v != 0) or abs(v) >= 1e5 else f"{v:.4g}"
    if isinstance(v, (dict, list)):
        return json.dumps(v, default=str)[:160]
    return str(v)


def _sections(rf: RunFolder) -> dict[str, Any]:
    res, checks = rf.read_json("results.json"), rf.read_json("validation.json")
    case = rf.read_json("case.resolved.json")
    env = rf.read_json("environment.json")
    setup = rf.read_json("setup.json") if (rf.path / "setup.json").exists() else {}
    system = rf.read_json("system/system.json") if (rf.path / "system/system.json").exists() else None
    counts = {s: sum(c["status"] == s for c in checks) for s in ("passed", "warning", "failed", "not_applicable")}

    phys = case["physics"]
    setup_rows = [("Model", phys["model"]), ("Geometry", _fmt({k: v for k, v in case["geometry"].items()})),
                  ("Mesh", _fmt(res.get("mesh"))),
                  ("Boundary conditions", "; ".join(
                      f"{b['boundary']}: {b['type']}" + ("" if b["type"] == "periodic" else f" = {b['value']}")
                      for b in phys["bcs"]))]
    for k in ("diffusivity", "velocity", "reaction", "viscosity"):
        if k in phys:
            setup_rows.append((k.capitalize(), _fmt(phys[k])))
    if "source" in phys:
        setup_rows.append(("Source", _fmt(phys["source"])))
    if "initial" in phys:
        setup_rows.append(("Initial condition", _fmt(phys["initial"])))
    if case.get("time"):
        setup_rows.append(("Time", _fmt(case["time"])))
    setup_rows.append(("Solver mode", case["solver"]["mode"]))
    if case["physics"]["model"] in ("steady_transport_1d", "poisson_2d"):
        setup_rows.append(("Advection scheme", case["discretization"]["advection"]))

    metric_rows = []
    for name, r in res.get("results", {}).items():
        if "metrics_vs_reference" in r:
            metric_rows.append((f"{name} vs analytical", r["metrics_vs_reference"]))
    if res.get("comparison"):
        metric_rows.append(("quantum vs classical", res["comparison"]["metrics_quantum_vs_classical"]))

    solver_rows = []
    for name, r in res.get("results", {}).items():
        solver_rows.append((name, r["method"], r.get("status", ""), r.get("limitations", "")))

    resources = []
    for name, r in res.get("results", {}).items():
        for k, v in r.get("resources", {}).items():
            resources.append((name, k, _fmt(v)))
    for k, v in (res.get("estimate") or {}).items():
        if k not in ("quantum",):
            resources.append(("estimate", k, _fmt(v)))

    q = res.get("results", {}).get("quantum")
    q_rows = [(k, _fmt(v)) for k, v in q["info"].items() if k not in ("spsa_history",)] if q else []

    trace = [("Run ID", res.get("run_id")), ("Status", res.get("status")), ("Finished", res.get("finished_at")),
             ("Wall time [s]", _fmt(res.get("wall_time_s")))]
    if system:
        trace.append(("System fingerprint (A, b)", system.get("fingerprint")))
    if q:
        trace.append(("Quantum seed", q["info"].get("seed")))
    trace += [(k, v) for k, v in env.items()]
    trace.append(("Integrity", "SHA-256 of every file in checksums.json (verify with `qcfd verify`)"))

    used = {"quantum"} if q else set()
    caps = [c for c in CAPABILITIES if c["status"] != "implemented" and
            (c["area"] in used or c["area"] in ("physics", "geometry", "mesh"))]
    return {"res": res, "checks": checks, "counts": counts, "setup_rows": setup_rows, "metric_rows": metric_rows,
            "solver_rows": solver_rows, "resources": resources, "q_rows": q_rows, "trace": trace,
            "issues": setup.get("issues", []), "budget": res.get("error_budget") or [], "case": case,
            "refinement": res.get("refinement"), "caps": caps}


METRIC_KEYS = ("max_abs", "max_relative", "l2_relative", "rmse")


# ------------------------------------------------------------------ Markdown
def write_markdown(rf: RunFolder, figs: list[tuple[str, str]], s: dict) -> Path:
    res, L = s["res"], []
    L += [f"# Simulation report — {res.get('case')}", "",
          f"Run `{res.get('run_id')}` · status **{res.get('status')}** · checks: "
          + ", ".join(f"{v} {k.replace('_', ' ')}" for k, v in s["counts"].items()), ""]
    L += ["## Set-up", "", "| Item | Value |", "| --- | --- |"] + [f"| {a} | {b} |" for a, b in s["setup_rows"]] + [""]
    L += ["## Solvers", "", "| Role | Method | Status | Known limitations |", "| --- | --- | --- | --- |"]
    L += [f"| {a} | {b} | {c} | {d} |" for a, b, c, d in s["solver_rows"]] + [""]
    if s["metric_rows"]:
        L += ["## Error metrics", "", "| Comparison | " + " | ".join(METRIC_KEYS) + " |",
              "| --- |" + " --- |" * len(METRIC_KEYS)]
        L += [f"| {n} | " + " | ".join(_fmt(m.get(k)) for k in METRIC_KEYS) + " |" for n, m in s["metric_rows"]]
        L += [""]
    if s["budget"]:
        L += ["## Where the differences come from", "", "| Source | Magnitude | Note |", "| --- | --- | --- |"]
        L += [f"| {b['source']} | {_fmt(b['magnitude'])} | {b['note']} |" for b in s["budget"]] + [""]
    L += ["## Validation", "", "| Check | Status | Value | Criterion |", "| --- | --- | --- | --- |"]
    L += [f"| {c['name']} | {c['status']} | {_fmt(c['value'])} | {c['detail']} |" for c in s["checks"]] + [""]
    for f, cap in figs:
        L += [f"![{cap}](figures/{f})", "", f"*{cap}*", ""]
    if s["q_rows"]:
        L += ["## Quantum run details", "", "| Item | Value |", "| --- | --- |"]
        L += [f"| {a} | {b} |" for a, b in s["q_rows"]] + [""]
    L += ["## Resources", "", "| Scope | Item | Value |", "| --- | --- | --- |"]
    L += [f"| {a} | {b} | {c} |" for a, b, c in s["resources"]] + [""]
    L += ["## Known limitations (feature status)", ""] + [f"- **{c['status']}** — {c['area']}: {c['feature']}"
                                                         for c in s["caps"]] + [""]
    L += ["## Traceability", "", "| Item | Value |", "| --- | --- |"] + [f"| {a} | {b} |" for a, b in s["trace"]]
    p = rf.file("report.md")
    p.write_text("\n".join(L) + "\n")
    return p


# ------------------------------------------------------------------ HTML
_CSS = """body{font:14px/1.5 system-ui,Segoe UI,sans-serif;color:#1f2933;max-width:1040px;margin:24px auto;padding:0 20px}
h1{font-size:22px}h2{font-size:16px;margin-top:28px;border-bottom:1px solid #d5d9de;padding-bottom:4px}
table{border-collapse:collapse;width:100%;font-size:13px;margin:8px 0}th,td{text-align:left;padding:5px 8px;border-bottom:1px solid #e5e7eb;vertical-align:top}
th{color:#6b7680;font-weight:600}.chip{padding:1px 8px;border-radius:10px;font-size:11px;background:#eef0f2}
.passed{background:#e7f3ec;color:#15803d}.warning{background:#fdf3e2;color:#b45309}.failed{background:#fbe9e9;color:#b91c1c}
.completed{color:#15803d}.completed_with_failures,.failed-run{color:#b91c1c}figure{margin:16px 0}img{max-width:100%}
figcaption{color:#6b7680;font-size:12px}.muted{color:#6b7680}code{font-size:12px}pre{background:#f6f7f9;padding:10px;overflow:auto;font-size:12px}"""


def _table(head: list[str], rows: list[tuple]) -> str:
    h = "".join(f"<th>{html.escape(x)}</th>" for x in head)
    b = "".join("<tr>" + "".join(f"<td>{c}</td>" for c in r) + "</tr>" for r in rows)
    return f"<table><thead><tr>{h}</tr></thead><tbody>{b}</tbody></table>"


def write_html(rf: RunFolder, figs: list[tuple[str, str]], s: dict) -> Path:
    e = lambda v: html.escape(_fmt(v) if not isinstance(v, str) else v)
    res = s["res"]
    parts = [f"<h1>Simulation report — {e(res.get('case'))}</h1>",
             f"<p>Run <code>{e(res.get('run_id'))}</code> · status <b class='{e(res.get('status'))}'>{e(res.get('status'))}</b> · "
             + " · ".join(f"<span class='chip {k}'>{v} {k.replace('_', ' ')}</span>" for k, v in s["counts"].items())
             + "</p>"]
    parts += ["<h2>Set-up</h2>", _table(["Item", "Value"], [(e(a), e(b)) for a, b in s["setup_rows"]])]
    if s["issues"]:
        parts += ["<p class='muted'>Setup warnings: " + "; ".join(e(i["message"]) for i in s["issues"]) + "</p>"]
    parts += ["<h2>Solvers</h2>", _table(["Role", "Method", "Status", "Known limitations"],
                                         [tuple(e(x) for x in r) for r in s["solver_rows"]])]
    if s["metric_rows"]:
        parts += ["<h2>Error metrics</h2>", _table(["Comparison", *METRIC_KEYS],
                  [(e(n), *(e(m.get(k)) for k in METRIC_KEYS)) for n, m in s["metric_rows"]])]
    if s["budget"]:
        parts += ["<h2>Where the differences come from</h2>",
                  _table(["Source", "Magnitude", "Note"], [(e(b["source"]), e(b["magnitude"]), e(b["note"]))
                                                           for b in s["budget"]])]
    parts += ["<h2>Validation</h2>", _table(["Check", "Status", "Value", "Criterion"],
              [(e(c["name"]), f"<span class='chip {c['status']}'>{e(c['status'].replace('_', ' '))}</span>",
                e(c["value"]), e(c["detail"])) for c in s["checks"]])]
    for f, cap in figs:
        b64 = base64.b64encode((rf.path / "figures" / f).read_bytes()).decode()
        parts += [f"<figure><img src='data:image/png;base64,{b64}' alt='{e(cap)}'><figcaption>{e(cap)}</figcaption></figure>"]
    if s["q_rows"]:
        parts += ["<h2>Quantum run details</h2>", _table(["Item", "Value"], [(e(a), e(b)) for a, b in s["q_rows"]])]
        qasm = rf.path / "quantum/ansatz.qasm"
        if qasm.exists():
            parts += [f"<details><summary>Optimised ansatz (OpenQASM 2.0)</summary><pre>{html.escape(qasm.read_text())}</pre></details>"]
    parts += ["<h2>Resources</h2>", _table(["Scope", "Item", "Value"], [tuple(e(x) for x in r) for r in s["resources"]])]
    parts += ["<h2>Known limitations (feature status)</h2>",
              _table(["Status", "Area", "Feature"], [(e(c["status"]), e(c["area"]), e(c["feature"])) for c in s["caps"]])]
    parts += ["<h2>Traceability</h2>", _table(["Item", "Value"], [(e(a), e(b)) for a, b in s["trace"]]),
              f"<details><summary>Resolved case</summary><pre>{html.escape(json.dumps(s['case'], indent=2))}</pre></details>"]
    doc = f"<!doctype html><html><head><meta charset='utf-8'><title>{e(res.get('case'))} — QuantumCFD report</title>" \
          f"<style>{_CSS}</style></head><body>{''.join(parts)}</body></html>"
    p = rf.file("report.html")
    p.write_text(doc)
    return p


# ------------------------------------------------------------------ PDF
def write_pdf(rf: RunFolder, figs: list[tuple[str, str]], s: dict) -> Path:
    plt = _plt()
    from matplotlib.backends.backend_pdf import PdfPages
    res = s["res"]
    p = rf.file("report.pdf")
    with PdfPages(p) as pdf:
        def text_page(title: str, lines: list[str]):
            fig = plt.figure(figsize=(8.27, 11.69))
            fig.text(0.07, 0.95, title, fontsize=14, weight="bold")
            y = 0.92
            for line in lines:
                for chunk in [line[i:i + 105] for i in range(0, max(len(line), 1), 105)]:
                    fig.text(0.07, y, chunk, fontsize=8, family="monospace")
                    y -= 0.016
                    if y < 0.04:
                        pdf.savefig(fig); plt.close(fig)
                        fig = plt.figure(figsize=(8.27, 11.69)); y = 0.95
            pdf.savefig(fig); plt.close(fig)

        lines = [f"Run {res.get('run_id')}   status: {res.get('status')}",
                 "Checks: " + ", ".join(f"{v} {k}" for k, v in s["counts"].items()), "", "SET-UP"]
        lines += [f"  {a}: {b}" for a, b in s["setup_rows"]] + ["", "SOLVERS"]
        lines += [f"  {a}: {b} [{c}] {d}" for a, b, c, d in s["solver_rows"]] + ["", "ERROR METRICS"]
        lines += [f"  {n}: " + ", ".join(f"{k}={_fmt(m.get(k))}" for k in METRIC_KEYS) for n, m in s["metric_rows"]]
        lines += ["", "WHERE THE DIFFERENCES COME FROM"] + [f"  {b['source']}: {_fmt(b['magnitude'])} — {b['note']}"
                                                           for b in s["budget"]]
        lines += ["", "VALIDATION"] + [f"  [{c['status']:>14}] {c['name']} = {_fmt(c['value'])}  ({c['detail']})"
                                       for c in s["checks"]]
        text_page(f"QuantumCFD report — {res.get('case')}", lines)
        for f, cap in figs:
            img = plt.imread(rf.path / "figures" / f)
            fig = plt.figure(figsize=(8.27, 11.69))
            ax = fig.add_axes([0.07, 0.35, 0.86, 0.55]); ax.imshow(img); ax.axis("off")
            fig.text(0.07, 0.31, cap, fontsize=9)
            pdf.savefig(fig); plt.close(fig)
        tail = ["RESOURCES"] + [f"  {a}.{b} = {c}" for a, b, c in s["resources"]]
        tail += ["", "QUANTUM DETAILS"] + [f"  {a} = {b}" for a, b in s["q_rows"]]
        tail += ["", "KNOWN LIMITATIONS"] + [f"  [{c['status']}] {c['area']}: {c['feature']}" for c in s["caps"]]
        tail += ["", "TRACEABILITY"] + [f"  {a}: {b}" for a, b in s["trace"]]
        text_page("Resources, limitations and traceability", tail)
    return p


def build_report(rf: RunFolder, formats: list[str] = ("html", "md"), csv: bool = True) -> list[Path]:
    figs = make_figures(rf)
    s = _sections(rf)
    out = []
    if csv:
        out.append(write_csv(rf))
    if "md" in formats:
        out.append(write_markdown(rf, figs, s))
    if "html" in formats:
        out.append(write_html(rf, figs, s))
    if "pdf" in formats:
        out.append(write_pdf(rf, figs, s))
    return out
