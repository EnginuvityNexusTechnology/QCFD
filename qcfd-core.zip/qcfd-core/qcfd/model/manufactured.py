"""Analytical / manufactured solutions.

Every steady benchmark field is defined by u and its derivatives, so the
source term is *derived* from the operator (method of manufactured solutions)
and the same function is the reference for validation. That guarantees the
reference and the source can never disagree.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Callable

import numpy as np

Arr = np.ndarray


@dataclass(frozen=True)
class Field1D:
    u: Callable[[Arr], Arr]
    du: Callable[[Arr], Arr]
    d2u: Callable[[Arr], Arr]


@dataclass(frozen=True)
class Field2D:
    u: Callable[[Arr, Arr], Arr]
    lap: Callable[[Arr, Arr], Arr]


def field_1d(name: str, params: dict, x0: float, length: float) -> Field1D:
    p = dict(params)
    if name == "sine":
        a, k = p.get("amplitude", 1.0), p.get("k", 1)
        w = k * np.pi / length
        return Field1D(lambda x: a * np.sin(w * (x - x0)),
                       lambda x: a * w * np.cos(w * (x - x0)),
                       lambda x: -a * w**2 * np.sin(w * (x - x0)))
    if name == "poly3":
        c0, c1, c2, c3 = (p.get(k, 0.0) for k in ("c0", "c1", "c2", "c3"))
        return Field1D(lambda x: c0 + c1 * x + c2 * x**2 + c3 * x**3,
                       lambda x: c1 + 2 * c2 * x + 3 * c3 * x**2,
                       lambda x: 2 * c2 + 6 * c3 * x)
    if name == "exp_layer":
        # Exact homogeneous solution of -k u'' + c u' = 0 with u(0)=0, u(L)=1 for Pe = cL/k.
        pe = float(p["pe"])
        den = np.expm1(pe)
        return Field1D(lambda x: np.expm1(pe * (x - x0) / length) / den,
                       lambda x: (pe / length) * np.exp(pe * (x - x0) / length) / den,
                       lambda x: (pe / length) ** 2 * np.exp(pe * (x - x0) / length) / den)
    if name == "gaussian":
        xc, w, a = p.get("center", x0 + length / 2), p.get("width", length / 8), p.get("amplitude", 1.0)
        g = lambda x: a * np.exp(-(((x - xc) / w) ** 2))
        return Field1D(g, lambda x: -2 * (x - xc) / w**2 * g(x),
                       lambda x: (4 * (x - xc) ** 2 / w**4 - 2 / w**2) * g(x))
    raise ValueError(f"unknown 1D manufactured solution '{name}'")


def field_2d(name: str, params: dict, origin: tuple[float, float], lx: float, ly: float) -> Field2D:
    p = dict(params)
    x0, y0 = origin
    if name == "sine2d":
        a, kx, ky = p.get("amplitude", 1.0), p.get("kx", 1), p.get("ky", 1)
        wx, wy = kx * np.pi / lx, ky * np.pi / ly
        u = lambda x, y: a * np.sin(wx * (x - x0)) * np.sin(wy * (y - y0))
        return Field2D(u, lambda x, y: -(wx**2 + wy**2) * u(x, y))
    if name == "poly2d":
        # u = 16 xi(1-xi) eta(1-eta): peak 1, zero on the boundary
        def u(x, y):
            xi, eta = (x - x0) / lx, (y - y0) / ly
            return 16 * xi * (1 - xi) * eta * (1 - eta)

        def lap(x, y):
            xi, eta = (x - x0) / lx, (y - y0) / ly
            return 16 * (-2 * eta * (1 - eta) / lx**2 - 2 * xi * (1 - xi) / ly**2)

        return Field2D(u, lap)
    if name == "exp_sin":
        # Harmonic: u = exp(pi x) sin(pi y) (scaled) -> lap u = 0; non-zero Dirichlet data.
        def u(x, y):
            return np.exp(np.pi * (x - x0) / ly) * np.sin(np.pi * (y - y0) / ly)
        return Field2D(u, lambda x, y: np.zeros_like(x * y))
    raise ValueError(f"unknown 2D manufactured solution '{name}'")


MANUFACTURED_1D = ("sine", "poly3", "exp_layer", "gaussian")
MANUFACTURED_2D = ("sine2d", "poly2d", "exp_sin")


# ---- time-dependent exact solutions ----------------------------------------

def heat_sine_exact(x: Arr, t: float, *, alpha: float, k: int, amplitude: float, x0: float, length: float) -> Arr:
    w = k * np.pi / length
    return amplitude * np.exp(-alpha * w**2 * t) * np.sin(w * (x - x0))


def burgers_tanh_exact(x: Arr, t: float, *, nu: float, u_left: float, u_right: float, x_front: float) -> Arr:
    """Viscous Burgers travelling front (exact): speed s = (uL+uR)/2."""
    s = 0.5 * (u_left + u_right)
    return s - 0.5 * (u_left - u_right) * np.tanh((u_left - u_right) * (x - x_front - s * t) / (4 * nu))


def taylor_green_exact(x: Arr, y: Arr, t: float, *, nu: float, amplitude: float, length: float) -> tuple[Arr, Arr, Arr]:
    k = 2 * np.pi / length
    f = np.exp(-2 * nu * k**2 * t)
    u = -amplitude * np.cos(k * x) * np.sin(k * y) * f
    v = amplitude * np.sin(k * x) * np.cos(k * y) * f
    p = -0.25 * amplitude**2 * (np.cos(2 * k * x) + np.cos(2 * k * y)) * f**2
    return u, v, p
