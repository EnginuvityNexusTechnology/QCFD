"""Uniform structured (node-centred) meshes with quality checks and memory estimates."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Annotated, Literal, Union

import numpy as np
from pydantic import BaseModel, ConfigDict, Field

from .geometry import Interval, Rectangle


class MeshSpec1D(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)
    kind: Literal["uniform_1d"] = "uniform_1d"
    cells: int = Field(ge=2, le=1_000_000)


class MeshSpec2D(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)
    kind: Literal["uniform_2d"] = "uniform_2d"
    nx: int = Field(ge=2, le=4096)
    ny: int = Field(ge=2, le=4096)


MeshSpec = Annotated[Union[MeshSpec1D, MeshSpec2D], Field(discriminator="kind")]


@dataclass(frozen=True)
class Mesh1D:
    x: np.ndarray          # nodes x_0 .. x_N  (N = cells)
    h: float

    @property
    def cells(self) -> int:
        return self.x.size - 1

    def summary(self) -> dict:
        return {"kind": "uniform_1d", "cells": self.cells, "nodes": int(self.x.size), "h": self.h}


@dataclass(frozen=True)
class Mesh2D:
    x: np.ndarray          # nx+1 node coordinates
    y: np.ndarray          # ny+1 node coordinates
    hx: float
    hy: float

    @property
    def nx(self) -> int:
        return self.x.size - 1

    @property
    def ny(self) -> int:
        return self.y.size - 1

    def grid(self) -> tuple[np.ndarray, np.ndarray]:
        """X, Y arrays shaped (ny+1, nx+1) — row index = y."""
        return np.meshgrid(self.x, self.y, indexing="xy")

    def summary(self) -> dict:
        return {"kind": "uniform_2d", "nx": self.nx, "ny": self.ny, "nodes": int(self.x.size * self.y.size),
                "hx": self.hx, "hy": self.hy}


def build_mesh(geometry: Interval | Rectangle, spec: MeshSpec1D | MeshSpec2D) -> Mesh1D | Mesh2D:
    if isinstance(geometry, Interval):
        if not isinstance(spec, MeshSpec1D):
            raise ValueError("an interval needs a uniform_1d mesh")
        a, b = geometry.bounds
        return Mesh1D(x=np.linspace(a, b, spec.cells + 1), h=geometry.length / spec.cells)
    if not isinstance(spec, MeshSpec2D):
        raise ValueError("a rectangle needs a uniform_2d mesh")
    x0, y0 = geometry.origin
    return Mesh2D(x=np.linspace(x0, x0 + geometry.lx, spec.nx + 1),
                  y=np.linspace(y0, y0 + geometry.ly, spec.ny + 1),
                  hx=geometry.lx / spec.nx, hy=geometry.ly / spec.ny)


def quality(mesh: Mesh1D | Mesh2D) -> list[dict]:
    """Mesh checks in the shared check format (see validation.checks)."""
    out = []
    if isinstance(mesh, Mesh1D):
        dx = np.diff(mesh.x)
        uniform = np.allclose(dx, mesh.h, rtol=1e-12)
        out.append({"name": "mesh.uniform_spacing", "status": "passed" if uniform else "failed",
                    "detail": "uniform node spacing", "value": float(dx.max() / dx.min())})
        out.append({"name": "mesh.resolution", "status": "passed" if mesh.cells >= 8 else "warning",
                    "detail": "at least 8 cells recommended for 2nd-order accuracy", "value": mesh.cells})
    else:
        ar = max(mesh.hx, mesh.hy) / min(mesh.hx, mesh.hy)
        out.append({"name": "mesh.aspect_ratio", "status": "passed" if ar <= 4 else "warning",
                    "detail": "cell aspect ratio <= 4", "value": ar})
        out.append({"name": "mesh.resolution", "status": "passed" if min(mesh.nx, mesh.ny) >= 8 else "warning",
                    "detail": "at least 8 cells per direction recommended", "value": min(mesh.nx, mesh.ny)})
    return out


def memory_estimate_bytes(mesh: Mesh1D | Mesh2D, fields: int = 1) -> int:
    """Rough working-set estimate: fields + a 5-point sparse operator (CSR) + LU fill for 2D."""
    n = mesh.x.size if isinstance(mesh, Mesh1D) else mesh.x.size * mesh.y.size
    stencil = 3 if isinstance(mesh, Mesh1D) else 5
    csr = n * stencil * (8 + 4) + (n + 1) * 4
    fill = 0 if isinstance(mesh, Mesh1D) else int(n * np.sqrt(n) * 12)  # nested-dissection-like LU fill
    return int(fields * 8 * n * 4 + csr + fill)
