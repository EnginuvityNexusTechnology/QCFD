"""Geometry: the computational domains supported in V1.

V1 supports exactly two shapes, which is what structured finite-difference
meshes need:
  * Interval   (1D)  boundaries: left, right
  * Rectangle  (2D)  boundaries: left, right, bottom, top
"""

from __future__ import annotations

from typing import Annotated, Literal, Union

from pydantic import BaseModel, ConfigDict, Field


class _Strict(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)


class Interval(_Strict):
    kind: Literal["interval"] = "interval"
    length: float = Field(gt=0, description="domain length [m]")
    origin: float = 0.0

    @property
    def dim(self) -> int:
        return 1

    @property
    def boundaries(self) -> tuple[str, ...]:
        return ("left", "right")

    @property
    def bounds(self) -> tuple[float, float]:
        return (self.origin, self.origin + self.length)


class Rectangle(_Strict):
    kind: Literal["rectangle"] = "rectangle"
    lx: float = Field(gt=0, description="width [m]")
    ly: float = Field(gt=0, description="height [m]")
    origin: tuple[float, float] = (0.0, 0.0)

    @property
    def dim(self) -> int:
        return 2

    @property
    def boundaries(self) -> tuple[str, ...]:
        return ("left", "right", "bottom", "top")


Geometry = Annotated[Union[Interval, Rectangle], Field(discriminator="kind")]
