"""Physics models, boundary conditions, sources and initial conditions.

Supported models (V1):
  steady_transport_1d     -k u'' + c u' + r u = f                 (Poisson, advection-diffusion, Helmholtz-type)
  poisson_2d              -k (u_xx + u_yy) = f
  heat_1d                 u_t = a u_xx                              (transient diffusion)
  burgers_1d              u_t + u u_x = nu u_xx                     (nonlinear)
  incompressible_ns_2d    u_t + (u.grad)u = -grad p + nu lap u,  div u = 0   (periodic box)
"""

from __future__ import annotations

from typing import Annotated, Literal, Union

from pydantic import BaseModel, ConfigDict, Field


class _Strict(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)


# ---------------------------------------------------------------- BCs
class BC(_Strict):
    boundary: str
    type: Literal["dirichlet", "neumann", "periodic"]
    # number, or "exact" = take the value from the analytical / manufactured reference
    value: float | Literal["exact"] = 0.0
    # Neumann: value is the OUTWARD normal derivative du/dn.


# ---------------------------------------------------------------- sources
class ZeroSource(_Strict):
    kind: Literal["zero"] = "zero"


class ConstantSource(_Strict):
    kind: Literal["constant"] = "constant"
    value: float


class ManufacturedSource(_Strict):
    kind: Literal["manufactured"] = "manufactured"
    name: str = Field(description="manufactured solution; the source term is derived from it")
    params: dict[str, float] = Field(default_factory=dict)


Source = Annotated[Union[ZeroSource, ConstantSource, ManufacturedSource], Field(discriminator="kind")]


# ---------------------------------------------------------------- models
class SteadyTransport1D(_Strict):
    model: Literal["steady_transport_1d"] = "steady_transport_1d"
    diffusivity: float = Field(1.0, gt=0, description="k [m^2/s]")
    velocity: float = Field(0.0, description="c [m/s]")
    reaction: float = Field(0.0, ge=0, description="r [1/s]; >= 0 keeps the operator well posed")
    source: Source = ZeroSource()
    bcs: list[BC]

    steady: Literal[True] = True
    linear: Literal[True] = True


class Poisson2D(_Strict):
    model: Literal["poisson_2d"] = "poisson_2d"
    diffusivity: float = Field(1.0, gt=0)
    source: Source = ZeroSource()
    bcs: list[BC]

    steady: Literal[True] = True
    linear: Literal[True] = True


class SineIC(_Strict):
    kind: Literal["sine"] = "sine"
    k: int = Field(1, ge=1)
    amplitude: float = 1.0


class Heat1D(_Strict):
    model: Literal["heat_1d"] = "heat_1d"
    diffusivity: float = Field(1.0, gt=0)
    initial: SineIC = SineIC()
    bcs: list[BC]

    steady: Literal[False] = False
    linear: Literal[True] = True


class TanhFrontIC(_Strict):
    kind: Literal["tanh_front"] = "tanh_front"
    u_left: float = 1.0
    u_right: float = 0.0
    x_front: float = 0.25


class Burgers1D(_Strict):
    model: Literal["burgers_1d"] = "burgers_1d"
    viscosity: float = Field(0.01, gt=0)
    initial: TanhFrontIC = TanhFrontIC()
    bcs: list[BC]

    steady: Literal[False] = False
    linear: Literal[False] = False


class TaylorGreenIC(_Strict):
    kind: Literal["taylor_green"] = "taylor_green"
    amplitude: float = 1.0


class IncompressibleNS2D(_Strict):
    model: Literal["incompressible_ns_2d"] = "incompressible_ns_2d"
    viscosity: float = Field(0.01, gt=0)
    density: float = Field(1.0, gt=0)
    initial: TaylorGreenIC = TaylorGreenIC()
    bcs: list[BC]

    steady: Literal[False] = False
    linear: Literal[False] = False


Physics = Annotated[
    Union[SteadyTransport1D, Poisson2D, Heat1D, Burgers1D, IncompressibleNS2D],
    Field(discriminator="model"),
]

MODEL_DIM = {
    "steady_transport_1d": 1, "heat_1d": 1, "burgers_1d": 1,
    "poisson_2d": 2, "incompressible_ns_2d": 2,
}
