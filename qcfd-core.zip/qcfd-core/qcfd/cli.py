"""Command-line interface.

  qcfd init <project> [--name NAME]          create a local project
  qcfd validate <case.toml>                  setup validation + resource estimate (no run)
  qcfd run <case.toml> --project <dir>       run, store, validate, report
  qcfd runs <project>                        run history
  qcfd show <project> <run_id>               summary of a stored run
  qcfd report <project> <run_id>             regenerate reports from stored data
  qcfd verify <project> <run_id>             check file integrity (SHA-256)
  qcfd compare <project> <run_a> <run_b>     compare two runs (only if compatible)
  qcfd capabilities                          feature status table
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import numpy as np

from . import __version__
from .workflow.capabilities import CAPABILITIES
from .workflow.case import CaseError, check_case, load_case
from .workflow.engine import estimate, run_case
from .workflow.storage import Project
from .workflow.validation import error_metrics

STATUS_MARK = {"passed": "ok  ", "warning": "WARN", "failed": "FAIL", "not_applicable": "n/a "}


def _print_checks(checks: list[dict]) -> None:
    for c in checks:
        val = "" if c["value"] is None else f" = {c['value']:.4g}" if isinstance(c["value"], float) else f" = {c['value']}"
        print(f"  [{STATUS_MARK[c['status']]}] {c['name']}{val}  — {c['detail']}")


def cmd_init(a) -> int:
    p = Project.create(a.project, a.name or Path(a.project).name)
    print(f"created project '{p.manifest['name']}' at {p.root}")
    return 0


def cmd_validate(a) -> int:
    try:
        case = load_case(a.case)
    except CaseError as e:
        print("case file is invalid:"); [print("  " + str(i)) for i in e.issues]
        return 2
    issues = check_case(case)
    for i in issues:
        print("  " + str(i))
    if any(i.level == "error" for i in issues):
        print("setup has errors; nothing was run")
        return 2
    print(f"setup OK: {case.name} ({case.physics.model}, solver mode {case.solver.mode})")
    print(json.dumps(estimate(case), indent=2, default=str))
    return 0


def cmd_run(a) -> int:
    try:
        case = load_case(a.case)
    except CaseError as e:
        print("case file is invalid:"); [print("  " + str(i)) for i in e.issues]
        return 2
    project = Project.open_or_create(a.project)
    project.store_case(Path(a.case))
    try:
        out = run_case(case, project, case_text=Path(a.case).read_text(),
                       log=(lambda m: print("  " + m)) if a.verbose else None, make_report=not a.no_report)
    except CaseError as e:
        print("setup has errors; nothing was run:"); [print("  " + str(i)) for i in e.issues]
        return 2
    print(f"run {out.run_id}: {out.status}")
    _print_checks(out.checks)
    print(f"stored in {out.run_dir}")
    return 1 if out.status != "completed" else 0


def cmd_runs(a) -> int:
    for r in Project(a.project).runs():
        c = r.get("checks", {})
        print(f"{r['run_id']:<55} {r['model']:<22} {r['status']:<24} "
              f"pass={c.get('passed', '-')} warn={c.get('warning', '-')} fail={c.get('failed', '-')}")
    return 0


def cmd_show(a) -> int:
    rf = Project(a.project).run(a.run_id)
    res = rf.read_json("results.json")
    print(f"{res.get('run_id')}  {res.get('case')}  {res.get('model')}  {res.get('status')}")
    for name, r in res.get("results", {}).items():
        m = r.get("metrics_vs_reference")
        print(f"  {name}: {r['method']} [{r.get('status')}]" + (f"  rel L2 vs analytical = {m['l2_relative']:.3e}" if m else ""))
    if res.get("comparison"):
        print(f"  quantum vs classical rel L2 = {res['comparison']['metrics_quantum_vs_classical']['l2_relative']:.3e}")
    _print_checks(rf.read_json("validation.json"))
    return 0


def cmd_report(a) -> int:
    from .report.builder import build_report
    rf = Project(a.project).run(a.run_id)
    bad = rf.verify()
    if bad:
        print("refusing to regenerate: stored files changed since the run:", *bad, sep="\n  ")
        return 1
    for p in build_report(rf, formats=a.formats.split(","), csv=True):
        print(f"wrote {p}")
    rf.finalize()
    return 0


def cmd_verify(a) -> int:
    rf = Project(a.project).run(a.run_id)
    bad = rf.verify()
    if bad:
        print("INTEGRITY FAILURE:", *bad, sep="\n  ")
        return 1
    print(f"{rf.run_id}: all {len(rf.read_json('checksums.json'))} files match their SHA-256")
    return 0


def cmd_compare(a) -> int:
    pr = Project(a.project)
    A, B = pr.run(a.run_a), pr.run(a.run_b)
    sa, sb = A.path / "system/system.json", B.path / "system/system.json"
    if not (sa.exists() and sb.exists()):
        print("not comparable: comparison is defined for steady runs that store their discrete system")
        return 2
    fa, fb = json.loads(sa.read_text())["fingerprint"], json.loads(sb.read_text())["fingerprint"]
    if fa != fb:
        print("not comparable: the runs solve different discrete systems (mesh, physics or BCs differ)")
        print(f"  {a.run_a}: {fa[:16]}\n  {a.run_b}: {fb[:16]}")
        return 2
    print(f"compatible: identical discrete system {fa[:16]}")
    for name in ("classical", "quantum"):
        pa, pb = A.path / f"fields/{name}.npy", B.path / f"fields/{name}.npy"
        if pa.exists() and pb.exists():
            m = error_metrics(np.load(pb), np.load(pa))
            print(f"  {name}: rel L2 = {m['l2_relative']:.3e}, max abs = {m['max_abs']:.3e}")
    return 0


def cmd_capabilities(a) -> int:
    for c in CAPABILITIES:
        print(f"  {c['status']:<12} {c['area']:<10} {c['feature']}")
    return 0


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(prog="qcfd", description=f"QuantumCFD simulation core {__version__}")
    sub = ap.add_subparsers(dest="cmd", required=True)
    s = sub.add_parser("init"); s.add_argument("project"); s.add_argument("--name"); s.set_defaults(f=cmd_init)
    s = sub.add_parser("validate"); s.add_argument("case"); s.set_defaults(f=cmd_validate)
    s = sub.add_parser("run"); s.add_argument("case"); s.add_argument("--project", required=True)
    s.add_argument("--no-report", action="store_true"); s.add_argument("-v", "--verbose", action="store_true")
    s.set_defaults(f=cmd_run)
    s = sub.add_parser("runs"); s.add_argument("project"); s.set_defaults(f=cmd_runs)
    s = sub.add_parser("show"); s.add_argument("project"); s.add_argument("run_id"); s.set_defaults(f=cmd_show)
    s = sub.add_parser("report"); s.add_argument("project"); s.add_argument("run_id")
    s.add_argument("--formats", default="html,md,pdf"); s.set_defaults(f=cmd_report)
    s = sub.add_parser("verify"); s.add_argument("project"); s.add_argument("run_id"); s.set_defaults(f=cmd_verify)
    s = sub.add_parser("compare"); s.add_argument("project"); s.add_argument("run_a"); s.add_argument("run_b")
    s.set_defaults(f=cmd_compare)
    s = sub.add_parser("capabilities"); s.set_defaults(f=cmd_capabilities)
    a = ap.parse_args(argv)
    return a.f(a)


if __name__ == "__main__":
    sys.exit(main())
