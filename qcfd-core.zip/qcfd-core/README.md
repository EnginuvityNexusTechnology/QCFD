# qcfd — QuantumCFD simulation core

Offline engineering core for setting up fluid-flow problems, solving them with
tested classical methods and a quantum formulation (VQLS) on a local circuit
simulator, comparing the two, and producing traceable runs and reports.
No frontend, no network, no database server. Python ≥ 3.11 with NumPy, SciPy,
pydantic and matplotlib.

```bash
pip install -e ".[dev]"
pytest -q                                   # 40 tests, ~15 s
qcfd capabilities                           # feature status table
qcfd validate cases/01_poisson1d_classical_vs_quantum.toml
qcfd run cases/01_poisson1d_classical_vs_quantum.toml --project ./my-project -v
qcfd runs ./my-project
```

## Workflow

```
case.toml ─► setup validation ─► mesh ─► discretization ─► LinearSystem (A, b)
                (errors + fixes,     (quality,      (FD stencils,      │
                 resource estimate)   memory)        BCs, sources)      ├─► classical solver ─┐
                                                                         └─► quantum (VQLS)  ─┤
                                                                                              ▼
              report (HTML/MD/PDF, CSV) ◄─ validation checks ◄─ refinement study ◄─ comparison
                         └──────────────── run folder with SHA-256 checksums ─────────────────┘
```

Classical and quantum modules never import each other. They meet only in
`workflow/engine.py`, through the same `LinearSystem`. A comparison is made only
when both solved the identical discrete system (same SHA-256 fingerprint of A and b).

## What is supported

| Model | Equation | Methods | Quantum | Reference |
|---|---|---|---|---|
| `steady_transport_1d` | −k u″ + c u′ + r u = f, Dirichlet/Neumann | 2nd-order FD (central) or 1st-order upwind; direct, CG, GMRES | **VQLS** | manufactured: sine, poly3, gaussian, exp_layer |
| `poisson_2d` | −k ∇²u = f, Dirichlet | 5-point FD; direct, CG, GMRES | **VQLS** | manufactured: sine2d, poly2d, exp_sin |
| `heat_1d` | u_t = a u_xx | Crank–Nicolson, implicit Euler | planned | exact sine-mode decay |
| `burgers_1d` | u_t + u u_x = ν u_xx | method of lines + BDF, IMEX Euler | planned | exact tanh front |
| `incompressible_ns_2d` | Navier–Stokes, periodic box | SSP-RK3 + exact discrete FFT projection | planned | Taylor–Green vortex |

Measured orders (the refinement study runs on every case): steady 1D/2D 2.00, upwind 1.0,
CN 2.0, implicit Euler 1.0, Burgers BDF 2.0, Taylor–Green 2.00 with ‖div u‖ ≈ 1e-15.

### Quantum formulation

`quantum/vqls.py`: Variational Quantum Linear Solver with a hardware-efficient RY + CX ansatz.

* **Encoding:** the system is padded to 2ⁿ with an identity block, so any grid size works and padded
  amplitudes are checked to be ~0. It is rescaled and decomposed into Pauli strings (fast
  Walsh–Hadamard LCU, `quantum/pauli.py`).
* **`cost_mode = "exact"`:** statevector expectation values with L-BFGS-B. Reaches the classical
  solution to about 1e-8.
* **`cost_mode = "sampled"`:** the estimator a device would run. There is one Hadamard test per
  Pauli term of A for ⟨b|A|x⟩ and one Pauli-basis measurement per term of AᵀA. Each is sampled with
  `shots`, and training uses SPSA on the unnormalized global cost. The unnormalized form is
  deliberate: the normalized cost is a ratio whose small denominator amplifies shot noise about
  30× at the optimum.
* **Outputs:** the optimized circuit as OpenQASM 2.0, the Pauli terms, and resources (qubits,
  depth, CX count, LCU terms, circuits and shots per cost evaluation, state-prep and
  controlled-ansatz CX estimates).
* **Limitations (status: limited):** a noiseless simulator, so there is no gate or readout noise;
  readout signs come from the statevector; the cap is 10 qubits. No quantum advantage is claimed,
  and every report says so.

## Case files

See `cases/`. Each section maps to a workflow stage:

```toml
name = "..."
[geometry]       kind = "interval" | "rectangle"
[physics]        model = ..., coefficients, source / initial, bcs = [{boundary, type, value}]
[mesh]           kind = "uniform_1d" (cells) | "uniform_2d" (nx, ny)
[discretization] advection = "central" | "upwind"
[solver]         mode = "classical" | "quantum" | "both"; classical = {...}; quantum = {...}
[time]           t_end, dt, scheme, snapshots, cfl          # transient models only
[validation]     refinement_levels, reference_tolerance, comparison_tolerance, order_tolerance
[output]         reports = ["html", "md", "pdf"], csv
```

`value = "exact"` takes boundary data from the manufactured or analytical solution.
`qcfd validate` reports schema errors with their path, plus physics and compatibility rules with
a suggested fix. Examples: a quantum solve requested for a nonlinear model, CG on a non-symmetric
operator, a pure Neumann singular problem, a cell Péclet or Reynolds number too high, too many
qubits. A case with errors is never run.

## A stored run

```
runs/<run_id>/
  case.toml, case.resolved.json   input snapshot (as written + fully resolved defaults)
  environment.json                qcfd / python / numpy / scipy / platform versions
  setup.json                      setup issues + pre-run resource estimate
  run.log                         timestamped log
  mesh.json, system/A.npz, b.npy  discrete system + fingerprint
  fields/*.npy, fields.csv        reference / classical / quantum fields (or snapshots)
  quantum/ansatz.qasm, pauli_terms.json
  results.json                    metrics, comparison, refinement, error budget, resources
  validation.json                 checks: passed / warning / failed / not_applicable
  report.html|md|pdf, figures/    reports regenerable from stored data (`qcfd report`)
  checksums.json                  SHA-256 of every file (`qcfd verify`)
```

The report's **"Where the differences come from"** table attributes each difference to one source:
discretization (classical vs analytical), solver tolerance (residual), quantum approximation
(quantum vs classical on the same system), sampling noise, or hardware noise (not modelled).

## Extending

| To add | Implement | Register in |
|---|---|---|
| a physics model | pydantic model in `model/physics.py` + assembler in `discretization/` | `Physics` union, `MODEL_DIM`, `engine.assemble` / `_simulate_transient`, `case.check_case` |
| a classical linear solver | branch in `classical/linear.py::solve_linear` + `INFO` entry | `ClassicalCfg.method` |
| a quantum algorithm / backend | a module returning `QuantumResult` from a `LinearSystem` | `QuantumCfg.method`, `engine._run_steady` |
| a manufactured solution | `field_1d` / `field_2d` in `model/manufactured.py` | `MANUFACTURED_1D/2D` |

Update `workflow/capabilities.py` so reports label the new feature correctly.
