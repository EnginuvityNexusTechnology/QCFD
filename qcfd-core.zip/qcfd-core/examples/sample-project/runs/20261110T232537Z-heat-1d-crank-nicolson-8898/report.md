# Simulation report — Heat 1D - Crank-Nicolson

Run `20261110T232537Z-heat-1d-crank-nicolson-8898` · status **completed** · checks: 5 passed, 0 warning, 0 failed, 0 not applicable

## Set-up

| Item | Value |
| --- | --- |
| Model | heat_1d |
| Geometry | {"kind": "interval", "length": 1.0, "origin": 0.0} |
| Mesh | {"kind": "uniform_1d", "cells": 32, "nodes": 33, "h": 0.03125} |
| Boundary conditions | left: dirichlet = 0.0; right: dirichlet = 0.0 |
| Diffusivity | 0.1 |
| Initial condition | {"kind": "sine", "k": 1, "amplitude": 1.0} |
| Time | {"t_end": 1.0, "dt": null, "scheme": "crank_nicolson", "snapshots": 11, "cfl": 0.4} |
| Solver mode | classical |

## Solvers

| Role | Method | Status | Known limitations |
| --- | --- | --- | --- |
| classical | crank_nicolson | implemented |  |

## Error metrics

| Comparison | max_abs | max_relative | l2_relative | rmse |
| --- | --- | --- | --- | --- |
| classical vs analytical | 2.664e-04 | 7.147e-04 | 7.147e-04 | 1.855e-04 |

## Where the differences come from

| Source | Magnitude | Note |
| --- | --- | --- |
| discretization (space + time) | 7.147e-04 | scheme crank_nicolson; see the refinement study for the split between h and dt |

## Validation

| Check | Status | Value | Criterion |
| --- | --- | --- | --- |
| mesh.uniform_spacing | passed | 1 | uniform node spacing |
| mesh.resolution | passed | 32 | at least 8 cells recommended for 2nd-order accuracy |
| classical.reference_error | passed | 7.147e-04 | relative L2 error vs analytical reference at t_end <= 0.05 |
| physics.maximum_principle | passed | 0.373 | max |u| does not grow (homogeneous diffusion) |
| classical.convergence_order | passed | 2 | space and time refined together (dt ~ h): expected ~2 (+/-0.25) |

![Solution snapshots in time (light to dark), analytical solution dashed.](figures/snapshots.png)

*Solution snapshots in time (light to dark), analytical solution dashed.*

![Relative L2 error against the analytical solution over time.](figures/error_history.png)

*Relative L2 error against the analytical solution over time.*

![Grid-refinement study on log-log axes with the expected slope.](figures/refinement.png)

*Grid-refinement study on log-log axes with the expected slope.*

## Resources

| Scope | Item | Value |
| --- | --- | --- |
| classical | runtime_s | 4.795e-04 |
| classical | unknowns | 31 |
| estimate | mesh | {"kind": "uniform_1d", "cells": 32, "nodes": 33, "h": 0.03125} |
| estimate | memory_estimate_bytes | 2,380 |
| estimate | time | {"t_end": 1.0, "scheme": "crank_nicolson", "dt": "auto"} |
| estimate | refinement_finest_mesh | {"kind": "uniform_1d", "cells": 256, "nodes": 257, "h": 0.00390625} |

## Known limitations (feature status)

- **planned** — geometry: CAD import / curved boundaries / 3D
- **planned** — mesh: graded / stretched / unstructured meshes
- **limited** — physics: incompressible_ns_2d: periodic box (Taylor-Green)
- **planned** — physics: walls / inflow-outflow NS, flow over a cylinder, Schrodinger 1D

## Traceability

| Item | Value |
| --- | --- |
| Run ID | 20261110T232537Z-heat-1d-crank-nicolson-8898 |
| Status | completed |
| Finished | 2026-11-10T23:25:37+00:00 |
| Wall time [s] | 0.07847 |
| qcfd | 0.2.0 |
| python | 3.13.18 |
| numpy | 2.5.3 |
| scipy | 1.18.1 |
| platform | Linux-6.18.44-fc-v338-x86_64-with-glibc2.39 |
| machine | x86_64 |
| matplotlib | 3.11.2 |
| Integrity | SHA-256 of every file in checksums.json (verify with `qcfd verify`) |
