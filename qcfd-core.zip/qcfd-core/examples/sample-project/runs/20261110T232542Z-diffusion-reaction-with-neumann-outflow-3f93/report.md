# Simulation report — Diffusion-reaction with Neumann outflow

Run `20261110T232542Z-diffusion-reaction-with-neumann-outflow-3f93` · status **completed** · checks: 5 passed, 0 warning, 0 failed, 1 not applicable

## Set-up

| Item | Value |
| --- | --- |
| Model | steady_transport_1d |
| Geometry | {"kind": "interval", "length": 2.0, "origin": 0.0} |
| Mesh | {"kind": "uniform_1d", "cells": 16, "nodes": 17, "h": 0.125} |
| Boundary conditions | left: dirichlet = 0.0; right: neumann = 0.0 |
| Diffusivity | 0.5 |
| Velocity | 0 |
| Reaction | 1 |
| Source | {"kind": "constant", "value": 1.0} |
| Solver mode | classical |
| Advection scheme | central |

## Solvers

| Role | Method | Status | Known limitations |
| --- | --- | --- | --- |
| classical | cg | implemented | Conjugate gradients; requires a symmetric positive-definite operator. Jacobi-preconditioned. |

## Where the differences come from

| Source | Magnitude | Note |
| --- | --- | --- |
| discretization | — | no reference: estimated only through the self-convergence order |
| classical solver tolerance | 7.192e-15 | relative residual of the classical solve |

## Validation

| Check | Status | Value | Criterion |
| --- | --- | --- | --- |
| mesh.uniform_spacing | passed | 1 | uniform node spacing |
| mesh.resolution | passed | 16 | at least 8 cells recommended for 2nd-order accuracy |
| classical.converged | passed | — | solver convergence |
| classical.residual | passed | 7.192e-15 | relative residual ||Au-b||/||b|| <= 1e-08 |
| classical.reference_error | not_applicable | — | no analytical reference for this set-up; see the self-convergence study |
| classical.convergence_order | passed | 1.999 | self-convergence (three nested grids, no reference): expected ~2 (+/-0.25) |

![Nodal solution: analytical reference, classical and quantum results.](figures/solution.png)

*Nodal solution: analytical reference, classical and quantum results.*

## Resources

| Scope | Item | Value |
| --- | --- | --- |
| classical | runtime_s | 0.001075 |
| classical | unknowns | 16 |
| classical | nnz | 46 |
| estimate | mesh | {"kind": "uniform_1d", "cells": 16, "nodes": 17, "h": 0.125} |
| estimate | memory_estimate_bytes | 1,228 |
| estimate | system | {"unknowns": 16, "nnz": 46, "symmetric": true, "fingerprint": "bfcbec68d06c303b", "operator": "-k u'' + c u' + r u", "advection": "central", "cell_peclet": 0.0, |
| estimate | refinement_finest_mesh | {"kind": "uniform_1d", "cells": 128, "nodes": 129, "h": 0.015625} |

## Known limitations (feature status)

- **planned** — geometry: CAD import / curved boundaries / 3D
- **planned** — mesh: graded / stretched / unstructured meshes
- **limited** — physics: incompressible_ns_2d: periodic box (Taylor-Green)
- **planned** — physics: walls / inflow-outflow NS, flow over a cylinder, Schrodinger 1D

## Traceability

| Item | Value |
| --- | --- |
| Run ID | 20261110T232542Z-diffusion-reaction-with-neumann-outflow-3f93 |
| Status | completed |
| Finished | 2026-11-10T23:25:42+00:00 |
| Wall time [s] | 0.08889 |
| System fingerprint (A, b) | bfcbec68d06c303be07de56505f53df68704297e49ba03bfcadcded621107090 |
| qcfd | 0.2.0 |
| python | 3.13.18 |
| numpy | 2.5.3 |
| scipy | 1.18.1 |
| platform | Linux-6.18.44-fc-v338-x86_64-with-glibc2.39 |
| machine | x86_64 |
| matplotlib | 3.11.2 |
| Integrity | SHA-256 of every file in checksums.json (verify with `qcfd verify`) |
