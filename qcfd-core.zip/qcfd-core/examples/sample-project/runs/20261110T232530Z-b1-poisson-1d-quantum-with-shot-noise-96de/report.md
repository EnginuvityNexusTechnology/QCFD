# Simulation report — B1 Poisson 1D - quantum with shot noise

Run `20261110T232530Z-b1-poisson-1d-quantum-with-shot-noise-96de` · status **completed** · checks: 8 passed, 3 warning, 0 failed, 1 not applicable

## Set-up

| Item | Value |
| --- | --- |
| Model | steady_transport_1d |
| Geometry | {"kind": "interval", "length": 1.0, "origin": 0.0} |
| Mesh | {"kind": "uniform_1d", "cells": 5, "nodes": 6, "h": 0.2} |
| Boundary conditions | left: dirichlet = exact; right: dirichlet = exact |
| Diffusivity | 1 |
| Velocity | 0 |
| Reaction | 0 |
| Source | {"kind": "manufactured", "name": "sine", "params": {}} |
| Solver mode | both |
| Advection scheme | central |

## Solvers

| Role | Method | Status | Known limitations |
| --- | --- | --- | --- |
| classical | direct | implemented | Sparse LU (SuperLU). Exact to round-off; memory grows with fill-in. |
| quantum | vqls | limited | VQLS on a local noiseless statevector simulator. Sampled mode models shot noise only (no gate/readout noise). Readout signs come from the statevector. Hardware-efficient ansatz without trainability guarantees. Capped at 10 qubits (2^10 unknowns). No quantum advantage is claimed. |

## Error metrics

| Comparison | max_abs | max_relative | l2_relative | rmse |
| --- | --- | --- | --- | --- |
| classical vs analytical | 0.03192 | 0.03356 | 0.03356 | 0.02166 |
| quantum vs analytical | 0.01998 | 0.02101 | 0.01929 | 0.01245 |
| quantum vs classical | 0.03979 | 0.04048 | 0.02621 | 0.01749 |

## Where the differences come from

| Source | Magnitude | Note |
| --- | --- | --- |
| discretization | 0.03356 | classical vs analytical; the algebraic error is negligible so this is truncation error |
| classical solver tolerance | 3.319e-16 | relative residual of the classical solve |
| quantum approximation + sampling noise | 0.02621 | quantum vs classical on the identical discrete system: ansatz expressivity, optimiser convergence, finite shots |
| sampling noise | 0.1142 | standard deviation of the sampled cost over 5 repeated estimates |
| hardware noise | — | not modelled (noiseless simulator) |

## Validation

| Check | Status | Value | Criterion |
| --- | --- | --- | --- |
| mesh.uniform_spacing | passed | 1 | uniform node spacing |
| mesh.resolution | warning | 5 | at least 8 cells recommended for 2nd-order accuracy |
| classical.converged | passed | — | solver convergence |
| classical.residual | passed | 3.319e-16 | relative residual ||Au-b||/||b|| <= 1e-08 |
| classical.reference_error | passed | 0.03356 | relative L2 error vs analytical reference <= 0.2 |
| quantum.cost_converged | warning | 0.01057 | VQLS global cost < 1e-06 (exact, simulator diagnostic) |
| quantum.padding_leakage | passed | 0 | norm of the padded (non-physical) amplitudes <= 0.001 |
| quantum.sampling | warning | 0.1142 | shot noise included; readout signs from statevector (idealised) |
| quantum.hardware_noise | not_applicable | — | noiseless simulator: gate and readout noise are not modelled |
| quantum.reference_error | passed | 0.01929 | relative L2 error vs analytical reference <= 0.2 |
| comparison.quantum_vs_classical | passed | 0.02621 | relative L2 difference, quantum vs classical <= 0.1 |
| classical.convergence_order | passed | 2.009 | error vs analytical reference: expected ~2 (+/-0.25) |

![Nodal solution: analytical reference, classical and quantum results.](figures/solution.png)

*Nodal solution: analytical reference, classical and quantum results.*

![Pointwise discretization error and quantum-classical difference (log scale).](figures/error.png)

*Pointwise discretization error and quantum-classical difference (log scale).*

![Grid-refinement study on log-log axes with the expected slope.](figures/refinement.png)

*Grid-refinement study on log-log axes with the expected slope.*

## Quantum run details

| Item | Value |
| --- | --- |
| method | vqls |
| cost_mode | sampled |
| optimizer | spsa |
| seed | 7 |
| final_cost_exact | 0.01057 |
| restart_costs | [0.002248517083333417, 0.0009049247916666318] |
| relative_residual | 0.1047 |
| padding_leakage | 0 |
| condition_number | 9.472 |
| scale_factor_mu | -1.599 |
| sampled_cost_mean | 0.01484 |
| sampled_cost_std | 0.1142 |
| sampled_unnormalised_cost_mean | 8.584e-04 |
| sampled_unnormalised_cost_std | 0.004229 |
| sampled_estimate_repeats | 5 |
| readout_shots | 100,000 |
| readout_sign_source | statevector (idealised) |
| readout_max_prob_std | 0.001524 |

## Resources

| Scope | Item | Value |
| --- | --- | --- |
| classical | runtime_s | 3.448e-04 |
| classical | unknowns | 4 |
| classical | nnz | 10 |
| quantum | unknowns | 4 |
| quantum | qubits | 2 |
| quantum | padded_unknowns | 0 |
| quantum | ansatz_layers | 3 |
| quantum | ansatz_parameters | 8 |
| quantum | ansatz_cx | 3 |
| quantum | ansatz_depth | 7 |
| quantum | statevector_bytes | 64 |
| quantum | feasible_locally | yes |
| quantum | state_prep_cx_estimate | 2 |
| quantum | hadamard_test_ancillas | 1 |
| quantum | pauli_terms_A | 4 |
| quantum | pauli_terms_AtA | 6 |
| quantum | max_pauli_weight | 2 |
| quantum | circuits_per_cost_evaluation | 9 |
| quantum | controlled_ansatz_cx_estimate | 34 |
| quantum | shots_per_cost_evaluation | 180,000 |
| quantum | runtime_s | 0.6647 |
| quantum | cost_evaluations | 3,042 |
| quantum | circuits_executed | 27,423 |
| quantum | shots_used | 548,460,000 |
| quantum | ansatz_gate_counts | {"ry": 8, "cx": 3} |
| quantum | ansatz_two_qubit_depth | 3 |
| quantum | simulator | qcfd.statevector (NumPy, noiseless) |
| estimate | mesh | {"kind": "uniform_1d", "cells": 5, "nodes": 6, "h": 0.2} |
| estimate | memory_estimate_bytes | 436 |
| estimate | system | {"unknowns": 4, "nnz": 10, "symmetric": true, "fingerprint": "6e32c6281eca14cc", "operator": "-k u'' + c u' + r u", "advection": "central", "cell_peclet": 0.0,  |
| estimate | refinement_finest_mesh | {"kind": "uniform_1d", "cells": 40, "nodes": 41, "h": 0.025} |

## Known limitations (feature status)

- **planned** — geometry: CAD import / curved boundaries / 3D
- **planned** — mesh: graded / stretched / unstructured meshes
- **limited** — physics: incompressible_ns_2d: periodic box (Taylor-Green)
- **planned** — physics: walls / inflow-outflow NS, flow over a cylinder, Schrodinger 1D
- **limited** — quantum: VQLS, exact statevector cost
- **limited** — quantum: VQLS, shot-sampled Hadamard-test cost + SPSA
- **planned** — quantum: noise models, sign-resolving readout, HHL/QSVT, framework backends (Qiskit/Qrisp/PennyLane)
- **planned** — quantum: quantum formulation for transient or nonlinear models
- **planned** — quantum: cloud / physical QPU execution

## Traceability

| Item | Value |
| --- | --- |
| Run ID | 20261110T232530Z-b1-poisson-1d-quantum-with-shot-noise-96de |
| Status | completed |
| Finished | 2026-11-10T23:25:31+00:00 |
| Wall time [s] | 0.7567 |
| System fingerprint (A, b) | 6e32c6281eca14cc57d14cc1c0e4551a73bfa55df7451d690d454f96ca17f5f1 |
| Quantum seed | 7 |
| qcfd | 0.2.0 |
| python | 3.13.18 |
| numpy | 2.5.3 |
| scipy | 1.18.1 |
| platform | Linux-6.18.44-fc-v338-x86_64-with-glibc2.39 |
| machine | x86_64 |
| matplotlib | 3.11.2 |
| Integrity | SHA-256 of every file in checksums.json (verify with `qcfd verify`) |
