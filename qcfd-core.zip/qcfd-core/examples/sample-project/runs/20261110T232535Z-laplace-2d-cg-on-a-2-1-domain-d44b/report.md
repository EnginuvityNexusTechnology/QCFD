# Simulation report — Laplace 2D - CG on a 2:1 domain

Run `20261110T232535Z-laplace-2d-cg-on-a-2-1-domain-d44b` · status **completed** · checks: 6 passed, 0 warning, 0 failed, 0 not applicable

## Set-up

| Item | Value |
| --- | --- |
| Model | poisson_2d |
| Geometry | {"kind": "rectangle", "lx": 2.0, "ly": 1.0, "origin": [0.0, 0.0]} |
| Mesh | {"kind": "uniform_2d", "nx": 64, "ny": 32, "nodes": 2145, "hx": 0.03125, "hy": 0.03125} |
| Boundary conditions | left: dirichlet = exact; right: dirichlet = exact; bottom: dirichlet = exact; top: dirichlet = exact |
| Diffusivity | 1 |
| Source | {"kind": "manufactured", "name": "exp_sin", "params": {}} |
| Solver mode | classical |
| Advection scheme | central |

## Solvers

| Role | Method | Status | Known limitations |
| --- | --- | --- | --- |
| classical | cg | implemented | Conjugate gradients; requires a symmetric positive-definite operator. Jacobi-preconditioned. |

## Error metrics

| Comparison | max_abs | max_relative | l2_relative | rmse |
| --- | --- | --- | --- | --- |
| classical vs analytical | 0.158 | 2.951e-04 | 5.399e-04 | 0.05914 |

## Where the differences come from

| Source | Magnitude | Note |
| --- | --- | --- |
| discretization | 5.399e-04 | classical vs analytical; the algebraic error is negligible so this is truncation error |
| classical solver tolerance | 1.695e-12 | relative residual of the classical solve |

## Validation

| Check | Status | Value | Criterion |
| --- | --- | --- | --- |
| mesh.aspect_ratio | passed | 1 | cell aspect ratio <= 4 |
| mesh.resolution | passed | 32 | at least 8 cells per direction recommended |
| classical.converged | passed | — | solver convergence |
| classical.residual | passed | 1.695e-12 | relative residual ||Au-b||/||b|| <= 1e-08 |
| classical.reference_error | passed | 5.399e-04 | relative L2 error vs analytical reference <= 0.05 |
| classical.convergence_order | passed | 2 | error vs analytical reference: expected ~2 (+/-0.25) |

![Solution field and difference fields on the structured mesh.](figures/fields.png)

*Solution field and difference fields on the structured mesh.*

![Grid-refinement study on log-log axes with the expected slope.](figures/refinement.png)

*Grid-refinement study on log-log axes with the expected slope.*

## Resources

| Scope | Item | Value |
| --- | --- | --- |
| classical | runtime_s | 0.004723 |
| classical | unknowns | 1,953 |
| classical | nnz | 9,577 |
| estimate | mesh | {"kind": "uniform_2d", "nx": 64, "ny": 32, "nodes": 2145, "hx": 0.03125, "hy": 0.03125} |
| estimate | memory_estimate_bytes | 1,398,050 |
| estimate | system | {"unknowns": 1953, "nnz": 9577, "symmetric": true, "fingerprint": "5580281e1c2bd3db", "operator": "-k lap u (5-point)", "hx": 0.03125, "hy": 0.03125} |
| estimate | refinement_finest_mesh | {"kind": "uniform_2d", "nx": 256, "ny": 128, "nodes": 33153, "hx": 0.0078125, "hy": 0.0078125} |

## Known limitations (feature status)

- **planned** — geometry: CAD import / curved boundaries / 3D
- **planned** — mesh: graded / stretched / unstructured meshes
- **limited** — physics: incompressible_ns_2d: periodic box (Taylor-Green)
- **planned** — physics: walls / inflow-outflow NS, flow over a cylinder, Schrodinger 1D

## Traceability

| Item | Value |
| --- | --- |
| Run ID | 20261110T232535Z-laplace-2d-cg-on-a-2-1-domain-d44b |
| Status | completed |
| Finished | 2026-11-10T23:25:36+00:00 |
| Wall time [s] | 0.2681 |
| System fingerprint (A, b) | 5580281e1c2bd3dbc63a663361cce225d1756f270fe2300bac20c92fb0e942aa |
| qcfd | 0.2.0 |
| python | 3.13.18 |
| numpy | 2.5.3 |
| scipy | 1.18.1 |
| platform | Linux-6.18.44-fc-v338-x86_64-with-glibc2.39 |
| machine | x86_64 |
| matplotlib | 3.11.2 |
| Integrity | SHA-256 of every file in checksums.json (verify with `qcfd verify`) |
