# Simulation report — B1 Poisson 1D - classical vs quantum

Run `20261110T232527Z-b1-poisson-1d-classical-vs-quantum-9c2c` · status **completed** · checks: 10 passed, 0 warning, 0 failed, 1 not applicable

## Set-up

| Item | Value |
| --- | --- |
| Model | steady_transport_1d |
| Geometry | {"kind": "interval", "length": 1.0, "origin": 0.0} |
| Mesh | {"kind": "uniform_1d", "cells": 9, "nodes": 10, "h": 0.1111111111111111} |
| Boundary conditions | left: dirichlet = exact; right: dirichlet = exact |
| Diffusivity | 1 |
| Velocity | 0 |
| Reaction | 0 |
| Source | {"kind": "manufactured", "name": "sine", "params": {"k": 1.0}} |
| Solver mode | both |
| Advection scheme | central |

## Solvers

| Role | Method | Status | Known limitations |
| --- | --- | --- | --- |
| classical | direct | implemented | Sparse LU (SuperLU). Exact to round-off; memory grows with fill-in. |
| quantum | vqls | limited | VQLS on a local noiseless statevector simulator. Sampled mode models shot noise only (no gate/readout noise). Readout signs come from the statevector. Hardware-efficient ansatz without trainability guarantees. Capped at 10 qubits (2^10 unknowns). No quantum advantage is claimed. |

## Error metrics

| Comparison | max_abs | max_relative | l2_relative | rmse |
| --- | --- | --- | --- | --- |
| classical vs analytical | 0.01006 | 0.01022 | 0.01022 | 0.006853 |
| quantum vs analytical | 0.01006 | 0.01022 | 0.01022 | 0.006853 |
| quantum vs classical | 1.445e-08 | 1.453e-08 | 9.838e-09 | 6.667e-09 |

## Where the differences come from

| Source | Magnitude | Note |
| --- | --- | --- |
| discretization | 0.01022 | classical vs analytical; the algebraic error is negligible so this is truncation error |
| classical solver tolerance | 2.289e-15 | relative residual of the classical solve |
| quantum approximation | 9.838e-09 | quantum vs classical on the identical discrete system: ansatz expressivity, optimiser convergence |
| hardware noise | — | not modelled (noiseless simulator) |

## Validation

| Check | Status | Value | Criterion |
| --- | --- | --- | --- |
| mesh.uniform_spacing | passed | 1 | uniform node spacing |
| mesh.resolution | passed | 9 | at least 8 cells recommended for 2nd-order accuracy |
| classical.converged | passed | — | solver convergence |
| classical.residual | passed | 2.289e-15 | relative residual ||Au-b||/||b|| <= 1e-08 |
| classical.reference_error | passed | 0.01022 | relative L2 error vs analytical reference <= 0.05 |
| quantum.cost_converged | passed | 1.676e-14 | VQLS global cost < 1e-06 (exact, simulator diagnostic) |
| quantum.padding_leakage | passed | 0 | norm of the padded (non-physical) amplitudes <= 0.001 |
| quantum.hardware_noise | not_applicable | — | noiseless simulator: gate and readout noise are not modelled |
| quantum.reference_error | passed | 0.01022 | relative L2 error vs analytical reference <= 0.05 |
| comparison.quantum_vs_classical | passed | 9.838e-09 | relative L2 difference, quantum vs classical <= 0.0001 |
| classical.convergence_order | passed | 2.002 | error vs analytical reference: expected ~2 (+/-0.25) |

![Nodal solution: analytical reference, classical and quantum results.](figures/solution.png)

*Nodal solution: analytical reference, classical and quantum results.*

![Pointwise discretization error and quantum-classical difference (log scale).](figures/error.png)

*Pointwise discretization error and quantum-classical difference (log scale).*

![Grid-refinement study on log-log axes with the expected slope.](figures/refinement.png)

*Grid-refinement study on log-log axes with the expected slope.*

## Quantum run details

| Item | Value |
| --- | --- |
| method | vqls |
| cost_mode | exact |
| optimizer | lbfgs |
| seed | 1,234 |
| final_cost_exact | 1.676e-14 |
| restart_costs | [1.6764367671839864e-14, 4.285460875053104e-14, 1.2922996006636822e-13] |
| relative_residual | 1.297e-07 |
| padding_leakage | 0 |
| condition_number | 32.16 |
| scale_factor_mu | 2.143 |

## Resources

| Scope | Item | Value |
| --- | --- | --- |
| classical | runtime_s | 3.170e-04 |
| classical | unknowns | 8 |
| classical | nnz | 22 |
| quantum | unknowns | 8 |
| quantum | qubits | 3 |
| quantum | padded_unknowns | 0 |
| quantum | ansatz_layers | 4 |
| quantum | ansatz_parameters | 15 |
| quantum | ansatz_cx | 8 |
| quantum | ansatz_depth | 13 |
| quantum | statevector_bytes | 128 |
| quantum | feasible_locally | yes |
| quantum | state_prep_cx_estimate | 8 |
| quantum | hadamard_test_ancillas | 1 |
| quantum | pauli_terms_A | 8 |
| quantum | pauli_terms_AtA | 14 |
| quantum | max_pauli_weight | 3 |
| quantum | circuits_per_cost_evaluation | 21 |
| quantum | controlled_ansatz_cx_estimate | 78 |
| quantum | runtime_s | 0.7178 |
| quantum | cost_evaluations | 3,616 |
| quantum | circuits_executed | 0 |
| quantum | shots_used | 0 |
| quantum | ansatz_gate_counts | {"ry": 15, "cx": 8} |
| quantum | ansatz_two_qubit_depth | 8 |
| quantum | simulator | qcfd.statevector (NumPy, noiseless) |
| estimate | mesh | {"kind": "uniform_1d", "cells": 9, "nodes": 10, "h": 0.1111111111111111} |
| estimate | memory_estimate_bytes | 724 |
| estimate | system | {"unknowns": 8, "nnz": 22, "symmetric": true, "fingerprint": "7ed6bd241f01c7b5", "operator": "-k u'' + c u' + r u", "advection": "central", "cell_peclet": 0.0,  |
| estimate | refinement_finest_mesh | {"kind": "uniform_1d", "cells": 144, "nodes": 145, "h": 0.006944444444444444} |

## Known limitations (feature status)

- **planned** — geometry: CAD import / curved boundaries / 3D
- **planned** — mesh: graded / stretched / unstructured meshes
- **limited** — physics: incompressible_ns_2d: periodic box (Taylor-Green)
- **planned** — physics: walls / inflow-outflow NS, flow over a cylinder, Schrodinger 1D
- **limited** — quantum: VQLS, exact statevector cost
- **limited** — quantum: VQLS, shot-sampled Hadamard-test cost + SPSA
- **planned** — quantum: noise models, sign-resolving readout, HHL/QSVT, framework backends (Qiskit/Qrisp/PennyLane)
- **planned** — quantum: quantum formulation for transient or nonlinear models
- **planned** — quantum: cloud / physical QPU execution

## Traceability

| Item | Value |
| --- | --- |
| Run ID | 20261110T232527Z-b1-poisson-1d-classical-vs-quantum-9c2c |
| Status | completed |
| Finished | 2026-11-10T23:25:27+00:00 |
| Wall time [s] | 0.7281 |
| System fingerprint (A, b) | 7ed6bd241f01c7b544e3062de91234bfd170bb0c145c7cab19013f848125ef40 |
| Quantum seed | 1234 |
| qcfd | 0.2.0 |
| python | 3.13.18 |
| numpy | 2.5.3 |
| scipy | 1.18.1 |
| platform | Linux-6.18.44-fc-v338-x86_64-with-glibc2.39 |
| machine | x86_64 |
| matplotlib | 3.11.2 |
| Integrity | SHA-256 of every file in checksums.json (verify with `qcfd verify`) |
