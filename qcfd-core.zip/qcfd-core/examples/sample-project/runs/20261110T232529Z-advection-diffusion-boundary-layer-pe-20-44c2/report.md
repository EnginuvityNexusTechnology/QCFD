# Simulation report — Advection-diffusion boundary layer (Pe = 20)

Run `20261110T232529Z-advection-diffusion-boundary-layer-pe-20-44c2` · status **completed** · checks: 6 passed, 0 warning, 0 failed, 0 not applicable

## Set-up

| Item | Value |
| --- | --- |
| Model | steady_transport_1d |
| Geometry | {"kind": "interval", "length": 1.0, "origin": 0.0} |
| Mesh | {"kind": "uniform_1d", "cells": 40, "nodes": 41, "h": 0.025} |
| Boundary conditions | left: dirichlet = exact; right: dirichlet = exact |
| Diffusivity | 0.05 |
| Velocity | 1 |
| Reaction | 0 |
| Source | {"kind": "manufactured", "name": "exp_layer", "params": {"pe": 20.0}} |
| Solver mode | classical |
| Advection scheme | central |

## Solvers

| Role | Method | Status | Known limitations |
| --- | --- | --- | --- |
| classical | gmres | implemented | Restarted GMRES(50), ILU-preconditioned; for non-symmetric operators (advection). |

## Error metrics

| Comparison | max_abs | max_relative | l2_relative | rmse |
| --- | --- | --- | --- | --- |
| classical vs analytical | 0.007879 | 0.007879 | 0.01195 | 0.002348 |

## Where the differences come from

| Source | Magnitude | Note |
| --- | --- | --- |
| discretization | 0.01195 | classical vs analytical; the algebraic error is negligible so this is truncation error |
| classical solver tolerance | 2.626e-16 | relative residual of the classical solve |

## Validation

| Check | Status | Value | Criterion |
| --- | --- | --- | --- |
| mesh.uniform_spacing | passed | 1 | uniform node spacing |
| mesh.resolution | passed | 40 | at least 8 cells recommended for 2nd-order accuracy |
| classical.converged | passed | — | solver convergence |
| classical.residual | passed | 2.626e-16 | relative residual ||Au-b||/||b|| <= 1e-08 |
| classical.reference_error | passed | 0.01195 | relative L2 error vs analytical reference <= 0.05 |
| classical.convergence_order | passed | 2.009 | error vs analytical reference: expected ~2 (+/-0.25) |

![Nodal solution: analytical reference, classical and quantum results.](figures/solution.png)

*Nodal solution: analytical reference, classical and quantum results.*

![Pointwise discretization error and quantum-classical difference (log scale).](figures/error.png)

*Pointwise discretization error and quantum-classical difference (log scale).*

![Grid-refinement study on log-log axes with the expected slope.](figures/refinement.png)

*Grid-refinement study on log-log axes with the expected slope.*

## Resources

| Scope | Item | Value |
| --- | --- | --- |
| classical | runtime_s | 6.117e-04 |
| classical | unknowns | 39 |
| classical | nnz | 115 |
| estimate | mesh | {"kind": "uniform_1d", "cells": 40, "nodes": 41, "h": 0.025} |
| estimate | memory_estimate_bytes | 2,956 |
| estimate | system | {"unknowns": 39, "nnz": 115, "symmetric": false, "fingerprint": "4ab790d6aabf201e", "operator": "-k u'' + c u' + r u", "advection": "central", "cell_peclet": 0. |
| estimate | refinement_finest_mesh | {"kind": "uniform_1d", "cells": 320, "nodes": 321, "h": 0.003125} |

## Known limitations (feature status)

- **planned** — geometry: CAD import / curved boundaries / 3D
- **planned** — mesh: graded / stretched / unstructured meshes
- **limited** — physics: incompressible_ns_2d: periodic box (Taylor-Green)
- **planned** — physics: walls / inflow-outflow NS, flow over a cylinder, Schrodinger 1D

## Traceability

| Item | Value |
| --- | --- |
| Run ID | 20261110T232529Z-advection-diffusion-boundary-layer-pe-20-44c2 |
| Status | completed |
| Finished | 2026-11-10T23:25:29+00:00 |
| Wall time [s] | 0.06994 |
| System fingerprint (A, b) | 4ab790d6aabf201e55b0ea9d1ae9a3d677873cfc4c86b35570ab6bd08e93ff7e |
| qcfd | 0.2.0 |
| python | 3.13.18 |
| numpy | 2.5.3 |
| scipy | 1.18.1 |
| platform | Linux-6.18.44-fc-v338-x86_64-with-glibc2.39 |
| machine | x86_64 |
| matplotlib | 3.11.2 |
| Integrity | SHA-256 of every file in checksums.json (verify with `qcfd verify`) |
