# Simulation report — Burgers 1D - viscous front

Run `20261110T232538Z-burgers-1d-viscous-front-220d` · status **completed** · checks: 6 passed, 0 warning, 0 failed, 0 not applicable

## Set-up

| Item | Value |
| --- | --- |
| Model | burgers_1d |
| Geometry | {"kind": "interval", "length": 1.0, "origin": 0.0} |
| Mesh | {"kind": "uniform_1d", "cells": 64, "nodes": 65, "h": 0.015625} |
| Boundary conditions | left: dirichlet = exact; right: dirichlet = exact |
| Viscosity | 0.02 |
| Initial condition | {"kind": "tanh_front", "u_left": 1.0, "u_right": 0.0, "x_front": 0.25} |
| Time | {"t_end": 0.5, "dt": null, "scheme": "mol_bdf", "snapshots": 11, "cfl": 0.4} |
| Solver mode | classical |

## Solvers

| Role | Method | Status | Known limitations |
| --- | --- | --- | --- |
| classical | mol_bdf | implemented |  |

## Error metrics

| Comparison | max_abs | max_relative | l2_relative | rmse |
| --- | --- | --- | --- | --- |
| classical vs analytical | 0.003954 | 0.003954 | 0.001559 | 0.001058 |

## Where the differences come from

| Source | Magnitude | Note |
| --- | --- | --- |
| discretization (space + time) | 0.001559 | scheme mol_bdf; see the refinement study for the split between h and dt |

## Validation

| Check | Status | Value | Criterion |
| --- | --- | --- | --- |
| mesh.uniform_spacing | passed | 1 | uniform node spacing |
| mesh.resolution | passed | 64 | at least 8 cells recommended for 2nd-order accuracy |
| classical.reference_error | passed | 0.001559 | relative L2 error vs analytical reference at t_end <= 0.05 |
| physics.no_overshoot | passed | 0 | relative overshoot beyond the initial range <= 0.01 |
| stability.cell_reynolds | passed | 0.7797 | cell Reynolds number |u|h/nu (central convection) <= 2 |
| classical.convergence_order | passed | 2.001 | space and time refined together (dt ~ h): expected ~2 (+/-0.25) |

![Solution snapshots in time (light to dark), analytical solution dashed.](figures/snapshots.png)

*Solution snapshots in time (light to dark), analytical solution dashed.*

![Relative L2 error against the analytical solution over time.](figures/error_history.png)

*Relative L2 error against the analytical solution over time.*

![Grid-refinement study on log-log axes with the expected slope.](figures/refinement.png)

*Grid-refinement study on log-log axes with the expected slope.*

## Resources

| Scope | Item | Value |
| --- | --- | --- |
| classical | runtime_s | 0.03217 |
| classical | unknowns | 63 |
| estimate | mesh | {"kind": "uniform_1d", "cells": 64, "nodes": 65, "h": 0.015625} |
| estimate | memory_estimate_bytes | 4,684 |
| estimate | time | {"t_end": 0.5, "scheme": "mol_bdf", "dt": "auto"} |
| estimate | refinement_finest_mesh | {"kind": "uniform_1d", "cells": 512, "nodes": 513, "h": 0.001953125} |

## Known limitations (feature status)

- **planned** — geometry: CAD import / curved boundaries / 3D
- **planned** — mesh: graded / stretched / unstructured meshes
- **limited** — physics: incompressible_ns_2d: periodic box (Taylor-Green)
- **planned** — physics: walls / inflow-outflow NS, flow over a cylinder, Schrodinger 1D

## Traceability

| Item | Value |
| --- | --- |
| Run ID | 20261110T232538Z-burgers-1d-viscous-front-220d |
| Status | completed |
| Finished | 2026-11-10T23:25:38+00:00 |
| Wall time [s] | 0.2713 |
| qcfd | 0.2.0 |
| python | 3.13.18 |
| numpy | 2.5.3 |
| scipy | 1.18.1 |
| platform | Linux-6.18.44-fc-v338-x86_64-with-glibc2.39 |
| machine | x86_64 |
| matplotlib | 3.11.2 |
| Integrity | SHA-256 of every file in checksums.json (verify with `qcfd verify`) |
