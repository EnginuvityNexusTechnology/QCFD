# Simulation report — Taylor-Green vortex 2D

Run `20261110T232539Z-taylor-green-vortex-2d-9fc9` · status **completed** · checks: 8 passed, 0 warning, 0 failed, 0 not applicable

## Set-up

| Item | Value |
| --- | --- |
| Model | incompressible_ns_2d |
| Geometry | {"kind": "rectangle", "lx": 6.283185307179586, "ly": 6.283185307179586, "origin": [0.0, 0.0]} |
| Mesh | {"kind": "uniform_2d", "nx": 32, "ny": 32, "nodes": 1089, "hx": 0.19634954084936207, "hy": 0.19634954084936207} |
| Boundary conditions | left: periodic; right: periodic; bottom: periodic; top: periodic |
| Viscosity | 0.05 |
| Initial condition | {"kind": "taylor_green", "amplitude": 1.0} |
| Time | {"t_end": 2.0, "dt": null, "scheme": null, "snapshots": 9, "cfl": 0.5} |
| Solver mode | classical |

## Solvers

| Role | Method | Status | Known limitations |
| --- | --- | --- | --- |
| classical | ssp_rk3_projection | implemented |  |

## Error metrics

| Comparison | max_abs | max_relative | l2_relative | rmse |
| --- | --- | --- | --- | --- |
| classical vs analytical | 5.256e-04 | 6.419e-04 | 6.419e-04 | 2.628e-04 |

## Where the differences come from

| Source | Magnitude | Note |
| --- | --- | --- |
| discretization (space + time) | 6.419e-04 | scheme ssp_rk3_projection; see the refinement study for the split between h and dt |

## Validation

| Check | Status | Value | Criterion |
| --- | --- | --- | --- |
| mesh.aspect_ratio | passed | 1 | cell aspect ratio <= 4 |
| mesh.resolution | passed | 32 | at least 8 cells per direction recommended |
| classical.reference_error | passed | 6.419e-04 | relative L2 error vs analytical reference at t_end <= 0.05 |
| physics.divergence_free | passed | 1.277e-15 | max |div u| (discrete) at t_end <= 1e-10 |
| physics.energy_decay | passed | 0.6712 | kinetic energy decreases monotonically |
| physics.energy_decay_rate | passed | 8.609e-04 | max |KE(t)/KE(0) - exp(-4 nu k^2 t)| <= 0.01 |
| stability.cfl | passed | 0.485 | CFL number <= 1 |
| classical.convergence_order | passed | 1.999 | space and time refined together (dt ~ h): expected ~2 (+/-0.25) |

![Velocity magnitude, vectors and vorticity at the final time.](figures/flow.png)

*Velocity magnitude, vectors and vorticity at the final time.*

![Kinetic-energy decay against the exact Taylor-Green rate.](figures/energy.png)

*Kinetic-energy decay against the exact Taylor-Green rate.*

![Grid-refinement study on log-log axes with the expected slope.](figures/refinement.png)

*Grid-refinement study on log-log axes with the expected slope.*

## Resources

| Scope | Item | Value |
| --- | --- | --- |
| classical | runtime_s | 0.0199 |
| classical | unknowns | 2,048 |
| estimate | mesh | {"kind": "uniform_2d", "nx": 32, "ny": 32, "nodes": 1089, "hx": 0.19634954084936207, "hy": 0.19634954084936207} |
| estimate | memory_estimate_bytes | 535,792 |
| estimate | time | {"t_end": 2.0, "scheme": "ssp_rk3_projection", "dt": "auto"} |
| estimate | refinement_finest_mesh | {"kind": "uniform_2d", "nx": 128, "ny": 128, "nodes": 16641, "hx": 0.04908738521234052, "hy": 0.04908738521234052} |

## Known limitations (feature status)

- **planned** — geometry: CAD import / curved boundaries / 3D
- **planned** — mesh: graded / stretched / unstructured meshes
- **limited** — physics: incompressible_ns_2d: periodic box (Taylor-Green)
- **planned** — physics: walls / inflow-outflow NS, flow over a cylinder, Schrodinger 1D

## Traceability

| Item | Value |
| --- | --- |
| Run ID | 20261110T232539Z-taylor-green-vortex-2d-9fc9 |
| Status | completed |
| Finished | 2026-11-10T23:25:41+00:00 |
| Wall time [s] | 1.22 |
| qcfd | 0.2.0 |
| python | 3.13.18 |
| numpy | 2.5.3 |
| scipy | 1.18.1 |
| platform | Linux-6.18.44-fc-v338-x86_64-with-glibc2.39 |
| machine | x86_64 |
| matplotlib | 3.11.2 |
| Integrity | SHA-256 of every file in checksums.json (verify with `qcfd verify`) |
