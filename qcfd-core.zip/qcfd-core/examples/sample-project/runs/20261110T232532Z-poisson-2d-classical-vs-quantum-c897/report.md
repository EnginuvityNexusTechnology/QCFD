# Simulation report — Poisson 2D - classical vs quantum

Run `20261110T232532Z-poisson-2d-classical-vs-quantum-c897` · status **completed** · checks: 9 passed, 1 warning, 0 failed, 1 not applicable

## Set-up

| Item | Value |
| --- | --- |
| Model | poisson_2d |
| Geometry | {"kind": "rectangle", "lx": 1.0, "ly": 1.0, "origin": [0.0, 0.0]} |
| Mesh | {"kind": "uniform_2d", "nx": 5, "ny": 5, "nodes": 36, "hx": 0.2, "hy": 0.2} |
| Boundary conditions | left: dirichlet = exact; right: dirichlet = exact; bottom: dirichlet = exact; top: dirichlet = exact |
| Diffusivity | 1 |
| Source | {"kind": "manufactured", "name": "sine2d", "params": {}} |
| Solver mode | both |
| Advection scheme | central |

## Solvers

| Role | Method | Status | Known limitations |
| --- | --- | --- | --- |
| classical | direct | implemented | Sparse LU (SuperLU). Exact to round-off; memory grows with fill-in. |
| quantum | vqls | limited | VQLS on a local noiseless statevector simulator. Sampled mode models shot noise only (no gate/readout noise). Readout signs come from the statevector. Hardware-efficient ansatz without trainability guarantees. Capped at 10 qubits (2^10 unknowns). No quantum advantage is claimed. |

## Error metrics

| Comparison | max_abs | max_relative | l2_relative | rmse |
| --- | --- | --- | --- | --- |
| classical vs analytical | 0.03035 | 0.03356 | 0.03356 | 0.01398 |
| quantum vs analytical | 0.03035 | 0.03356 | 0.03356 | 0.01398 |
| quantum vs classical | 3.907e-08 | 4.180e-08 | 3.179e-08 | 1.369e-08 |

## Where the differences come from

| Source | Magnitude | Note |
| --- | --- | --- |
| discretization | 0.03356 | classical vs analytical; the algebraic error is negligible so this is truncation error |
| classical solver tolerance | 8.649e-16 | relative residual of the classical solve |
| quantum approximation | 3.179e-08 | quantum vs classical on the identical discrete system: ansatz expressivity, optimiser convergence |
| hardware noise | — | not modelled (noiseless simulator) |

## Validation

| Check | Status | Value | Criterion |
| --- | --- | --- | --- |
| mesh.aspect_ratio | passed | 1 | cell aspect ratio <= 4 |
| mesh.resolution | warning | 5 | at least 8 cells per direction recommended |
| classical.converged | passed | — | solver convergence |
| classical.residual | passed | 8.649e-16 | relative residual ||Au-b||/||b|| <= 1e-08 |
| classical.reference_error | passed | 0.03356 | relative L2 error vs analytical reference <= 0.1 |
| quantum.cost_converged | passed | 3.098e-14 | VQLS global cost < 1e-06 (exact, simulator diagnostic) |
| quantum.padding_leakage | passed | 0 | norm of the padded (non-physical) amplitudes <= 0.001 |
| quantum.hardware_noise | not_applicable | — | noiseless simulator: gate and readout noise are not modelled |
| quantum.reference_error | passed | 0.03356 | relative L2 error vs analytical reference <= 0.1 |
| comparison.quantum_vs_classical | passed | 3.179e-08 | relative L2 difference, quantum vs classical <= 0.0001 |
| classical.convergence_order | passed | 2.006 | error vs analytical reference: expected ~2 (+/-0.25) |

![Solution field and difference fields on the structured mesh.](figures/fields.png)

*Solution field and difference fields on the structured mesh.*

![Grid-refinement study on log-log axes with the expected slope.](figures/refinement.png)

*Grid-refinement study on log-log axes with the expected slope.*

## Quantum run details

| Item | Value |
| --- | --- |
| method | vqls |
| cost_mode | exact |
| optimizer | lbfgs |
| seed | 1 |
| final_cost_exact | 3.098e-14 |
| restart_costs | [1.7252865802674933e-13, 3.097522238704187e-14] |
| relative_residual | 1.765e-07 |
| padding_leakage | 0 |
| condition_number | 9.472 |
| scale_factor_mu | -2.584 |

## Resources

| Scope | Item | Value |
| --- | --- | --- |
| classical | runtime_s | 3.303e-04 |
| classical | unknowns | 16 |
| classical | nnz | 160 |
| quantum | unknowns | 16 |
| quantum | qubits | 4 |
| quantum | padded_unknowns | 0 |
| quantum | ansatz_layers | 5 |
| quantum | ansatz_parameters | 24 |
| quantum | ansatz_cx | 15 |
| quantum | ansatz_depth | 17 |
| quantum | statevector_bytes | 256 |
| quantum | feasible_locally | yes |
| quantum | state_prep_cx_estimate | 22 |
| quantum | hadamard_test_ancillas | 1 |
| quantum | pauli_terms_A | 7 |
| quantum | pauli_terms_AtA | 20 |
| quantum | max_pauli_weight | 2 |
| quantum | circuits_per_cost_evaluation | 26 |
| quantum | controlled_ansatz_cx_estimate | 138 |
| quantum | runtime_s | 2.105 |
| quantum | cost_evaluations | 6,100 |
| quantum | circuits_executed | 0 |
| quantum | shots_used | 0 |
| quantum | ansatz_gate_counts | {"ry": 24, "cx": 15} |
| quantum | ansatz_two_qubit_depth | 11 |
| quantum | simulator | qcfd.statevector (NumPy, noiseless) |
| estimate | mesh | {"kind": "uniform_2d", "nx": 5, "ny": 5, "nodes": 36, "hx": 0.2, "hy": 0.2} |
| estimate | memory_estimate_bytes | 6,052 |
| estimate | system | {"unknowns": 16, "nnz": 160, "symmetric": true, "fingerprint": "ac9c0439a531d0e8", "operator": "-k lap u (5-point)", "hx": 0.2, "hy": 0.2} |
| estimate | refinement_finest_mesh | {"kind": "uniform_2d", "nx": 80, "ny": 80, "nodes": 6561, "hx": 0.0125, "hy": 0.0125} |

## Known limitations (feature status)

- **planned** — geometry: CAD import / curved boundaries / 3D
- **planned** — mesh: graded / stretched / unstructured meshes
- **limited** — physics: incompressible_ns_2d: periodic box (Taylor-Green)
- **planned** — physics: walls / inflow-outflow NS, flow over a cylinder, Schrodinger 1D
- **limited** — quantum: VQLS, exact statevector cost
- **limited** — quantum: VQLS, shot-sampled Hadamard-test cost + SPSA
- **planned** — quantum: noise models, sign-resolving readout, HHL/QSVT, framework backends (Qiskit/Qrisp/PennyLane)
- **planned** — quantum: quantum formulation for transient or nonlinear models
- **planned** — quantum: cloud / physical QPU execution

## Traceability

| Item | Value |
| --- | --- |
| Run ID | 20261110T232532Z-poisson-2d-classical-vs-quantum-c897 |
| Status | completed |
| Finished | 2026-11-10T23:25:34+00:00 |
| Wall time [s] | 2.215 |
| System fingerprint (A, b) | ac9c0439a531d0e824caac379c5f28e2a02c4c4098823c5172d18d3c1db61fc8 |
| Quantum seed | 1 |
| qcfd | 0.2.0 |
| python | 3.13.18 |
| numpy | 2.5.3 |
| scipy | 1.18.1 |
| platform | Linux-6.18.44-fc-v338-x86_64-with-glibc2.39 |
| machine | x86_64 |
| matplotlib | 3.11.2 |
| Integrity | SHA-256 of every file in checksums.json (verify with `qcfd verify`) |
