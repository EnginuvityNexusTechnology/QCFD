"""End-to-end workflow: case files, setup validation, stored runs, reports, CLI."""

import json
from pathlib import Path

import pytest

from qcfd.cli import main
from qcfd.workflow.case import CaseError, check_case, load_case, parse_case
from qcfd.workflow.engine import run_case
from qcfd.workflow.storage import Project

CASES = Path(__file__).resolve().parents[1] / "cases"


def test_all_example_cases_pass_setup_validation():
    for f in sorted(CASES.glob("0*.toml")):
        assert not [i for i in check_case(load_case(f)) if i.level == "error"], f.name


def test_bad_case_reports_actionable_errors():
    issues = check_case(load_case(CASES / "bad_case_example.toml"))
    msgs = " ".join(i.message for i in issues if i.level == "error")
    assert "boundary 'right'" in msgs and "[time]" in msgs and "quantum formulation" in msgs


def test_schema_errors_carry_paths():
    with pytest.raises(CaseError) as e:
        parse_case({"name": "x", "geometry": {"kind": "interval", "length": -1},
                    "physics": {"model": "poisson_2d", "bcs": []}, "mesh": {"kind": "uniform_1d", "cells": 4}})
    assert any(i.path == "geometry.interval.length" for i in e.value.issues)


@pytest.fixture()
def project(tmp_path):
    return Project.create(tmp_path / "proj", "test")


def test_steady_run_is_stored_traceable_and_verifiable(project):
    case = load_case(CASES / "01_poisson1d_classical_vs_quantum.toml")
    out = run_case(case, project, case_text=(CASES / "01_poisson1d_classical_vs_quantum.toml").read_text())
    assert out.status == "completed" and not out.failed_checks
    d = out.run_dir
    for f in ("case.toml", "case.resolved.json", "environment.json", "run.log", "system/A.npz",
              "fields/classical.npy", "fields/quantum.npy", "quantum/ansatz.qasm", "results.json",
              "validation.json", "report.html", "report.md", "report.pdf", "fields.csv", "checksums.json"):
        assert (d / f).exists(), f
    res = json.loads((d / "results.json").read_text())
    assert res["comparison"]["compatible"]
    assert res["refinement"]["observed_order"] == pytest.approx(2.0, abs=0.1)
    assert {b["source"] for b in res["error_budget"]} >= {"discretization", "quantum approximation"}
    rf = project.run(out.run_id)
    assert rf.verify() == []
    (d / "fields/classical.npy").write_bytes(b"tampered")
    assert "fields/classical.npy" in rf.verify()
    assert project.runs()[-1]["run_id"] == out.run_id


@pytest.mark.parametrize("name", ["06_heat1d.toml", "07_burgers1d.toml", "08_taylor_green_2d.toml",
                                  "09_reaction_neumann_no_reference.toml", "05_laplace2d_cg.toml"])
def test_classical_cases_complete_without_failures(project, name):
    out = run_case(load_case(CASES / name), project)
    assert out.status == "completed", [c for c in out.checks if c["status"] == "failed"]
    order = [c for c in out.checks if c["name"] == "classical.convergence_order"]
    assert order and order[0]["status"] == "passed"


def test_invalid_case_is_not_run(project):
    with pytest.raises(CaseError):
        run_case(load_case(CASES / "bad_case_example.toml"), project)
    assert project.runs() == []


def test_cli_validate_run_compare_verify(tmp_path, capsys):
    proj = str(tmp_path / "p")
    assert main(["init", proj]) == 0
    assert main(["validate", str(CASES / "bad_case_example.toml")]) == 2
    assert main(["validate", str(CASES / "02_advection_diffusion_1d.toml")]) == 0
    assert main(["run", str(CASES / "02_advection_diffusion_1d.toml"), "--project", proj, "--no-report"]) == 0
    assert main(["run", str(CASES / "02_advection_diffusion_1d.toml"), "--project", proj, "--no-report"]) == 0
    assert main(["run", str(CASES / "09_reaction_neumann_no_reference.toml"), "--project", proj,
                 "--no-report"]) == 0
    a, b, c = [r["run_id"] for r in Project(proj).runs()]
    assert main(["compare", proj, a, b]) == 0
    assert main(["compare", proj, a, c]) == 2
    assert main(["verify", proj, a]) == 0
    assert main(["report", proj, a, "--formats", "html"]) == 0
    assert main(["verify", proj, a]) == 0
    capsys.readouterr()
