"""Quantum module: circuits, Pauli decomposition, VQLS against the classical solution."""

import numpy as np
import pytest
import scipy.sparse.linalg as spla

from qcfd.discretization.fd1d import assemble_steady_1d
from qcfd.discretization.fd2d import assemble_poisson_2d
from qcfd.model.geometry import Interval, Rectangle
from qcfd.model.mesh import MeshSpec1D, MeshSpec2D, build_mesh
from qcfd.model.physics import BC, ManufacturedSource, Poisson2D, SteadyTransport1D
from qcfd.quantum import pauli
from qcfd.quantum.circuit import Circuit, hardware_efficient_ansatz, simulate
from qcfd.quantum.vqls import CostEvaluator, encode, estimate_resources, solve_vqls

D = lambda side: BC(boundary=side, type="dirichlet", value="exact")


def system_1d(cells, velocity=0.0, right="dirichlet"):
    g = Interval(length=1.0)
    bcs = [D("left"), BC(boundary="right", type=right, value="exact")]
    m = SteadyTransport1D(velocity=velocity, source=ManufacturedSource(name="sine"), bcs=bcs)
    return assemble_steady_1d(m, g, build_mesh(g, MeshSpec1D(cells=cells)))


def rel(a, b):
    return np.linalg.norm(a - b) / np.linalg.norm(b)


def test_simulator_gates_and_qasm():
    assert np.allclose(simulate(Circuit(2).ry(0, np.pi).cx(0, 1)), [0, 0, 0, 1])
    assert np.allclose(simulate(Circuit(3).x(2).cx(2, 0)), np.eye(8)[5])
    bell = simulate(Circuit(2).h(0).cx(0, 1))
    assert np.allclose(bell, [2**-0.5, 0, 0, 2**-0.5])
    q = Circuit(2).ry(1, 0.5).cx(0, 1).to_qasm()
    assert "OPENQASM 2.0;" in q and "ry(0.5) q[1];" in q and "cx q[0],q[1];" in q


def test_ansatz_normalised_and_depth():
    c = hardware_efficient_ansatz(4, 3, np.random.default_rng(0).uniform(0, 6, 16))
    assert np.linalg.norm(simulate(c)) == pytest.approx(1.0)
    assert c.gate_counts() == {"ry": 16, "cx": 9}


@pytest.mark.parametrize("n", [1, 2, 3, 4])
def test_pauli_decomposition_roundtrip(n):
    rng = np.random.default_rng(n)
    A = rng.normal(size=(2**n, 2**n)) + 1j * rng.normal(size=(2**n, 2**n))
    assert np.allclose(pauli.to_dense(pauli.decompose(A), n), A, atol=1e-12)


def test_pauli_label_convention():
    Y, X, Z = np.array([[0, -1j], [1j, 0]]), np.array([[0, 1], [1, 0]]), np.diag([1, -1])
    (t,) = pauli.decompose(np.kron(Y, np.kron(X, Z)))
    assert t.label == "YXZ" and t.coeff == pytest.approx(1.0)


def test_padding_to_power_of_two():
    s = system_1d(cells=10)          # 9 unknowns -> 4 qubits, 7 padded
    enc = encode(s)
    assert enc.n_qubits == 4 and enc.A.shape == (16, 16)
    r = solve_vqls(s, restarts=2, seed=3)
    assert r.info["padding_leakage"] < 1e-4
    assert rel(r.u, spla.spsolve(s.A.tocsc(), s.b)) < 1e-4


@pytest.mark.parametrize("velocity,right", [(0.0, "dirichlet"), (2.0, "neumann")])
def test_vqls_exact_matches_classical_1d(velocity, right):
    s = system_1d(cells=9 if right == "dirichlet" else 8, velocity=velocity, right=right)
    r = solve_vqls(s, restarts=3, seed=11)
    assert r.converged
    assert rel(r.u, spla.spsolve(s.A.tocsc(), s.b)) < 1e-5


def test_vqls_exact_matches_classical_2d():
    g = Rectangle(lx=1.0, ly=1.0)
    m = Poisson2D(source=ManufacturedSource(name="sine2d"), bcs=[D(b) for b in g.boundaries])
    s = assemble_poisson_2d(m, g, build_mesh(g, MeshSpec2D(nx=5, ny=5)))
    r = solve_vqls(s, restarts=2, seed=1)
    assert r.resources["qubits"] == 4
    assert rel(r.u, spla.spsolve(s.A.tocsc(), s.b)) < 1e-5


def test_sampled_estimator_is_unbiased():
    s = system_1d(cells=5)
    enc = encode(s)
    theta = np.random.default_rng(0).uniform(0, 6, 2 * 4)
    ex = CostEvaluator(enc, 3, "exact", 1, np.random.default_rng(0))
    x = ex.state(theta)
    beta_ex, den_ex = ex.exact_terms(x)
    sm = CostEvaluator(enc, 3, "sampled", 50_000, np.random.default_rng(1))
    reps = [sm.sampled_terms(x) for _ in range(40)]
    assert np.mean([r[0].real for r in reps]) == pytest.approx(beta_ex.real, abs=5e-3)
    assert np.mean([r[1] for r in reps]) == pytest.approx(den_ex, abs=5e-3)


def test_vqls_sampled_spsa_reaches_few_percent():
    s = system_1d(cells=5)
    r = solve_vqls(s, cost_mode="sampled", optimizer="spsa", shots=20_000, readout_shots=100_000,
                   maxiter=300, restarts=2, seed=7)
    assert r.info["final_cost_exact"] < 0.05
    assert rel(r.u, spla.spsolve(s.A.tocsc(), s.b)) < 0.15
    assert r.resources["shots_used"] > 0


def test_sampled_with_lbfgs_rejected():
    with pytest.raises(ValueError):
        solve_vqls(system_1d(cells=5), cost_mode="sampled", optimizer="lbfgs")


def test_resource_estimate():
    est = estimate_resources(system_1d(cells=9), shots=1000)
    assert est["qubits"] == 3 and est["ansatz_parameters"] == 3 * (4 + 1)
    assert est["pauli_terms_A"] == len(encode(system_1d(cells=9)).a_terms)
    assert est["shots_per_cost_evaluation"] == 1000 * est["circuits_per_cost_evaluation"]
