"""Verification of discretizations and classical solvers against analytical solutions."""

import numpy as np
import pytest
import scipy.sparse.linalg as spla

from qcfd.classical.linear import solve_linear
from qcfd.classical.transient import burgers, heat_theta, ns2d_projection
from qcfd.discretization.fd1d import assemble_steady_1d, manufactured_field as mf1
from qcfd.discretization.fd2d import assemble_poisson_2d, manufactured_field as mf2
from qcfd.model import manufactured as ms
from qcfd.model.geometry import Interval, Rectangle
from qcfd.model.mesh import MeshSpec1D, MeshSpec2D, build_mesh
from qcfd.model.physics import BC, ManufacturedSource, Poisson2D, SteadyTransport1D
from qcfd.workflow.validation import observed_order


def _order_1d(model, geom, adv="central", cells=(16, 32, 64, 128)):
    hs, errs = [], []
    for n in cells:
        mesh = build_mesh(geom, MeshSpec1D(cells=n))
        s = assemble_steady_1d(model, geom, mesh, adv)
        u = s.expand(spla.spsolve(s.A.tocsc(), s.b))
        hs.append(mesh.h)
        errs.append(np.sqrt(mesh.h * np.sum((u - mf1(model, geom).u(mesh.x)) ** 2)))
    return observed_order(hs, errs), s


D = lambda side: BC(boundary=side, type="dirichlet", value="exact")
N = lambda side: BC(boundary=side, type="neumann", value="exact")
GEOM = Interval(length=2.0, origin=0.5)


@pytest.mark.parametrize("bcs", [[D("left"), D("right")], [N("left"), D("right")], [D("left"), N("right")]])
def test_steady_1d_central_second_order(bcs):
    m = SteadyTransport1D(diffusivity=0.3, velocity=0.7, reaction=0.2,
                          source=ManufacturedSource(name="gaussian"), bcs=bcs)
    order, _ = _order_1d(m, GEOM)
    assert order == pytest.approx(2.0, abs=0.1)


def test_steady_1d_upwind_first_order():
    m = SteadyTransport1D(diffusivity=0.3, velocity=1.5, source=ManufacturedSource(name="gaussian"),
                          bcs=[D("left"), D("right")])
    order, _ = _order_1d(m, GEOM, "upwind", cells=(64, 128, 256, 512))
    assert order == pytest.approx(1.0, abs=0.15)


def test_neumann_pure_diffusion_stays_symmetric():
    m = SteadyTransport1D(source=ManufacturedSource(name="sine"), bcs=[N("left"), D("right")])
    _, s = _order_1d(m, Interval(length=1.0))
    assert s.is_symmetric()
    assert solve_linear(s, "cg").converged


def test_exact_layer_and_cubic_are_reproduced():
    # central differences are exact for cubics with pure diffusion
    m = SteadyTransport1D(source=ManufacturedSource(name="poly3", params={"c1": 1, "c2": -2, "c3": 0.5}),
                          bcs=[D("left"), D("right")])
    g = Interval(length=1.0)
    mesh = build_mesh(g, MeshSpec1D(cells=7))
    s = assemble_steady_1d(m, g, mesh)
    assert np.allclose(s.expand(spla.spsolve(s.A.tocsc(), s.b)), mf1(m, g).u(mesh.x), atol=1e-12)


@pytest.mark.parametrize("name", ["sine2d", "exp_sin"])
def test_poisson_2d_second_order(name):
    g = Rectangle(lx=1.0, ly=2.0)
    m = Poisson2D(diffusivity=1.3, source=ManufacturedSource(name=name), bcs=[D(b) for b in g.boundaries])
    hs, errs = [], []
    for n in (8, 16, 32):
        mesh = build_mesh(g, MeshSpec2D(nx=n, ny=n))
        s = assemble_poisson_2d(m, g, mesh)
        u = s.expand(solve_linear(s, "direct").u)
        X, Y = mesh.grid()
        hs.append(mesh.hx); errs.append(np.abs(u - mf2(m, g).u(X, Y)).max())
    assert observed_order(hs, errs) == pytest.approx(2.0, abs=0.1)


def test_linear_solvers_agree():
    g = Rectangle(lx=1.0, ly=1.0)
    m = Poisson2D(source=ManufacturedSource(name="sine2d"), bcs=[D(b) for b in g.boundaries])
    s = assemble_poisson_2d(m, g, build_mesh(g, MeshSpec2D(nx=24, ny=24)))
    ref = solve_linear(s, "direct").u
    for method in ("cg", "gmres"):
        r = solve_linear(s, method, rtol=1e-12)
        assert r.converged and np.allclose(r.u, ref, rtol=1e-8, atol=1e-10)


def test_cg_rejects_nonsymmetric():
    m = SteadyTransport1D(velocity=1.0, source=ManufacturedSource(name="sine"), bcs=[D("left"), D("right")])
    g = Interval(length=1.0)
    s = assemble_steady_1d(m, g, build_mesh(g, MeshSpec1D(cells=16)))
    with pytest.raises(ValueError):
        solve_linear(s, "cg")


@pytest.mark.parametrize("theta,expected", [(0.5, 2.0), (1.0, 1.0)])
def test_heat_temporal_order(theta, expected):
    x = np.linspace(0, 1, 801)
    ex = lambda t: ms.heat_sine_exact(x, t, alpha=0.1, k=1, amplitude=1, x0=0, length=1)
    errs = [np.abs(heat_theta(x, ex(0), 0.1, 0.5, dt, lambda t: 0.0, lambda t: 0.0, theta=theta)
                   .fields["u"][-1] - ex(0.5)).max() for dt in (0.05, 0.025, 0.0125)]
    assert observed_order([0.05, 0.025, 0.0125], errs) == pytest.approx(expected, abs=0.15)


def test_burgers_bdf_second_order():
    kw = dict(nu=0.02, u_left=1.0, u_right=0.0, x_front=0.3)
    hs, errs = [], []
    for n in (64, 128, 256):
        x = np.linspace(0, 1, n + 1)
        bl = lambda t: ms.burgers_tanh_exact(np.array([0.0]), t, **kw)[0]
        br = lambda t: ms.burgers_tanh_exact(np.array([1.0]), t, **kw)[0]
        r = burgers(x, ms.burgers_tanh_exact(x, 0, **kw), 0.02, 0.3, None, bl, br, method="mol_bdf")
        hs.append(1 / n); errs.append(np.abs(r.fields["u"][-1] - ms.burgers_tanh_exact(x, 0.3, **kw)).max())
    assert observed_order(hs, errs) == pytest.approx(2.0, abs=0.1)


def test_taylor_green_divergence_free_and_second_order():
    L, errs, hs = 2 * np.pi, [], []
    for n in (16, 32, 64):
        xs = np.arange(n) * L / n
        X, Y = np.meshgrid(xs, xs)
        u0, v0, _ = ms.taylor_green_exact(X, Y, 0, nu=0.05, amplitude=1, length=L)
        r = ns2d_projection(L, n, u0, v0, 0.05, 1.0)
        ue, _, _ = ms.taylor_green_exact(X, Y, 1.0, nu=0.05, amplitude=1, length=L)
        assert r.info["max_divergence_final"] < 1e-12
        hs.append(L / n); errs.append(np.abs(r.fields["u"][-1] - ue).max())
    assert observed_order(hs, errs) == pytest.approx(2.0, abs=0.1)
